import 'dart:convert';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:naksaa_services/MainAsset/LoadingIndicator.dart';
import 'package:naksaa_services/Service/AllVendorService.dart';
import 'package:naksaa_services/Service/CustomerProfileService.dart';
import 'package:naksaa_services/UI/Home/Partner/VideoCall/VideoCallWithVendor.dart';
import 'package:naksaa_services/UI/REgister/project%20Assets/constants.dart';
import 'package:naksaa_services/model/CustomerProfileModel.dart';
import 'package:naksaa_services/model/VendorDetailsModel.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../../../MainAsset/URL.dart';

class IncomingVideoCallRequest extends StatefulWidget {
  String channelname;
  String token;
  String vendorid;
  IncomingVideoCallRequest(
      {super.key,
      required this.channelname,
      required this.token,
      required this.vendorid});

  @override
  State<IncomingVideoCallRequest> createState() =>
      _IncomingVideoCallRequestState();
}

class _IncomingVideoCallRequestState extends State<IncomingVideoCallRequest>
    with WidgetsBindingObserver {
  bool isloading = false;
  bool isloginloading = false;
  List<Vdatum> results = [];
  var vendorService = AllVendorService();
  var customerService = CustomerProfileService();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    getVendorDetails();
    getUserDetails();
  }

  Future<List<Vdatum>> getVendorDetails() async {
    print(widget.vendorid);
    var response = await vendorService.viewSingleVendor(widget.vendorid);

    results = VendorDetailsmodel.fromJson(jsonDecode(response)).vdata.toList();
    print(results);
    if (results != null) {
      setState(() {
        isloading = true;
      });
      return results;
    } else {
      throw Exception('Failed to load');
    }
  }

  List<CustomerP?> _customerList = [];
  Future<List<CustomerP?>> getUserDetails() async {
    print(widget.vendorid);
    SharedPreferences pref = await SharedPreferences.getInstance();
    String? phone = pref.getString("phone");
    var response = await customerService.viewCustomerProfile(phone!);

    if (results != null) {
      setState(() {
        _customerList = response!;
        isloading = true;
      });
      return _customerList;
    } else {
      throw Exception('Failed to load');
    }
  }

  @override
  Widget build(BuildContext context) {
    return isloading != false
        ? Scaffold(
            backgroundColor: Colors.black,
            body: Container(
              height: 812,
              width: 375,
              decoration: BoxDecoration(
                  color: Colors.black,
                  image: DecorationImage(
                    image: AssetImage("assets/SVG/request.png"),
                    colorFilter: ColorFilter.mode(
                        Colors.black.withOpacity(0.25), BlendMode.dstATop),
                  )),
              child: Column(children: [
                Container(
                  margin: EdgeInsets.only(top: 90),
                  child: Text(
                    "Incoming Chat Request From",
                    style: TextStyle(fontSize: 14, color: Colors.white),
                  ),
                ),
                SizedBox(
                  height: 20,
                ),
                Container(
                  height: 43,
                  width: 118,
                  decoration: BoxDecoration(
                      image: DecorationImage(
                    image: AssetImage("assets/logo.png"),
                  )),
                ),
                SizedBox(
                  height: 144,
                ),
                Container(
                  height: 127,
                  width: 127,
                  decoration: BoxDecoration(
                      border: Border.all(width: 2, color: themeColor),
                      shape: BoxShape.circle,
                      image: DecorationImage(
                          image: NetworkImage(
                              MainUrl + 'vendor-image/' + results[0].photo),
                          fit: BoxFit.fill)),
                ),
                SizedBox(
                  height: 22,
                ),
                Container(
                  child: Text(
                    "${results[0].name}",
                    style: TextStyle(
                        fontSize: 18,
                        color: Colors.white,
                        fontWeight: FontWeight.bold),
                  ),
                ),
                SizedBox(
                  height: 84,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    isloginloading != true
                        ? GestureDetector(
                            onTap: () async {
                              setState(() {
                                isloginloading = true;
                              });
                              SharedPreferences pref =
                                  await SharedPreferences.getInstance();
                              String? uid = pref.getString("uid");
                              Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) => VideoCallWithVendor(
                                          channnelName: "naks",
                                          token:
                                              "007eJxTYFg+cXPjRqa17dpKE6ZzP+APTtjgvZdjsn7WuklRjZUsjScVGJLMDJPNTAwsTQyNk01SjNKSkszTTIwsLFJNzBMTLVLMvuq+Sm4IZGRYtHUTMyMDBIL4LAx5idnFDAwA+gofHA==",
                                          // vendorData: results,
                                          userid: uid!)));
                              setState(() {
                                isloginloading = false;
                              });
                            },
                            child: Container(
                              height: 71,
                              width: 71,
                              decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: Color.fromRGBO(67, 217, 102, 1)),
                              child: Center(
                                child: Icon(
                                  Icons.call,
                                  color: Colors.white,
                                  size: 30,
                                ),
                              ),
                            ),
                          )
                        : const LoadingIndicator(),
                    GestureDetector(
                      onTap: () async {},
                      child: Container(
                        height: 71,
                        width: 71,
                        decoration: BoxDecoration(
                            shape: BoxShape.circle, color: Colors.red),
                        child: Center(
                          child: Icon(
                            Icons.call,
                            color: Colors.white,
                            size: 30,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
                SizedBox(
                  height: 20,
                ),
                // Text(
                //   "Reject Chat Request",
                //   style: TextStyle(
                //       fontSize: 10,
                //       color: Colors.white,
                //       fontWeight: FontWeight.normal),
                // ),
              ]),
            ),
          )
        : const Scaffold(
            backgroundColor: themeColor,
            body: Center(child: LoadingIndicator()),
          );
    ;
  }
}

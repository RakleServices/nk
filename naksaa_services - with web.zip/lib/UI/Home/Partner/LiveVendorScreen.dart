// import 'dart:ui';

// import 'package:agora_rtc_engine/agora_rtc_engine.dart';
// import 'package:flutter/material.dart';
// import 'package:naksaa_services/API/constants.dart';
// import 'package:naksaa_services/UI/Home/BottomNavigation.dart';
// import 'package:naksaa_services/UI/REgister/project%20Assets/constants.dart';
// import 'dart:math' as math;

// import 'package:permission_handler/permission_handler.dart';

// import '../../../API/FirebaseMethods.dart';

// class LiveVendorScreen extends StatefulWidget {
//   final bool isRole;
//   final String channelId;
//   final int uid;
//   const LiveVendorScreen(
//       {super.key,
//       required this.isRole,
//       required this.channelId,
//       required this.uid});

//   @override
//   State<LiveVendorScreen> createState() => _LiveVendorScreenState();
// }

// class _LiveVendorScreenState extends State<LiveVendorScreen> {
//   String channelName = "naks";
//   String token =
//       "007eJxTYGg2bd7RsWZv6qEilS7L8+UtUZNT7IL5bCTdVmXrafxyCFJgSDIzTDYzMbA0MTRONkkxSktKMk8zMbKwSDUxT0y0SDH7tPN2ckMgI4Op8n4WRgYIBPFZGPISs4sZGADS0x4T";
//   // uid of the local user

//   int? _remoteUid; // uid of the remote user
//   bool _isJoined = false; // Indicates if the local user has joined the channeRl
//   late RtcEngine agoraEngine; // Agora engine instance

//   final GlobalKey<ScaffoldMessengerState> scaffoldMessengerKey =
//       GlobalKey<ScaffoldMessengerState>(); // Global key to access the scaffold

//   showMessage(String message) {
//     scaffoldMessengerKey.currentState?.showSnackBar(SnackBar(
//       content: Text(message),
//     ));
//   }

//   final TextEditingController _chatController = TextEditingController();
//   final _formKey = GlobalKey<FormState>();

//   @override
//   void initState() {
//     super.initState();
//     // Set up an instance of Agora engine
//     setupVideoSDKEngine();
//   }

//   @override
//   void dispose() async {
//     await agoraEngine.leaveChannel();
//     _chatController.dispose();
//     super.dispose();
//   }

//   Future<void> setupVideoSDKEngine() async {
//     // retrieve or request camera and microphone permissions
//     await [Permission.microphone, Permission.camera].request();

//     //create an instance of the Agora engine
//     agoraEngine = createAgoraRtcEngine();
//     await agoraEngine.initialize(
//         const RtcEngineContext(appId: 'b61c6409413c4d2fbb7f4288e47aa8d6'));

//     await agoraEngine.enableVideo();

//     // Register the event handler
//     agoraEngine.registerEventHandler(
//       RtcEngineEventHandler(
//         onJoinChannelSuccess: (RtcConnection connection, int elapsed) {
//           showMessage(
//               "Local user uid:${connection.localUid} joined the channel");
//           setState(() {
//             _isJoined = true;
//           });
//         },
//         onUserJoined: (RtcConnection connection, int remoteUid, int elapsed) {
//           showMessage("Remote user uid:$remoteUid joined the channel");
//           setState(() {
//             _remoteUid = remoteUid;
//           });
//         },
//         onUserOffline: (RtcConnection connection, int remoteUid,
//             UserOfflineReasonType reason) {
//           showMessage("Remote user uid:$remoteUid left the channel");
//           setState(() {
//             _remoteUid = null;
//           });
//         },
//       ),
//     );
//     join();
//   }

//   void join() async {
//     // await agoraEngine.startPreview();

//     // // Set channel options including the client role and channel profile
//     ChannelMediaOptions options = const ChannelMediaOptions(
//       clientRoleType: ClientRoleType.clientRoleAudience,
//       channelProfile: ChannelProfileType.channelProfileLiveBroadcasting,
//     );
//     // await agoraEngine.startPreview();
//     // await agoraEngine
//     //     .setChannelProfile(ChannelProfileType.channelProfileLiveBroadcasting);
//     // if (widget.isRole) {
//     //   await agoraEngine.setClientRole(
//     //       role: ClientRoleType.clientRoleBroadcaster);
//     // } else {
//     //   await agoraEngine.setClientRole(role: ClientRoleType.clientRoleAudience);
//     // }

//     await agoraEngine.joinChannel(
//       token: token, channelId: channelName, uid: widget.uid,
//       options: options,
//       // uid: uid,
//     );
//     await updateViewCount(widget.uid.toString(), true);
//   }

//   void leave() async {
//     setState(() {
//       _isJoined = false;
//       _remoteUid = null;
//     });
//     await agoraEngine.leaveChannel();
//   }

//   bool isSwitched = false;
//   bool isVideomute = false;
//   bool mutecall = false;
//   void _onVideoMute(bool newval) {
//     agoraEngine.muteLocalVideoStream(newval);
//   }

//   _leaveChannel() async {
//     await agoraEngine.leaveChannel();
//     await updateViewCount(widget.uid.toString(), false);
//     Navigator.push(
//         context,
//         MaterialPageRoute(
//             builder: (context) => BottomNavigationBarScreen(
//                   pageIndex: 0,
//                 )));
//     //   if(widget.channelId == '123vjkv jk'){

//     //   }
//     // }
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       body: Container(
//         height: 720,
//         width: double.infinity,
//         // decoration: BoxDecoration(
//         //     image: DecorationImage(
//         //         image: NetworkImage(
//         //             "https://media.licdn.com/dms/image/C4D03AQGShQK41raBRw/profile-displayphoto-shrink_800_800/0/1653502865358?e=2147483647&v=beta&t=YxSdpV0rHxs9IldnnJrNRp0sIWeuBMT-G-wcjP50t-w"),
//         //         fit: BoxFit.cover)),
//         child: Stack(children: [
//           Container(height: 800, width: 400, child: _remoteVideo()),
//           Positioned(
//             top: 49,
//             left: 11,
//             child: Container(
//               height: 74,
//               child: Row(children: [
//                 GestureDetector(
//                   onTap: () {
//                     _leaveChannel();
//                   },
//                   child: Container(
//                     height: 44,
//                     width: 44,
//                     decoration: BoxDecoration(
//                         color: Colors.black.withOpacity(0.30),
//                         shape: BoxShape.circle),
//                     child: Center(
//                         child: Icon(
//                       Icons.arrow_back_sharp,
//                       size: 25,
//                       color: Colors.white,
//                     )),
//                   ),
//                 ),
//                 SizedBox(
//                   width: 19,
//                 ),
//                 GestureDetector(
//                   onTap: () {},
//                   child: Container(
//                     height: 74,
//                     width: 59,
//                     child: Stack(
//                       children: [
//                         Container(
//                           height: 59,
//                           width: 59,
//                           decoration: BoxDecoration(
//                               shape: BoxShape.circle,
//                               border: Border.all(width: 2, color: Colors.red),
//                               image: DecorationImage(
//                                   image: NetworkImage(
//                                       "https://rationcart.in/assets/img/Logo_rc.png"))),
//                         ),
//                         Positioned(
//                             bottom: 0,
//                             child: Container(
//                               height: 23,
//                               width: 59,
//                               decoration: BoxDecoration(
//                                   color: Colors.red,
//                                   borderRadius: BorderRadius.circular(15)),
//                               child: Center(
//                                   child: Text(
//                                 "Live",
//                                 style: TextStyle(
//                                     fontSize: 17, color: Colors.white),
//                               )),
//                             ))
//                       ],
//                     ),
//                   ),
//                 ),
//                 SizedBox(
//                   width: 15,
//                 ),
//                 Text(
//                   "Dilip Pandey",
//                   style: TextStyle(
//                       fontSize: 16,
//                       fontWeight: FontWeight.bold,
//                       color: Colors.white),
//                 ),
//                 SizedBox(
//                   width: 5,
//                 ),
//                 Container(
//                   height: 25,
//                   width: 25,
//                   decoration: BoxDecoration(
//                       image: DecorationImage(
//                           image: AssetImage("assets/SVG/star2-2x.png"),
//                           fit: BoxFit.fill)),
//                   child: Center(
//                       child: Icon(
//                     Icons.check,
//                     size: 10,
//                     color: Colors.white,
//                   )),
//                 ),
//                 SizedBox(
//                   width: 25,
//                 ),
//                 Container(
//                   child: Column(
//                       mainAxisAlignment: MainAxisAlignment.center,
//                       crossAxisAlignment: CrossAxisAlignment.center,
//                       children: [
//                         Container(
//                           height: 23,
//                           padding:
//                               EdgeInsets.symmetric(vertical: 2, horizontal: 7),
//                           decoration: BoxDecoration(
//                               borderRadius: BorderRadius.circular(15),
//                               color: Colors.black.withOpacity(0.25)),
//                           child: Center(
//                             child: Row(children: [
//                               Icon(
//                                 Icons.remove_red_eye,
//                                 color: Colors.white,
//                                 size: 12,
//                               ),
//                               SizedBox(
//                                 width: 3,
//                               ),
//                               Text(
//                                 "3222",
//                                 style: TextStyle(
//                                     fontSize: 12,
//                                     color: Colors.white,
//                                     fontWeight: FontWeight.bold),
//                               )
//                             ]),
//                           ),
//                         ),
//                         SizedBox(
//                           height: 6,
//                         ),
//                         Container(
//                           height: 23,
//                           padding:
//                               EdgeInsets.symmetric(vertical: 2, horizontal: 10),
//                           decoration: BoxDecoration(
//                               borderRadius: BorderRadius.circular(15),
//                               color: themeColor),
//                           child: Center(
//                               child: Text(
//                             "Follow",
//                             style: TextStyle(
//                                 fontSize: 12,
//                                 color: blueColor,
//                                 fontWeight: FontWeight.bold),
//                           )),
//                         )
//                       ]),
//                 )
//               ]),
//             ),
//           ),
//           Positioned(
//               bottom: 10,
//               child: Container(
//                 width: 355,
//                 child:
//                     Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
//                   SizedBox(
//                     width: 16,
//                   ),
//                   Container(
//                     width: 258,
//                     child: Column(
//                       children: [
//                         ListView.builder(
//                             shrinkWrap: true,
//                             physics: AlwaysScrollableScrollPhysics(),
//                             itemCount: 5,
//                             itemBuilder: ((context, index) {
//                               return Container(
//                                 margin: EdgeInsets.only(bottom: 10),
//                                 child: Row(children: [
//                                   Container(
//                                     height: 39,
//                                     width: 39,
//                                     decoration: BoxDecoration(
//                                         shape: BoxShape.circle,
//                                         image: DecorationImage(
//                                             image: NetworkImage(
//                                                 "https://rationcart.in/assets/img/Logo_rc.png"))),
//                                   ),
//                                   SizedBox(
//                                     width: 10,
//                                   ),
//                                   Column(
//                                       crossAxisAlignment:
//                                           CrossAxisAlignment.start,
//                                       children: [
//                                         Text(
//                                           "Srishti Sharma",
//                                           style: TextStyle(
//                                               fontSize: 12,
//                                               color: Colors.white,
//                                               fontWeight: FontWeight.bold),
//                                         ),
//                                         SizedBox(
//                                           height: 3,
//                                         ),
//                                         Text(
//                                           "Joined",
//                                           style: TextStyle(
//                                               fontSize: 11,
//                                               color: Colors.white,
//                                               fontWeight: FontWeight.normal),
//                                         )
//                                       ]),
//                                 ]),
//                               );
//                             })),
//                         Container(
//                           height: 35,
//                           width: 258,
//                           padding:
//                               EdgeInsets.symmetric(vertical: 0, horizontal: 10),
//                           decoration: BoxDecoration(
//                               color: Colors.white,
//                               borderRadius: BorderRadius.circular(18)),
//                           child: Center(
//                               child: Row(
//                             children: [
//                               Container(
//                                 height: 35,
//                                 width: 210,
//                                 child: Center(
//                                   child: TextFormField(
//                                     decoration: InputDecoration(
//                                       border: InputBorder.none,
//                                       hintText: 'Type your comment',
//                                       focusedBorder: InputBorder.none,
//                                       enabledBorder: InputBorder.none,
//                                       errorBorder: InputBorder.none,
//                                       disabledBorder: InputBorder.none,
//                                     ),
//                                   ),
//                                 ),
//                               ),
//                               SizedBox(
//                                 width: 10,
//                               ),
//                               Transform.rotate(
//                                 angle: -math.pi / 4,
//                                 child: Container(
//                                   margin: EdgeInsets.only(bottom: 10),
//                                   height: 18,
//                                   width: 18,
//                                   decoration: BoxDecoration(
//                                       // shape: BoxShape.circle,
//                                       image: DecorationImage(
//                                           image: AssetImage(
//                                               "assets/SVG/Group.png"),
//                                           fit: BoxFit.fill)),
//                                 ),
//                               ),
//                             ],
//                           )),
//                         )
//                       ],
//                     ),
//                   ),
//                   SizedBox(
//                     width: 30,
//                   ),
//                   Container(
//                     child: Column(
//                         mainAxisAlignment: MainAxisAlignment.end,
//                         children: [
//                           Container(
//                             height: 44,
//                             width: 44,
//                             decoration: BoxDecoration(
//                                 shape: BoxShape.circle,
//                                 color: themeColor,
//                                 border:
//                                     Border.all(width: 2, color: Colors.white)),
//                             child: Icon(
//                               Icons.call,
//                               color: blueColor,
//                               size: 25,
//                             ),
//                           ),
//                           SizedBox(
//                             height: 10,
//                           ),
//                           Container(
//                             height: 44,
//                             width: 44,
//                             decoration: BoxDecoration(
//                                 shape: BoxShape.circle,
//                                 color: themeColor,
//                                 border:
//                                     Border.all(width: 2, color: Colors.white)),
//                             child: Icon(
//                               Icons.diamond,
//                               color: blueColor,
//                               size: 25,
//                             ),
//                           ),
//                           SizedBox(
//                             height: 10,
//                           ),
//                           Container(
//                             height: 44,
//                             width: 44,
//                             decoration: BoxDecoration(
//                                 shape: BoxShape.circle,
//                                 color: themeColor,
//                                 border:
//                                     Border.all(width: 2, color: Colors.white)),
//                             child: Icon(
//                               Icons.message,
//                               color: blueColor,
//                               size: 25,
//                             ),
//                           ),
//                           SizedBox(
//                             height: 10,
//                           ),
//                           Container(
//                             height: 44,
//                             width: 44,
//                             decoration: BoxDecoration(
//                                 shape: BoxShape.circle,
//                                 color: themeColor,
//                                 border:
//                                     Border.all(width: 2, color: Colors.white)),
//                             child: Icon(
//                               Icons.thumb_up_alt_sharp,
//                               color: blueColor,
//                               size: 25,
//                             ),
//                           )
//                         ]),
//                   )
//                 ]),
//               ))
//         ]),
//       ),
//     );
//   }

//   Widget _localPreview() {
//     if (_isJoined) {
//       return AgoraVideoView(
//           controller: VideoViewController(
//         rtcEngine: agoraEngine,
//         canvas: VideoCanvas(
//           uid: 1234,
//           sourceType: VideoSourceType.videoSourceScreen,
//         ),
//       ));
//     } else {
//       return const Text(
//         'Join a channel',
//         textAlign: TextAlign.center,
//       );
//     }
//   }

//   Widget _remoteVideo() {
//     if (_remoteUid != null) {
//       // return Container();
//       return AgoraVideoView(
//         controller: VideoViewController.remote(
//           rtcEngine: agoraEngine,
//           canvas: VideoCanvas(uid: _remoteUid),
//           connection: RtcConnection(channelId: channelName),
//         ),
//       );
//     } else {
//       String msg = '';
//       if (_isJoined) msg = 'Waiting for a remote user to join';
//       return Text(
//         msg,
//         textAlign: TextAlign.center,
//       );
//     }
//   }
// }

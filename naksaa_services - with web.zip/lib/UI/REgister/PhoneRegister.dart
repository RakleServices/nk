import 'dart:convert';

import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:naksaa_services/API/NetworkProvider.dart';
import 'package:naksaa_services/UI/REgister/OTPVarification.dart';
import 'package:naksaa_services/UI/REgister/project%20Assets/constants.dart';

class PhoneRegister extends StatefulWidget {
  const PhoneRegister({super.key});

  @override
  State<PhoneRegister> createState() => _PhoneRegisterState();
}

class _PhoneRegisterState extends State<PhoneRegister> {
  var networkHandler = NetworkHandler();
  TextEditingController _phone = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  String? ftoken;
  var isloading = false;

  @override
  void initState() {
    super.initState();
    gettoken();
  }

  Future<void> gettoken() async {
    final fcmToken = await FirebaseMessaging.instance.getToken();
    setState(() {
      ftoken = fcmToken.toString();
      print("fcm" + ftoken.toString());
    });
  }

  @override
  Widget build(BuildContext context) {
    var screenWidth = MediaQuery.of(context).size.width;
    var screenHeight = MediaQuery.of(context).size.height;
    Size size = MediaQuery.of(context).size;
    return LayoutBuilder(builder: (context, constraints) {
      if (constraints.maxWidth > 1200) {
        return DesktopPhoneRegister();
      } else if (constraints.maxWidth > 800 && constraints.maxWidth < 1200) {
        return DesktopPhoneRegister();
      } else {
        return MobilePhoneregister();
      }
    });
  }

  Widget DesktopPhoneRegister() {
    return Scaffold(
      body: SingleChildScrollView(
        child: Center(
          child: Container(
            height: 700,
            width: 700,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Container(
                  margin: EdgeInsets.only(top: 60, left: 21),
                  height: 140,
                  width: 150,
                  child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          height: 100,
                          // width: 198,
                          child: Image.asset(
                            "assets/logo.png",
                            fit: BoxFit.fill,
                          ),
                        ),
                        SizedBox(
                          height: 5,
                        ),
                        Text(
                          "DISCOVER THE BEST SOLUTION EASY & SIMPLE",
                          style: TextStyle(
                              fontSize: 10,
                              color: Color.fromRGBO(112, 112, 112, 1)),
                        )
                      ]),
                ),
                Container(
                  margin: EdgeInsets.only(top: 68),
                  height: 400,
                  width: double.infinity,
                  decoration: BoxDecoration(
                      image: DecorationImage(
                          image: AssetImage("assets/SVG/back.png"))),
                  child: Container(
                    height: 390,
                    width: 340,
                    margin: EdgeInsets.only(left: 20, right: 20),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      color: Colors.white,
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.12),
                          offset: const Offset(
                            3.0,
                            3.0,
                          ),
                          blurRadius: 8.0,
                          spreadRadius: 2.0,
                        ), //BoxShadow
                        BoxShadow(
                          color: Colors.white,
                          offset: const Offset(0.0, 0.0),
                          blurRadius: 0.0,
                          spreadRadius: 0.0,
                        ), //BoxShadow
                      ],
                    ),
                    child: Form(
                      key: _formKey,
                      child: Column(children: [
                        Container(
                          width: 400,
                          margin: EdgeInsets.symmetric(
                              vertical: 35, horizontal: 40),
                          child: Text(
                            "Log In",
                            textAlign: TextAlign.center,
                            style: TextStyle(
                                fontSize: 26,
                                color: Color.fromRGBO(2, 44, 67, 1),
                                fontWeight: FontWeight.bold),
                          ),
                        ),
                        Container(
                          height: 56,
                          width: 400,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(25),
                            color: Colors.white,
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withOpacity(0.12),
                                offset: const Offset(
                                  3.0,
                                  3.0,
                                ),
                                blurRadius: 8.0,
                                spreadRadius: 2.0,
                              ), //BoxShadow
                              BoxShadow(
                                color: Colors.white,
                                offset: const Offset(0.0, 0.0),
                                blurRadius: 0.0,
                                spreadRadius: 0.0,
                              ), //BoxShadow
                            ],
                          ),
                          child: Row(children: [
                            SizedBox(
                              width: 6,
                            ),
                            Container(
                              height: 50,
                              width: 50,
                              decoration: BoxDecoration(
                                  image: DecorationImage(
                                      image: AssetImage(
                                          "assets/SVG/flag-2x.png"))),
                            ),
                            SizedBox(
                              width: 20,
                            ),
                            Container(
                              child: Center(
                                  child: Text(
                                "INDIA +91",
                                style: TextStyle(
                                    fontSize: 12,
                                    color: Color.fromRGBO(164, 164, 164, 1)),
                              )),
                            ),
                          ]),
                        ),
                        SizedBox(
                          height: 20,
                        ),
                        Container(
                          height: 56,
                          width: 400,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(25),
                            color: Colors.white,
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withOpacity(0.12),
                                offset: const Offset(
                                  3.0,
                                  3.0,
                                ),
                                blurRadius: 8.0,
                                spreadRadius: 2.0,
                              ), //BoxShadow
                              BoxShadow(
                                color: Colors.white,
                                offset: const Offset(0.0, 0.0),
                                blurRadius: 0.0,
                                spreadRadius: 0.0,
                              ), //BoxShadow
                            ],
                          ),
                          child: Center(
                              child: TextFormField(
                            controller: _phone,
                            textAlign: TextAlign.center,
                            keyboardType: TextInputType.phone,
                            decoration: InputDecoration(
                              border: InputBorder.none,
                              hintText: 'Enter Mobile Number',
                            ),
                            validator: (value) {
                              if (value == null || value.isEmpty) {
                                return 'Enter your mobile';
                              } else if (value.length < 10) {
                                return 'Enter 10 digit mobile number';
                              } else if (value.length > 10) {
                                return 'Enter 10 digit mobile number';
                              }
                              return null;
                            },
                            style: TextStyle(
                                fontSize: 15,
                                color: Color.fromRGBO(164, 164, 164, 1)),
                          )),
                        ),
                        SizedBox(
                          height: 40,
                        ),
                        GestureDetector(
                          onTap: () async {
                            if (_formKey.currentState!.validate()) {
                              setState(() {
                                isloading = true;
                              });
                              Map<String, String> data = {
                                'phone': _phone.text,
                                'mob_notification': ftoken.toString()
                              };
                              var response = await networkHandler.post(
                                  'customer-reg', data);

                              if (response.statusCode == 200) {
                                Map jsonResponse = jsonDecode(response.body);
                                if (jsonResponse['status'] == true) {
                                  setState(() {
                                    isloading = false;
                                  });
                                  Fluttertoast.showToast(
                                      msg: jsonResponse['otp'],
                                      toastLength: Toast.LENGTH_SHORT,
                                      gravity: ToastGravity.BOTTOM,
                                      timeInSecForIosWeb: 1,
                                      backgroundColor: themeColor,
                                      textColor: Colors.white,
                                      fontSize: 16.0);
                                  Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) => OTPVarification(
                                                mobile: _phone.text,
                                              )));
                                } else {
                                  setState(() {
                                    isloading = false;
                                  });
                                  Fluttertoast.showToast(
                                      msg:
                                          "Something went wrong!, please try again..",
                                      toastLength: Toast.LENGTH_SHORT,
                                      gravity: ToastGravity.BOTTOM,
                                      timeInSecForIosWeb: 1,
                                      backgroundColor: themeColor,
                                      textColor: Colors.white,
                                      fontSize: 16.0);
                                }
                              }
                            }
                          },
                          child: isloading == false
                              ? Container(
                                  width: 247,
                                  height: 56,
                                  decoration: BoxDecoration(
                                      color: Colors.yellow,
                                      borderRadius: BorderRadius.circular(25),
                                      border: Border.all(
                                          width: 2, color: Colors.yellow)),
                                  child: Center(
                                    child: Text(
                                      "GET OTP",
                                      style: TextStyle(
                                          fontSize: 17, color: Colors.white),
                                    ),
                                  ),
                                )
                              : Container(
                                  width: 247,
                                  height: 56,
                                  decoration: BoxDecoration(
                                      color: Colors.yellow,
                                      borderRadius: BorderRadius.circular(25),
                                      border: Border.all(
                                          width: 2, color: Colors.yellow)),
                                  child: Center(
                                      child: CircularProgressIndicator(
                                    color: Colors.white,
                                  )),
                                ),
                        )
                      ]),
                    ),
                  ),
                ),
                Center(
                  child: Container(
                    margin: EdgeInsets.only(
                      top: 50,
                    ),
                    width: 196,
                    child: Text(
                      "Welcome To ChatnFix Discover the Best Solution Easy & Simple",
                      textAlign: TextAlign.center,
                      style: TextStyle(fontSize: 16, color: Colors.black),
                    ),
                  ),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget MobilePhoneregister() {
    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              margin: EdgeInsets.only(top: 94, left: 21),
              height: 84,
              width: double.infinity,
              child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      height: 65,
                      // width: 198,
                      child: Image.asset(
                        "assets/logo.png",
                        fit: BoxFit.fill,
                      ),
                    ),
                    SizedBox(
                      height: 5,
                    ),
                    Text(
                      "DISCOVER THE BEST SOLUTION EASY & SIMPLE",
                      style: TextStyle(
                          fontSize: 10,
                          color: Color.fromRGBO(112, 112, 112, 1)),
                    )
                  ]),
            ),
            Container(
              margin: EdgeInsets.only(top: 68),
              height: 390,
              width: double.infinity,
              decoration: BoxDecoration(
                  image: DecorationImage(
                      image: AssetImage("assets/SVG/back.png"))),
              child: Container(
                height: 390,
                width: 340,
                margin: EdgeInsets.only(left: 20, right: 20),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  color: Colors.white,
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.12),
                      offset: const Offset(
                        3.0,
                        3.0,
                      ),
                      blurRadius: 8.0,
                      spreadRadius: 2.0,
                    ), //BoxShadow
                    BoxShadow(
                      color: Colors.white,
                      offset: const Offset(0.0, 0.0),
                      blurRadius: 0.0,
                      spreadRadius: 0.0,
                    ), //BoxShadow
                  ],
                ),
                child: Form(
                  key: _formKey,
                  child: Column(children: [
                    Container(
                      width: 400,
                      margin:
                          EdgeInsets.symmetric(vertical: 35, horizontal: 40),
                      child: Text(
                        "Log In",
                        textAlign: TextAlign.left,
                        style: TextStyle(
                            fontSize: 26,
                            color: Color.fromRGBO(2, 44, 67, 1),
                            fontWeight: FontWeight.bold),
                      ),
                    ),
                    Container(
                      height: 56,
                      width: 247,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(25),
                        color: Colors.white,
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.12),
                            offset: const Offset(
                              3.0,
                              3.0,
                            ),
                            blurRadius: 8.0,
                            spreadRadius: 2.0,
                          ), //BoxShadow
                          BoxShadow(
                            color: Colors.white,
                            offset: const Offset(0.0, 0.0),
                            blurRadius: 0.0,
                            spreadRadius: 0.0,
                          ), //BoxShadow
                        ],
                      ),
                      child: Row(children: [
                        SizedBox(
                          width: 6,
                        ),
                        Container(
                          height: 50,
                          width: 50,
                          decoration: BoxDecoration(
                              image: DecorationImage(
                                  image: AssetImage("assets/SVG/flag-2x.png"))),
                        ),
                        SizedBox(
                          width: 20,
                        ),
                        Container(
                          child: Center(
                              child: Text(
                            "INDIA +91",
                            style: TextStyle(
                                fontSize: 12,
                                color: Color.fromRGBO(164, 164, 164, 1)),
                          )),
                        ),
                      ]),
                    ),
                    SizedBox(
                      height: 20,
                    ),
                    Container(
                      height: 56,
                      width: 247,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(25),
                        color: Colors.white,
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.12),
                            offset: const Offset(
                              3.0,
                              3.0,
                            ),
                            blurRadius: 8.0,
                            spreadRadius: 2.0,
                          ), //BoxShadow
                          BoxShadow(
                            color: Colors.white,
                            offset: const Offset(0.0, 0.0),
                            blurRadius: 0.0,
                            spreadRadius: 0.0,
                          ), //BoxShadow
                        ],
                      ),
                      child: Center(
                          child: TextFormField(
                        controller: _phone,
                        textAlign: TextAlign.center,
                        keyboardType: TextInputType.phone,
                        decoration: InputDecoration(
                          border: InputBorder.none,
                          hintText: 'Enter Mobile Number',
                        ),
                        validator: (value) {
                          if (value == null || value.isEmpty) {
                            return 'Enter your mobile';
                          } else if (value.length < 10) {
                            return 'Enter 10 digit mobile number';
                          } else if (value.length > 10) {
                            return 'Enter 10 digit mobile number';
                          }
                          return null;
                        },
                        style: TextStyle(
                            fontSize: 15,
                            color: Color.fromRGBO(164, 164, 164, 1)),
                      )),
                    ),
                    SizedBox(
                      height: 40,
                    ),
                    GestureDetector(
                      onTap: () async {
                        if (_formKey.currentState!.validate()) {
                          setState(() {
                            isloading = true;
                          });
                          Map<String, String> data = {
                            'phone': _phone.text,
                            'mob_notification': ftoken.toString()
                          };
                          var response =
                              await networkHandler.post('customer-reg', data);

                          if (response.statusCode == 200) {
                            Map jsonResponse = jsonDecode(response.body);
                            if (jsonResponse['status'] == true) {
                              Fluttertoast.showToast(
                                  msg: jsonResponse['otp'],
                                  toastLength: Toast.LENGTH_SHORT,
                                  gravity: ToastGravity.BOTTOM,
                                  timeInSecForIosWeb: 1,
                                  backgroundColor: themeColor,
                                  textColor: Colors.white,
                                  fontSize: 16.0);
                              Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) => OTPVarification(
                                            mobile: _phone.text,
                                          )));
                            } else {
                              Fluttertoast.showToast(
                                  msg:
                                      "Something went wrong!, please try again..",
                                  toastLength: Toast.LENGTH_SHORT,
                                  gravity: ToastGravity.BOTTOM,
                                  timeInSecForIosWeb: 1,
                                  backgroundColor: themeColor,
                                  textColor: Colors.white,
                                  fontSize: 16.0);
                            }
                          }
                        }
                      },
                      child: isloading == false
                          ? Container(
                              width: 247,
                              height: 56,
                              decoration: BoxDecoration(
                                  color: Colors.yellow,
                                  borderRadius: BorderRadius.circular(25),
                                  border: Border.all(
                                      width: 2, color: Colors.yellow)),
                              child: Center(
                                child: Text(
                                  "GET OTP",
                                  style: TextStyle(
                                      fontSize: 17, color: Colors.white),
                                ),
                              ),
                            )
                          : Container(
                              width: 247,
                              height: 56,
                              decoration: BoxDecoration(
                                  color: Colors.yellow,
                                  borderRadius: BorderRadius.circular(25),
                                  border: Border.all(
                                      width: 2, color: Colors.yellow)),
                              child: Center(
                                  child: CircularProgressIndicator(
                                color: Colors.white,
                              )),
                            ),
                    )
                  ]),
                ),
              ),
            ),
            Center(
              child: Container(
                margin: EdgeInsets.only(
                  top: 50,
                ),
                width: 196,
                child: Text(
                  "Welcome To ChatnFix Discover the Best Solution Easy & Simple",
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 16, color: Colors.black),
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}

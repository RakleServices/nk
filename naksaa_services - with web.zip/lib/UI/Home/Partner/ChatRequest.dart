import 'dart:convert';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:naksaa_services/API/FirebaseMethods.dart';
import 'package:naksaa_services/MainAsset/LoadingIndicator.dart';
import 'package:naksaa_services/Service/CustomerProfileService.dart';
import 'package:naksaa_services/UI/REgister/project%20Assets/constants.dart';
import 'package:naksaa_services/model/CustomerProfileModel.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../../MainAsset/URL.dart';
import '../../../Service/AllVendorService.dart';
import '../../../model/VendorDetailsModel.dart';
import 'ChatWithCustomer.dart';

class IncomingChatRequest extends StatefulWidget {
  String vendorid;

  IncomingChatRequest({super.key, required this.vendorid});

  @override
  State<IncomingChatRequest> createState() => _IncomingChatRequestState();
}

class _IncomingChatRequestState extends State<IncomingChatRequest>
    with WidgetsBindingObserver {
  Map<String, dynamic> userMap = {};
  FirebaseFirestore _firestore = FirebaseFirestore.instance;
  FirebaseAuth _auth = FirebaseAuth.instance;
  bool isloading = false;
  bool isloginloading = false;
  List<Vdatum> results = [];
  var vendorService = AllVendorService();
  var customerService = CustomerProfileService();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    getVendorDetails();
    getUserDetails();
    setStatus("Online");
  }

  Future<List<Vdatum>> getVendorDetails() async {
    print(widget.vendorid);
    var response = await vendorService.viewSingleVendor(widget.vendorid);

    results = VendorDetailsmodel.fromJson(jsonDecode(response)).vdata.toList();
    print(results);
    if (results != null) {
      setState(() {
        isloading = true;
      });
      return results;
    } else {
      throw Exception('Failed to load');
    }
  }

  List<CustomerP?> _customerList = [];
  Future<List<CustomerP?>> getUserDetails() async {
    print(widget.vendorid);
    SharedPreferences pref = await SharedPreferences.getInstance();
    String? phone = pref.getString("phone");
    var response = await customerService.viewCustomerProfile(phone!);

    if (results != null) {
      setState(() {
        _customerList = response!;
        isloading = true;
      });
      return _customerList;
    } else {
      throw Exception('Failed to load');
    }
  }

  String chatRoomId(String user1, String user2) {
    if (user1[0].toLowerCase().codeUnits[0] >
        user2[0].toLowerCase().codeUnits[0]) {
      return '$user1$user2';
    } else {
      return '$user2$user1';
    }
  }

  void setStatus(String status) async {
    await _firestore.collection('users').doc(_auth.currentUser!.uid).update({
      "status": status,
    });
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      setStatus("Online");
    } else {
      setStatus("Offline");
    }
  }

  @override
  Widget build(BuildContext context) {
    return isloading != false
        ? Scaffold(
            backgroundColor: Colors.black,
            body: Container(
              height: 812,
              width: 375,
              decoration: BoxDecoration(
                  color: Colors.black,
                  image: DecorationImage(
                    image: AssetImage("assets/SVG/request.png"),
                    colorFilter: ColorFilter.mode(
                        Colors.black.withOpacity(0.25), BlendMode.dstATop),
                  )),
              child: Column(children: [
                Container(
                  margin: EdgeInsets.only(top: 90),
                  child: Text(
                    "Incoming Chat Request From",
                    style: TextStyle(fontSize: 14, color: Colors.white),
                  ),
                ),
                SizedBox(
                  height: 20,
                ),
                Container(
                  height: 43,
                  width: 118,
                  decoration: BoxDecoration(
                      image: DecorationImage(
                    image: AssetImage("assets/logo.png"),
                  )),
                ),
                SizedBox(
                  height: 144,
                ),
                Container(
                  height: 127,
                  width: 127,
                  decoration: BoxDecoration(
                      border: Border.all(width: 2, color: themeColor),
                      shape: BoxShape.circle,
                      image: DecorationImage(
                          image: NetworkImage(
                              MainUrl + 'vendor-image/' + results[0].photo),
                          fit: BoxFit.fill)),
                ),
                SizedBox(
                  height: 22,
                ),
                Container(
                  child: Text(
                    "${results[0].name}",
                    style: TextStyle(
                        fontSize: 18,
                        color: Colors.white,
                        fontWeight: FontWeight.bold),
                  ),
                ),
                SizedBox(
                  height: 185,
                ),
                isloginloading != true
                    ? GestureDetector(
                        onTap: () async {
                          print(results[0].email);
                          print("${_customerList[0]!.phone}${results[0].id}");
                          setState(() {
                            isloginloading = true;
                          });
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => ChatWithCustomer(
                                      chatRoomId:
                                          "${_customerList[0]!.phone}${results[0].id}",
                                      customer: _customerList,
                                      vdetails: results)));
                          setState(() {
                            isloginloading = false;
                          });
                          // String RoomId =
                          //     chatRoomId(userPhone, widget.vendorid);
                          // print(RoomId);
                          // print(
                          //     '${userEmail}${userPassword}, ${results[0].email}');
                          // loginFirebase(userEmail, userPassword).then((user) {
                          //   if (user != null) {
                          //     _firestore
                          //         .collection("users")
                          //         .where("email", isEqualTo: results[0].email)
                          //         .get()
                          //         .then((value) {
                          //       setState(() {
                          //         userMap = value.docs[0].data();
                          //         // print(userMap);
                          //       });
                          //       setState(() {
                          //         isloginloading = false;
                          //       });

                          //     }).onError((error, stackTrace) {
                          //       setState(() {
                          //         isloginloading = false;
                          //       });
                          //       Fluttertoast.showToast(
                          //           msg:
                          //               "Something went wrong !, Please try again..",
                          //           toastLength: Toast.LENGTH_SHORT,
                          //           gravity: ToastGravity.BOTTOM,
                          //           timeInSecForIosWeb: 1,
                          //           backgroundColor: darkBlue,
                          //           textColor: Colors.white,
                          //           fontSize: 16.0);
                          //     });
                          //   } else {
                          //     setState(() {
                          //       isloginloading = false;
                          //     });
                          //     Fluttertoast.showToast(
                          //         msg:
                          //             "Something went wrong !, Please try again..",
                          //         toastLength: Toast.LENGTH_SHORT,
                          //         gravity: ToastGravity.BOTTOM,
                          //         timeInSecForIosWeb: 1,
                          //         backgroundColor: darkBlue,
                          //         textColor: Colors.white,
                          //         fontSize: 16.0);
                          //   }
                          // });
                        },
                        child: Container(
                          height: 45,
                          width: 167,
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(34),
                              color: themeColor),
                          child: Center(
                            child: Text(
                              "Start Chat",
                              style: TextStyle(
                                  fontSize: 18,
                                  color: blueColor,
                                  fontWeight: FontWeight.bold),
                            ),
                          ),
                        ),
                      )
                    : const LoadingIndicator(),
                const SizedBox(
                  height: 20,
                ),
                const Text(
                  "Reject Chat Request",
                  style: TextStyle(
                      fontSize: 10,
                      color: Colors.white,
                      fontWeight: FontWeight.normal),
                ),
              ]),
            ),
          )
        : const Scaffold(
            backgroundColor: themeColor,
            body: Center(child: LoadingIndicator()),
          );
  }
}

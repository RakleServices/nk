import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/container.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:naksaa_services/MainAsset/LoadingIndicator.dart';
import 'package:naksaa_services/MainAsset/URL.dart';
import 'package:naksaa_services/Service/CustomerOrderService.dart';
import 'package:naksaa_services/UI/Home/ChatScreen.dart';
import 'package:naksaa_services/UI/REgister/project%20Assets/constants.dart';
import 'package:naksaa_services/model/CustomerOrderModel.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../Home/BottomNavigation.dart';

class CustomerOrderScreenForChat extends StatefulWidget {
  const CustomerOrderScreenForChat({super.key});

  @override
  State<CustomerOrderScreenForChat> createState() =>
      _CustomerOrderScreenForChatState();
}

class _CustomerOrderScreenForChatState
    extends State<CustomerOrderScreenForChat> {
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getorder();
    // allVendor = vendorService.viewallVendor();
  }

  List<CustomerOrderdata> _orderdata = [];
  var customerOrderService = CustomerOrderService();
  Future<List<CustomerOrderdata>> getorder() async {
    SharedPreferences pref = await SharedPreferences.getInstance();
    String? uid = pref.getString("uid");
    var response = await customerOrderService.viewCustomerOrder(uid!);
    _orderdata = response;
    return _orderdata;
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.all(20),
      child: Column(children: [
        SizedBox(
            height: 410,
            child: FutureBuilder(
              future: getorder(),
              builder: (BuildContext ctx, AsyncSnapshot<List> item) => item
                      .hasData
                  ? item.data!.length != 0
                      ? ListView.builder(
                          itemCount: item.data!.length,
                          // physics: AlwaysScrollableScrollPhysics(),
                          shrinkWrap: true,
                          itemBuilder: ((context, index) {
                            return _orderdata[index].orderfor == "chat"
                                ? Container(
                                    margin: const EdgeInsets.only(
                                        top: 10, bottom: 10),
                                    padding: const EdgeInsets.all(20),
                                    decoration: BoxDecoration(
                                        color: Colors.white,
                                        borderRadius:
                                            BorderRadius.circular(10)),
                                    child: Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            mainAxisAlignment:
                                                MainAxisAlignment.start,
                                            children: [
                                              Text(
                                                "#Naksa${_orderdata[index].orderid}",
                                                style: const TextStyle(
                                                    fontSize: 12,
                                                    color: textColor,
                                                    fontWeight:
                                                        FontWeight.bold),
                                              ),
                                              const SizedBox(
                                                height: 10,
                                              ),
                                              Text(
                                                "${_orderdata[index].name}",
                                                style: const TextStyle(
                                                    fontSize: 14,
                                                    color: Colors.black,
                                                    fontWeight:
                                                        FontWeight.bold),
                                              ),
                                              const SizedBox(
                                                height: 5,
                                              ),
                                              Text(
                                                "${_orderdata[index].createdat}",
                                                style: const TextStyle(
                                                    fontSize: 12,
                                                    color: textColor,
                                                    fontWeight:
                                                        FontWeight.normal),
                                              ),
                                              const SizedBox(
                                                height: 10,
                                              ),
                                              Text(
                                                "${_orderdata[index].orderstatus}",
                                                style: const TextStyle(
                                                    fontSize: 14,
                                                    color: Colors.green,
                                                    fontWeight:
                                                        FontWeight.bold),
                                              ),
                                              const SizedBox(
                                                height: 10,
                                              ),
                                              Text(
                                                "Order For : ${_orderdata[index].orderfor}",
                                                style: const TextStyle(
                                                    fontSize: 12,
                                                    color: textColor,
                                                    fontWeight:
                                                        FontWeight.normal),
                                              ),
                                              const SizedBox(
                                                height: 5,
                                              ),
                                              Text(
                                                "Rate: ₹ ${_orderdata[index].audicallprice}/mins",
                                                style: const TextStyle(
                                                    fontSize: 12,
                                                    color: textColor,
                                                    fontWeight:
                                                        FontWeight.normal),
                                              ),
                                              const SizedBox(
                                                height: 5,
                                              ),
                                              Text(
                                                "Duration: ${_orderdata[index].completecalltime} minutes",
                                                style: const TextStyle(
                                                    fontSize: 12,
                                                    color: textColor,
                                                    fontWeight:
                                                        FontWeight.normal),
                                              ),
                                              const SizedBox(
                                                height: 5,
                                              ),
                                              Text(
                                                "Deduction: ₹ ${_orderdata[index].callingamount}",
                                                style: const TextStyle(
                                                    fontSize: 12,
                                                    color: textColor,
                                                    fontWeight:
                                                        FontWeight.normal),
                                              ),
                                            ]),
                                        Container(
                                          child: Column(
                                            mainAxisAlignment:
                                                MainAxisAlignment.center,
                                            crossAxisAlignment:
                                                CrossAxisAlignment.center,
                                            children: [
                                              Container(
                                                height: 65,
                                                width: 73,
                                                child: Stack(children: [
                                                  Container(
                                                    height: 65,
                                                    width: 65,
                                                    decoration: BoxDecoration(
                                                        shape: BoxShape.circle,
                                                        // color: Colors.red,
                                                        border: Border.all(
                                                            width: 2,
                                                            color:
                                                                lightblueColor),
                                                        image: DecorationImage(
                                                            image: NetworkImage(
                                                                MainUrl +
                                                                    "vendor-image/" +
                                                                    _orderdata[
                                                                            index]
                                                                        .photo))),
                                                  ),
                                                  Positioned(
                                                      top: 6,
                                                      right: 0,
                                                      child: Container(
                                                        height: 25,
                                                        width: 25,
                                                        decoration: BoxDecoration(
                                                            image: DecorationImage(
                                                                image: AssetImage(
                                                                    "assets/SVG/star2-2x.png"),
                                                                fit: BoxFit
                                                                    .fill)),
                                                      )),
                                                ]),
                                              ),
                                              SizedBox(
                                                height: 10,
                                              ),
                                              Container(
                                                height: 22,
                                                width: 62,
                                                decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            10),
                                                    color: themeColor),
                                                child: Center(
                                                    child: Text(
                                                  "${_orderdata[index].orderfor}",
                                                  style: TextStyle(
                                                      fontWeight:
                                                          FontWeight.bold,
                                                      fontSize: 12,
                                                      color: blueColor),
                                                )),
                                              ),
                                              SizedBox(
                                                height: 6,
                                              ),
                                              Text(
                                                "Wait time - ${_orderdata[index].waittime} m",
                                                style: TextStyle(
                                                    fontSize: 12,
                                                    color: textColor,
                                                    fontWeight:
                                                        FontWeight.normal),
                                              )
                                            ],
                                          ),
                                        )
                                      ],
                                    ),
                                  )
                                : Container();
                          }))
                      : Container(
                          margin: EdgeInsets.all(20),
                          child: Center(
                              child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              const Text(
                                "Oops!",
                                style: TextStyle(
                                    fontSize: 25,
                                    color: Colors.black,
                                    fontWeight: FontWeight.bold),
                              ),
                              const SizedBox(
                                height: 15,
                              ),
                              Text(
                                "You've not taken any call consultations yet!",
                                style: TextStyle(
                                    fontSize: 14,
                                    color: textColor,
                                    fontWeight: FontWeight.bold),
                              ),
                              SizedBox(
                                height: 15,
                              ),
                              Container(
                                height: 60,
                                width: 50,
                                child:
                                    SvgPicture.asset("assets/SVG/phone3.svg"),
                              ),
                              SizedBox(
                                height: 40,
                              ),
                              GestureDetector(
                                onTap: () {
                                  Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) =>
                                              BottomNavigationBarScreen(
                                                pageIndex: 1,
                                              )));
                                },
                                child: Container(
                                  height: 50,
                                  width: 146,
                                  decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(25),
                                      color: themeColor),
                                  child: const Center(
                                      child: Text(
                                    "Search Now",
                                    style:
                                        TextStyle(fontWeight: FontWeight.bold),
                                  )),
                                ),
                              )
                            ],
                          )),
                        )
                  : const LoadingIndicator(),
            ))
      ]),
    );
  }
}

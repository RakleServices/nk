import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:naksaa_services/API/NetworkProvider.dart';
import 'package:naksaa_services/MainAsset/LoadingIndicator.dart';
import 'package:naksaa_services/MainAsset/URL.dart';
import 'package:naksaa_services/Service/AllVendorService.dart';
import 'package:naksaa_services/UI/Home/Partner/ChatRequest.dart';
import 'package:naksaa_services/UI/Home/Partner/VendorProfile.dart';
import 'package:naksaa_services/UI/Home/Utility/rechargeNowUtility.dart';
import 'package:naksaa_services/model/AllVendorModel.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../Service/WalletService.dart';
import '../../model/CustomerWalletModel.dart';
import '../REgister/project Assets/AppBar.dart';
import '../REgister/project Assets/constants.dart';
import '../REgister/project Assets/desktopNavbar.dart';
import 'Partner/VideoCall/OrderSuccessModel.dart';

class ChatMainScreen extends StatefulWidget {
  const ChatMainScreen({super.key});

  @override
  State<ChatMainScreen> createState() => _ChatMainScreenState();
}

class _ChatMainScreenState extends State<ChatMainScreen> {
  List<Datum>? results;
  var vendorService = AllVendorService();

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getdata();
    getWalletAmount();
    // allVendor = vendorService.viewallVendor();
  }

  bool isloading = false;
  List<Walletdatum> _walletList = [];
  var walletService = CustomerWalletService();
  Future<void> getWalletAmount() async {
    SharedPreferences pref = await SharedPreferences.getInstance();
    String? uid = pref.getString("uid");
    var response = await walletService.viewCustomerWallet(uid!);
    if (response != null) {
      setState(() {
        isloading = true;
      });
      _walletList = response;
    }
  }

  var networkHandler = NetworkHandler();
  Future<List<Datum>> getdata() async {
    results = await vendorService.viewallVendor();
    if (results != null) {
      return results!;
    } else {
      throw Exception('Failed to load');
    }
  }

  @override
  Widget build(BuildContext context) {
    Color themeColor = Color.fromRGBO(255, 215, 0, 1);
    Color secondColor = Color.fromRGBO(56, 56, 56, 1);
    return LayoutBuilder(builder: (context, constraints) {
      if (constraints.maxWidth > 1200) {
        return DesktopChatScreen();
      } else if (constraints.maxWidth > 800 && constraints.maxWidth < 1200) {
        return DesktopChatScreen();
      } else {
        return MobileChatScreen();
      }
    });
  }

  Widget MobileChatScreen() {
    return Scaffold(
      appBar: AppBar(
          backgroundColor: Colors.transparent,
          elevation: 0.0,
          toolbarHeight: 140,
          automaticallyImplyLeading: false,
          foregroundColor: Color.fromRGBO(0, 0, 0, 1),
          flexibleSpace: AppBarScreen()),
      body: Container(
        height: 600,
        color: Color.fromRGBO(242, 244, 243, 1),
        child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Container(
                margin: EdgeInsets.all(15),
                child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text("Messaging"),
                      Container(
                        child: Row(children: [
                          Text("Sort By Date"),
                          Icon(Icons.keyboard_arrow_down_outlined)
                        ]),
                      ),
                    ]),
              ),
              Container(
                  height: 482,
                  child: RefreshIndicator(
                    onRefresh: () {
                      print("refreshed");
                      return getdata();
                    },
                    child: FutureBuilder(
                      future: getdata(),
                      builder: (BuildContext ctx, AsyncSnapshot<List> item) =>
                          item.hasData
                              ? item.data!.length != 0
                                  ? ListView.builder(
                                      itemCount: results!.length,
                                      physics: AlwaysScrollableScrollPhysics(),
                                      shrinkWrap: true,
                                      itemBuilder: ((context, index) {
                                        return GestureDetector(
                                          onTap: () {
                                            Navigator.push(
                                                context,
                                                MaterialPageRoute(
                                                    builder: (context) =>
                                                        VendorProfileScreen(
                                                            vid: results![index]
                                                                .id
                                                                .toString())));
                                          },
                                          child: Container(
                                            padding: EdgeInsets.all(10),
                                            height: 134,
                                            margin: EdgeInsets.only(
                                                bottom: 15,
                                                left: 14,
                                                right: 14),
                                            decoration: BoxDecoration(
                                              borderRadius:
                                                  BorderRadius.circular(10),
                                              color: Colors.white,
                                              boxShadow: [
                                                BoxShadow(
                                                  color: Color.fromRGBO(
                                                      0, 0, 0, 0.16),
                                                  offset: const Offset(
                                                    3.0,
                                                    3.0,
                                                  ),
                                                  blurRadius: 6.0,
                                                  spreadRadius: 2.0,
                                                ), //BoxShadow
                                                BoxShadow(
                                                  color: Colors.white,
                                                  offset:
                                                      const Offset(0.0, 0.0),
                                                  blurRadius: 0.0,
                                                  spreadRadius: 0.0,
                                                ), //BoxShadow
                                              ],
                                            ),
                                            child: Row(
                                                mainAxisAlignment:
                                                    MainAxisAlignment.center,
                                                children: [
                                                  Container(
                                                    width: 65,
                                                    child: Column(
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .center,
                                                      children: [
                                                        Container(
                                                          height: 60,
                                                          width: 60,
                                                          decoration: BoxDecoration(
                                                              shape: BoxShape
                                                                  .circle,
                                                              border: Border.all(
                                                                  width: 1,
                                                                  color:
                                                                      themeColor),
                                                              image: DecorationImage(
                                                                  image: NetworkImage(MainUrl +
                                                                      'vendor-image/' +
                                                                      results![
                                                                              index]
                                                                          .photo),
                                                                  fit: BoxFit
                                                                      .cover)),
                                                        ),
                                                        SizedBox(
                                                          height: 12,
                                                        ),
                                                        Container(
                                                          child:
                                                              RatingBarIndicator(
                                                            rating: 4.5,
                                                            itemBuilder:
                                                                (context,
                                                                        index) =>
                                                                    Icon(
                                                              Icons.star,
                                                              color:
                                                                  Colors.amber,
                                                            ),
                                                            itemCount: 5,
                                                            itemSize: 13.0,
                                                            direction:
                                                                Axis.horizontal,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          height: 10,
                                                        ),
                                                        Container(
                                                          child: Center(
                                                              child: Text(
                                                            "734 Votes",
                                                            style: TextStyle(
                                                                fontSize: 9,
                                                                fontWeight:
                                                                    FontWeight
                                                                        .w600),
                                                          )),
                                                        )
                                                      ],
                                                    ),
                                                  ),
                                                  SizedBox(
                                                    width: 24,
                                                  ),
                                                  Container(
                                                    child: Column(
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .center,
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .start,
                                                        children: [
                                                          Text(
                                                            results![index]
                                                                .name,
                                                            style: TextStyle(
                                                                fontSize: 16,
                                                                fontWeight:
                                                                    FontWeight
                                                                        .bold,
                                                                color: Colors
                                                                    .black),
                                                          ),
                                                          SizedBox(
                                                            height: 10,
                                                          ),
                                                          SizedBox(
                                                            width: 150,
                                                            child: Text(
                                                              results![index]
                                                                  .primaryskills,
                                                              overflow:
                                                                  TextOverflow
                                                                      .ellipsis,
                                                              style: TextStyle(
                                                                  fontSize: 13,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .normal,
                                                                  color: Colors
                                                                      .black
                                                                      .withOpacity(
                                                                          0.53)),
                                                            ),
                                                          ),
                                                          SizedBox(
                                                            height: 5,
                                                          ),
                                                          SizedBox(
                                                            width: 150,
                                                            child: Text(
                                                              results![index]
                                                                  .language,
                                                              overflow:
                                                                  TextOverflow
                                                                      .ellipsis,
                                                              style: TextStyle(
                                                                  fontSize: 13,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .normal,
                                                                  color: Colors
                                                                      .black
                                                                      .withOpacity(
                                                                          0.53)),
                                                            ),
                                                          ),
                                                          SizedBox(
                                                            height: 5,
                                                          ),
                                                          Text(
                                                            "${(results![index].enddate.difference(results![index].startdate).inDays)} Days",
                                                            style: TextStyle(
                                                                fontSize: 13,
                                                                fontWeight:
                                                                    FontWeight
                                                                        .normal,
                                                                color: Colors
                                                                    .black
                                                                    .withOpacity(
                                                                        0.53)),
                                                          ),
                                                          SizedBox(
                                                            height: 6,
                                                          ),
                                                          Text(
                                                            "₹ ${results![index].audicallprice}/min",
                                                            style: TextStyle(
                                                                fontSize: 14,
                                                                fontWeight:
                                                                    FontWeight
                                                                        .bold,
                                                                color: Colors
                                                                    .black
                                                                    .withOpacity(
                                                                        1)),
                                                          )
                                                        ]),
                                                  ),
                                                  Container(
                                                    child: Column(
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .spaceBetween,
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .end,
                                                        children: [
                                                          Container(
                                                            height: 40,
                                                            width: 40,
                                                            decoration: BoxDecoration(
                                                                image: DecorationImage(
                                                                    image: AssetImage(
                                                                        "assets/SVG/star2-2x.png"))),
                                                            child: Center(
                                                                child: Padding(
                                                              padding: EdgeInsets
                                                                  .only(
                                                                      bottom:
                                                                          5),
                                                              child: Icon(
                                                                Icons.check,
                                                                color: Colors
                                                                    .white,
                                                                size: 16,
                                                              ),
                                                            )),
                                                          ),
                                                          GestureDetector(
                                                            onTap: () async {
                                                              if (double.parse(
                                                                      _walletList[
                                                                              0]
                                                                          .walletamount) >=
                                                                  100.0) {
                                                                setState(() {
                                                                  isloading =
                                                                      true;
                                                                });
                                                                SharedPreferences
                                                                    pref =
                                                                    await SharedPreferences
                                                                        .getInstance();

                                                                Map<String,
                                                                        String>
                                                                    data = {
                                                                  "userid": pref
                                                                      .getString(
                                                                          "uid")
                                                                      .toString(),
                                                                  "vid": results![
                                                                          index]
                                                                      .id
                                                                      .toString(),
                                                                  "orderfor":
                                                                      "chat",
                                                                  "createdat": DateTime
                                                                          .now()
                                                                      .toString()
                                                                };
                                                                _createOrderForChat(
                                                                    data,
                                                                    results![
                                                                            index]
                                                                        .photo,
                                                                    results![
                                                                            index]
                                                                        .name);
                                                              } else {
                                                                showDialog<
                                                                    void>(
                                                                  context:
                                                                      context,
                                                                  barrierDismissible:
                                                                      false, // user must tap button!
                                                                  builder:
                                                                      (BuildContext
                                                                          context) {
                                                                    return AlertDialog(
                                                                      elevation:
                                                                          0.6,
                                                                      contentPadding: EdgeInsets.only(
                                                                          left:
                                                                              20,
                                                                          right:
                                                                              10,
                                                                          top:
                                                                              5,
                                                                          bottom:
                                                                              5),
                                                                      titlePadding: EdgeInsets.only(
                                                                          left:
                                                                              20,
                                                                          right:
                                                                              10,
                                                                          top:
                                                                              5,
                                                                          bottom:
                                                                              5),
                                                                      shape: RoundedRectangleBorder(
                                                                          borderRadius:
                                                                              BorderRadius.circular(15)),
                                                                      title:
                                                                          Row(
                                                                        mainAxisAlignment:
                                                                            MainAxisAlignment.spaceBetween,
                                                                        children: [
                                                                          const Text(
                                                                              'Recharge Plan'),
                                                                          IconButton(
                                                                            icon:
                                                                                Icon(
                                                                              Icons.close,
                                                                              color: Colors.red,
                                                                            ),
                                                                            onPressed:
                                                                                () {
                                                                              Navigator.of(context).pop();
                                                                            },
                                                                          )
                                                                        ],
                                                                      ),
                                                                      content:
                                                                          RechargeNow(),
                                                                    );
                                                                  },
                                                                );
                                                              }
                                                            },
                                                            child: Container(
                                                              height: 25,
                                                              width: 65,
                                                              decoration: BoxDecoration(
                                                                  borderRadius:
                                                                      BorderRadius
                                                                          .circular(
                                                                              10),
                                                                  color:
                                                                      themeColor),
                                                              child:
                                                                  const Center(
                                                                      child:
                                                                          Text(
                                                                "Chat",
                                                                style: TextStyle(
                                                                    fontSize:
                                                                        12,
                                                                    fontWeight:
                                                                        FontWeight
                                                                            .bold,
                                                                    color: Color
                                                                        .fromRGBO(
                                                                            2,
                                                                            44,
                                                                            67,
                                                                            1)),
                                                              )),
                                                            ),
                                                          )
                                                        ]),
                                                  )
                                                ]),
                                          ),
                                        );
                                      }))
                                  : Center(
                                      child: Text("No Data Found"),
                                    )
                              : Center(
                                  child: CircularProgressIndicator(),
                                ),
                    ),
                  ))
            ]),
      ),
    );
  }

  Widget DesktopChatScreen() {
    return Scaffold(
      appBar: PreferredSize(
        preferredSize: Size(1000, 1000),
        child: NavBar(),
      ),
      body: Container(
        height: 600,
        color: Color.fromRGBO(242, 244, 243, 1),
        child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Container(
                margin: EdgeInsets.all(15),
                child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text("Messaging"),
                      Container(
                        child: Row(children: [
                          Text("Sort By Date"),
                          Icon(Icons.keyboard_arrow_down_outlined)
                        ]),
                      ),
                    ]),
              ),
              Container(
                  height: 482,
                  child: RefreshIndicator(
                    onRefresh: () {
                      print("refreshed");
                      return getdata();
                    },
                    child: FutureBuilder(
                      future: getdata(),
                      builder: (BuildContext ctx, AsyncSnapshot<List> item) => item
                              .hasData
                          ? item.data!.length != 0
                              ? GridView.builder(
                                  gridDelegate:
                                      SliverGridDelegateWithFixedCrossAxisCount(
                                          crossAxisCount: 4,
                                          crossAxisSpacing: 4.0,
                                          childAspectRatio: 2.2,
                                          mainAxisSpacing: 4.0),
                                  itemCount: results!.length,
                                  physics: AlwaysScrollableScrollPhysics(),
                                  shrinkWrap: true,
                                  itemBuilder: ((context, index) {
                                    return GestureDetector(
                                      onTap: () {
                                        Navigator.push(
                                            context,
                                            MaterialPageRoute(
                                                builder: (context) =>
                                                    VendorProfileScreen(
                                                        vid: results![index]
                                                            .id
                                                            .toString())));
                                      },
                                      child: Container(
                                        padding: EdgeInsets.all(10),
                                        margin: EdgeInsets.only(
                                            bottom: 15, left: 14, right: 14),
                                        decoration: BoxDecoration(
                                          borderRadius:
                                              BorderRadius.circular(10),
                                          color: Colors.white,
                                          boxShadow: [
                                            BoxShadow(
                                              color:
                                                  Color.fromRGBO(0, 0, 0, 0.16),
                                              offset: const Offset(
                                                3.0,
                                                3.0,
                                              ),
                                              blurRadius: 6.0,
                                              spreadRadius: 2.0,
                                            ), //BoxShadow
                                            BoxShadow(
                                              color: Colors.white,
                                              offset: const Offset(0.0, 0.0),
                                              blurRadius: 0.0,
                                              spreadRadius: 0.0,
                                            ), //BoxShadow
                                          ],
                                        ),
                                        child: Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.center,
                                            children: [
                                              Container(
                                                width: 80,
                                                child: Column(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.center,
                                                  children: [
                                                    Container(
                                                      height: 70,
                                                      width: 70,
                                                      decoration: BoxDecoration(
                                                          shape:
                                                              BoxShape.circle,
                                                          border: Border.all(
                                                              width: 1,
                                                              color:
                                                                  themeColor),
                                                          image: DecorationImage(
                                                              image: NetworkImage(MainUrl +
                                                                  'vendor-image/' +
                                                                  results![
                                                                          index]
                                                                      .photo),
                                                              fit: BoxFit
                                                                  .cover)),
                                                    ),
                                                    SizedBox(
                                                      height: 12,
                                                    ),
                                                    Container(
                                                      child: RatingBarIndicator(
                                                        rating: 4.5,
                                                        itemBuilder:
                                                            (context, index) =>
                                                                Icon(
                                                          Icons.star,
                                                          color: Colors.amber,
                                                        ),
                                                        itemCount: 5,
                                                        itemSize: 13.0,
                                                        direction:
                                                            Axis.horizontal,
                                                      ),
                                                    ),
                                                    SizedBox(
                                                      height: 10,
                                                    ),
                                                    Container(
                                                      child: Center(
                                                          child: Text(
                                                        "734 Votes",
                                                        style: TextStyle(
                                                            fontSize: 11,
                                                            fontWeight:
                                                                FontWeight
                                                                    .w600),
                                                      )),
                                                    )
                                                  ],
                                                ),
                                              ),
                                              SizedBox(
                                                width: 14,
                                              ),
                                              Container(
                                                child: Column(
                                                    mainAxisAlignment:
                                                        MainAxisAlignment
                                                            .center,
                                                    crossAxisAlignment:
                                                        CrossAxisAlignment
                                                            .start,
                                                    children: [
                                                      Text(
                                                        results![index].name,
                                                        style: TextStyle(
                                                            fontSize: 20,
                                                            fontWeight:
                                                                FontWeight.bold,
                                                            color:
                                                                Colors.black),
                                                      ),
                                                      SizedBox(
                                                        height: 10,
                                                      ),
                                                      SizedBox(
                                                        width: 90,
                                                        child: Text(
                                                          results![index]
                                                              .primaryskills,
                                                          overflow: TextOverflow
                                                              .ellipsis,
                                                          style: TextStyle(
                                                              fontSize: 13,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .normal,
                                                              color: Colors
                                                                  .black
                                                                  .withOpacity(
                                                                      0.53)),
                                                        ),
                                                      ),
                                                      SizedBox(
                                                        height: 5,
                                                      ),
                                                      SizedBox(
                                                        width: 90,
                                                        child: Text(
                                                          results![index]
                                                              .language,
                                                          overflow: TextOverflow
                                                              .ellipsis,
                                                          style: TextStyle(
                                                              fontSize: 13,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .normal,
                                                              color: Colors
                                                                  .black
                                                                  .withOpacity(
                                                                      0.53)),
                                                        ),
                                                      ),
                                                      SizedBox(
                                                        height: 5,
                                                      ),
                                                      Text(
                                                        "${(results![index].enddate.difference(results![index].startdate).inDays)} Days",
                                                        style: TextStyle(
                                                            fontSize: 13,
                                                            fontWeight:
                                                                FontWeight
                                                                    .normal,
                                                            color: Colors.black
                                                                .withOpacity(
                                                                    0.53)),
                                                      ),
                                                      SizedBox(
                                                        height: 6,
                                                      ),
                                                      Text(
                                                        "₹ ${results![index].audicallprice}/min",
                                                        style: TextStyle(
                                                            fontSize: 14,
                                                            fontWeight:
                                                                FontWeight.bold,
                                                            color: Colors.black
                                                                .withOpacity(
                                                                    1)),
                                                      )
                                                    ]),
                                              ),
                                              Container(
                                                child: Column(
                                                    mainAxisAlignment:
                                                        MainAxisAlignment
                                                            .spaceBetween,
                                                    crossAxisAlignment:
                                                        CrossAxisAlignment.end,
                                                    children: [
                                                      Container(
                                                        height: 40,
                                                        width: 40,
                                                        decoration: BoxDecoration(
                                                            image: DecorationImage(
                                                                image: AssetImage(
                                                                    "assets/SVG/star2-2x.png"))),
                                                        child: Center(
                                                            child: Padding(
                                                          padding:
                                                              EdgeInsets.only(
                                                                  bottom: 5),
                                                          child: Icon(
                                                            Icons.check,
                                                            color: Colors.white,
                                                            size: 16,
                                                          ),
                                                        )),
                                                      ),
                                                      GestureDetector(
                                                        onTap: () async {
                                                          if (double.parse(
                                                                  _walletList[0]
                                                                      .walletamount) >=
                                                              100.0) {
                                                            setState(() {
                                                              isloading = true;
                                                            });
                                                            SharedPreferences
                                                                pref =
                                                                await SharedPreferences
                                                                    .getInstance();

                                                            Map<String, String>
                                                                data = {
                                                              "userid": pref
                                                                  .getString(
                                                                      "uid")
                                                                  .toString(),
                                                              "vid": results![
                                                                      index]
                                                                  .id
                                                                  .toString(),
                                                              "orderfor":
                                                                  "chat",
                                                              "createdat":
                                                                  DateTime.now()
                                                                      .toString()
                                                            };
                                                            _createOrderForChat(
                                                                data,
                                                                results![index]
                                                                    .photo,
                                                                results![index]
                                                                    .name);
                                                          } else {
                                                            showDialog<void>(
                                                              context: context,
                                                              barrierDismissible:
                                                                  false, // user must tap button!
                                                              builder:
                                                                  (BuildContext
                                                                      context) {
                                                                return AlertDialog(
                                                                  elevation:
                                                                      0.6,
                                                                  contentPadding:
                                                                      EdgeInsets.only(
                                                                          left:
                                                                              20,
                                                                          right:
                                                                              10,
                                                                          top:
                                                                              5,
                                                                          bottom:
                                                                              5),
                                                                  titlePadding:
                                                                      EdgeInsets.only(
                                                                          left:
                                                                              20,
                                                                          right:
                                                                              10,
                                                                          top:
                                                                              5,
                                                                          bottom:
                                                                              5),
                                                                  shape: RoundedRectangleBorder(
                                                                      borderRadius:
                                                                          BorderRadius.circular(
                                                                              15)),
                                                                  title: Row(
                                                                    mainAxisAlignment:
                                                                        MainAxisAlignment
                                                                            .spaceBetween,
                                                                    children: [
                                                                      const Text(
                                                                          'Recharge Plan'),
                                                                      IconButton(
                                                                        icon:
                                                                            Icon(
                                                                          Icons
                                                                              .close,
                                                                          color:
                                                                              Colors.red,
                                                                        ),
                                                                        onPressed:
                                                                            () {
                                                                          Navigator.of(context)
                                                                              .pop();
                                                                        },
                                                                      )
                                                                    ],
                                                                  ),
                                                                  content:
                                                                      RechargeNow(),
                                                                );
                                                              },
                                                            );
                                                          }
                                                        },
                                                        child: Container(
                                                          height: 25,
                                                          width: 65,
                                                          decoration: BoxDecoration(
                                                              borderRadius:
                                                                  BorderRadius
                                                                      .circular(
                                                                          10),
                                                              color:
                                                                  themeColor),
                                                          child: const Center(
                                                              child: Text(
                                                            "Chat",
                                                            style: TextStyle(
                                                                fontSize: 12,
                                                                fontWeight:
                                                                    FontWeight
                                                                        .bold,
                                                                color: Color
                                                                    .fromRGBO(
                                                                        2,
                                                                        44,
                                                                        67,
                                                                        1)),
                                                          )),
                                                        ),
                                                      )
                                                    ]),
                                              )
                                            ]),
                                      ),
                                    );
                                  }))
                              : Center(
                                  child: Text("No Data Found"),
                                )
                          : Center(
                              child: CircularProgressIndicator(),
                            ),
                    ),
                  ))
            ]),
      ),
    );
  }

  void _createOrderForChat(
      Map<String, String> data, String image, String name) async {
    var response = await networkHandler.post("new-order", data);
    if (response.statusCode == 200) {
      Map jsonResponse = jsonDecode(response.body);
      if (jsonResponse["data"] == "created") {
        setState(() {
          isloading = false;
        });
        showDialog(
          context: context,
          builder: (BuildContext context) => OrderSuccessModel(
            vendorName: name,
            vendorimage: image,
            response: "success",
          ),
        );
        print("Order created succesflly");
      } else {
        setState(() {
          isloading = false;
        });
        showDialog(
          context: context,
          builder: (BuildContext context) => OrderSuccessModel(
            vendorName: name,
            vendorimage: image,
            response: "failed",
          ),
        );
        print("Something went wrong");
      }
    }
  }
}

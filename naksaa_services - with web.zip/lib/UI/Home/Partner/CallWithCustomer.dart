// import 'package:flutter/material.dart';
// import 'package:naksaa_services/API/constants.dart';
// import 'package:naksaa_services/MainAsset/URL.dart';
// import 'package:naksaa_services/UI/REgister/project%20Assets/constants.dart';
// import 'package:naksaa_services/model/VendorAvailabilityModel.dart';
// import 'package:naksaa_services/model/VendorDetailsModel.dart';
// import 'package:permission_handler/permission_handler.dart';
// import 'package:agora_rtc_engine/agora_rtc_engine.dart';

// import '../BottomNavigation.dart';

// class CallWithCustomer extends StatefulWidget {
//   List<Vdatum?> vendorData;
//   String channelName;
//   String token;
//   String uid;
//   CallWithCustomer(
//       {super.key,
//       required this.channelName,
//       required this.token,
//       required this.vendorData,
//       required this.uid});

//   @override
//   State<CallWithCustomer> createState() => _CallWithCustomerState();
// }

// class _CallWithCustomerState extends State<CallWithCustomer> {
//   // uid of the local user

//   int? _remoteUid; // uid of the remote user
//   bool _isJoined = false; // Indicates if the local user has joined the channel
//   late RtcEngine agoraEngine; // Agora engine instance

//   final GlobalKey<ScaffoldMessengerState> scaffoldMessengerKey =
//       GlobalKey<ScaffoldMessengerState>(); // Global key to access the scaffold

//   showMessage(String message) {
//     scaffoldMessengerKey.currentState?.showSnackBar(SnackBar(
//       content: Text(message),
//     ));
//   }

//   @override
//   void initState() {
//     super.initState();
//     // Set up an instance of Agora engine
//     setupVoiceSDKEngine();
//   }

//   Future<void> setupVoiceSDKEngine() async {
//     // retrieve or request microphone permission
//     await [Permission.microphone].request();

//     //create an instance of the Agora engine
//     agoraEngine = createAgoraRtcEngine();
//     await agoraEngine.initialize(const RtcEngineContext(appId: AppId));

//     // Register the event handler
//     agoraEngine.registerEventHandler(
//       RtcEngineEventHandler(
//         onJoinChannelSuccess: (RtcConnection connection, int elapsed) {
//           showMessage(
//               "Local user uid:${connection.localUid} joined the channel");
//           setState(() {
//             _isJoined = true;
//           });
//         },
//         onUserJoined: (RtcConnection connection, int remoteUid, int elapsed) {
//           showMessage("Remote user uid:$remoteUid joined the channel");
//           setState(() {
//             _remoteUid = remoteUid;
//           });
//         },
//         onUserOffline: (RtcConnection connection, int remoteUid,
//             UserOfflineReasonType reason) {
//           showMessage("Remote user uid:$remoteUid left the channel");
//           setState(() {
//             _remoteUid = null;
//           });
//         },
//       ),
//     );
//   }

//   void join() async {
//     // Set channel options including the client role and channel profile
//     ChannelMediaOptions options = const ChannelMediaOptions(
//       clientRoleType: ClientRoleType.clientRoleBroadcaster,
//       channelProfile: ChannelProfileType.channelProfileCommunication,
//     );

//     await agoraEngine.joinChannel(
//       token: widget.token,
//       channelId: widget.channelName,
//       options: options,
//       uid: int.parse(widget.uid),
//     );
//   }

//   bool mutecall = false;
//   void _onmute(bool sts) {
//     agoraEngine.muteLocalAudioStream(sts);
//   }

//   bool ishold = false;
//   void onhold(bool newval) {
//     agoraEngine.muteAllRemoteAudioStreams(newval);
//     agoraEngine.muteLocalAudioStream(newval);
//     agoraEngine.muteAllRemoteAudioStreams(newval);
//   }

//   bool isSwitched = false;
//   void _onHandsFree(bool newValue) {
//     agoraEngine.setDefaultAudioRouteToSpeakerphone(
//         false); // Disables the default audio route.
//     agoraEngine.setEnableSpeakerphone(
//         newValue); // Enables or disables the speakerphone temporarily.
//   }

//   void leave() async {
//     setState(() {
//       _isJoined = false;
//       _remoteUid = null;
//     });
//     await agoraEngine.leaveChannel();
//     Navigator.push(
//         context,
//         MaterialPageRoute(
//             builder: (context) => BottomNavigationBarScreen(pageIndex: 0)));
//   }

//   // Clean up the resources when you leave
//   @override
//   void dispose() async {
//     await agoraEngine.leaveChannel();
//     super.dispose();
//   }

//   Widget _status() {
//     String statusText;

//     if (!_isJoined)
//       statusText = 'Join a channel';
//     else if (_remoteUid == null)
//       statusText = 'Waiting for a remote user to join...';
//     else
//       statusText = 'Connected to remote user, uid:$_remoteUid';

//     return Text(
//       statusText,
//     );
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       backgroundColor: themeColor,
//       appBar: AppBar(
//           backgroundColor: Colors.transparent,
//           elevation: 0.0,
//           toolbarHeight: 50,
//           automaticallyImplyLeading: false,
//           foregroundColor: Color.fromRGBO(0, 0, 0, 1),
//           flexibleSpace: Container(
//             margin: EdgeInsets.only(top: 44, left: 15, right: 14),
//             child: Column(
//               children: [
//                 Row(
//                   crossAxisAlignment: CrossAxisAlignment.start,
//                   mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                   children: [
//                     Icon(
//                       Icons.arrow_back,
//                       size: 25,
//                     ),
//                     Container(
//                       height: 24,
//                       width: 60,
//                       decoration: BoxDecoration(
//                           border: Border.all(
//                               width: 1, color: Color.fromRGBO(47, 47, 47, 1)),
//                           borderRadius: BorderRadius.circular(5)),
//                       child: Center(
//                           child: Text(
//                         "END",
//                         style: TextStyle(
//                             fontSize: 13, color: Color.fromRGBO(47, 47, 47, 1)),
//                       )),
//                     ),
//                   ],
//                 ),
//               ],
//             ),
//           )),
//       body: Container(
//         height: 700,
//         child: Stack(
//           children: [
//             Positioned(
//                 bottom: 0,
//                 child: Container(
//                   height: 283,
//                   width: 360,
//                   decoration: BoxDecoration(
//                     borderRadius: BorderRadius.only(
//                         topLeft: Radius.circular(20),
//                         topRight: Radius.circular(20)),
//                     color: blueColor,
//                   ),
//                 )),
//             Container(
//               // height: 815,
//               width: 375,
//               margin: EdgeInsets.only(top: 10, left: 15, right: 14),
//               child: SingleChildScrollView(
//                 child: Container(
//                   child: Column(children: [
//                     Container(
//                       padding: EdgeInsets.all(10),
//                       height: 623,
//                       width: 330,
//                       decoration: BoxDecoration(
//                           borderRadius: BorderRadius.circular(20),
//                           color: Colors.white),
//                       child: Column(children: [
//                         Container(height: 40, child: Center(child: _status())),
//                         SizedBox(
//                           height: 53,
//                         ),
//                         GestureDetector(
//                           onTap: () {
//                             join();
//                           },
//                           child: Container(
//                             height: 177,
//                             width: 177,
//                             decoration: BoxDecoration(
//                                 border: Border.all(width: 2, color: themeColor),
//                                 shape: BoxShape.circle,
//                                 image: DecorationImage(
//                                     image: NetworkImage(MainUrl +
//                                         'vendor-image/' +
//                                         widget.vendorData[0]!.photo),
//                                     fit: BoxFit.fill)),
//                           ),
//                         ),
//                         SizedBox(
//                           height: 18,
//                         ),
//                         Container(
//                           child: Text(
//                             "Aditya Roy",
//                             style: TextStyle(
//                                 fontSize: 18,
//                                 color: Colors.black,
//                                 fontWeight: FontWeight.bold),
//                           ),
//                         ),
//                         SizedBox(
//                           height: 8,
//                         ),
//                         Container(
//                           child: Text(
//                             "Numerology, Loshu Grid",
//                             style: TextStyle(
//                                 fontSize: 13,
//                                 color: Colors.black,
//                                 fontWeight: FontWeight.normal),
//                           ),
//                         ),
//                         SizedBox(
//                           height: 8,
//                         ),
//                         Container(
//                           child: Text(
//                             "03:04",
//                             style: TextStyle(
//                                 fontSize: 13,
//                                 color: Colors.black,
//                                 fontWeight: FontWeight.normal),
//                           ),
//                         ),
//                         SizedBox(
//                           height: 34,
//                         ),
//                         GestureDetector(
//                           onTap: () {
//                             setState(() {
//                               mutecall = !mutecall;
//                             });
//                             _onmute(mutecall);
//                           },
//                           child: Container(
//                             child: Row(
//                                 mainAxisAlignment:
//                                     MainAxisAlignment.spaceEvenly,
//                                 children: [
//                                   Container(
//                                     child: Column(children: [
//                                       Container(
//                                         height: 71,
//                                         width: 71,
//                                         decoration: BoxDecoration(
//                                           color: mutecall != true
//                                               ? themeColor
//                                               : Colors.red,
//                                           shape: BoxShape.circle,
//                                         ),
//                                         child: Center(
//                                             child: Icon(
//                                           Icons.mic,
//                                           size: 25,
//                                           color: mutecall != true
//                                               ? Colors.black
//                                               : Colors.white,
//                                         )),
//                                       ),
//                                       SizedBox(
//                                         height: 9,
//                                       ),
//                                       Text(
//                                         "Mute",
//                                         style: TextStyle(
//                                             fontSize: 10,
//                                             fontWeight: FontWeight.bold),
//                                       )
//                                     ]),
//                                   ),
//                                   GestureDetector(
//                                     onTap: () {
//                                       setState(() {
//                                         ishold = !ishold;
//                                       });
//                                       onhold(ishold);
//                                     },
//                                     child: Container(
//                                       child: Column(children: [
//                                         Container(
//                                           height: 71,
//                                           width: 71,
//                                           decoration: BoxDecoration(
//                                               color: ishold != true
//                                                   ? themeColor
//                                                   : Colors.red,
//                                               shape: BoxShape.circle),
//                                           child: Center(
//                                               child: Icon(
//                                             Icons.pause,
//                                             size: 25,
//                                             color: ishold != true
//                                                 ? Colors.black
//                                                 : Colors.white,
//                                           )),
//                                         ),
//                                         SizedBox(
//                                           height: 9,
//                                         ),
//                                         Text(
//                                           "Hold",
//                                           style: TextStyle(
//                                               fontSize: 10,
//                                               fontWeight: FontWeight.bold),
//                                         )
//                                       ]),
//                                     ),
//                                   ),
//                                   GestureDetector(
//                                     onTap: () {
//                                       setState(() {
//                                         isSwitched = !isSwitched;
//                                       });
//                                       _onHandsFree(isSwitched);
//                                     },
//                                     child: Container(
//                                       child: Column(children: [
//                                         Container(
//                                           height: 71,
//                                           width: 71,
//                                           decoration: BoxDecoration(
//                                               color: isSwitched != true
//                                                   ? themeColor
//                                                   : Colors.red,
//                                               shape: BoxShape.circle),
//                                           child: Center(
//                                               child: Icon(
//                                             Icons.volume_up,
//                                             size: 25,
//                                             color: isSwitched != true
//                                                 ? Colors.black
//                                                 : Colors.white,
//                                           )),
//                                         ),
//                                         SizedBox(
//                                           height: 9,
//                                         ),
//                                         Text(
//                                           "Speaker",
//                                           style: TextStyle(
//                                               fontSize: 10,
//                                               fontWeight: FontWeight.bold),
//                                         )
//                                       ]),
//                                     ),
//                                   ),
//                                 ]),
//                           ),
//                         ),
//                         SizedBox(
//                           height: 30,
//                         ),
//                         GestureDetector(
//                           onTap: () {
//                             leave();
//                           },
//                           child: Container(
//                             child: Column(children: [
//                               Container(
//                                 height: 71,
//                                 width: 71,
//                                 decoration: BoxDecoration(
//                                     color: Colors.red, shape: BoxShape.circle),
//                                 child: Center(
//                                     child: Icon(
//                                   Icons.call,
//                                   size: 25,
//                                   color: Colors.white,
//                                 )),
//                               ),
//                               SizedBox(
//                                 height: 9,
//                               ),
//                               Text(
//                                 "End",
//                                 style: TextStyle(
//                                     fontSize: 10, fontWeight: FontWeight.bold),
//                               )
//                             ]),
//                           ),
//                         ),
//                       ]),
//                     ),
//                   ]),
//                 ),
//               ),
//             ),
//           ],
//         ),
//       ),
//     );
//   }
// }

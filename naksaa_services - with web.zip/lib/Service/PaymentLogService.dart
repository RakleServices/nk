import 'dart:convert';

import 'package:http/http.dart' as http;
import 'package:naksaa_services/MainAsset/URL.dart';
import 'package:naksaa_services/model/PaymentLogs.dart';

class CustomerPaymentLogService {
  Future<List<Paymentlog>?> viewCustomerPaymentLog(String uid) async {
    var client = http.Client();
    var uri = Uri.parse(BaseUrl + 'payment-logs/${uid}');
    var response = await client.get(uri);
    if (response.statusCode == 200) {
      var json = response.body;
      print(json);
      // print(json);
      return CustomerPaymentLogsModel.fromJson(jsonDecode(json))
          .paymentlog
          .toList();
    } else {
      throw Exception('failed to load data');
    }
  }
}

import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:image_picker/image_picker.dart';
import 'package:naksaa_services/API/NetworkProvider.dart';
import 'package:naksaa_services/MainAsset/LoadingIndicator.dart';
import 'package:naksaa_services/MainAsset/URL.dart';
import 'package:naksaa_services/Service/CustomerProfileService.dart';
import 'package:naksaa_services/UI/Home/BottomNavigation.dart';
import 'package:naksaa_services/UI/REgister/project%20Assets/constants.dart';
import 'package:intl/intl.dart';
import 'package:naksaa_services/model/CustomerProfileModel.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;

class CustomerProfile extends StatefulWidget {
  const CustomerProfile({super.key});

  @override
  State<CustomerProfile> createState() => _CustomerProfileState();
}

class _CustomerProfileState extends State<CustomerProfile> {
  TextEditingController name = TextEditingController();
  TextEditingController email = TextEditingController();
  TextEditingController dob = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  var networkHandler = NetworkHandler();
  bool isloading = false;

  @override
  void initState() {
    // TODO: implement initState
    // dob.text = "";
    super.initState();
    getProfileDetails();
  }

  bool isdataloading = false;
  List<CustomerP> _customerList = [];
  var customerService = CustomerProfileService();
  Future<void> getProfileDetails() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    var phone = prefs.getString("phone");
    var response = await customerService.viewCustomerProfile(phone.toString());
    if (response != null) {
      setState(() {
        isdataloading = true;
        _customerList = response;
        name.text = _customerList[0].name.toString();
        dob.text = _customerList[0].dob;
        email.text = _customerList[0].email;
        gender = _customerList[0].gender;
      });
    } else {
      throw Exception("Failed to load data");
    }
  }

  @override
  Widget build(BuildContext context) {
    return isdataloading != false
        ? Scaffold(
            backgroundColor: themeColor,
            appBar: AppBar(
                backgroundColor: Colors.transparent,
                elevation: 0.0,
                toolbarHeight: 180,
                automaticallyImplyLeading: false,
                foregroundColor: const Color.fromRGBO(0, 0, 0, 1),
                flexibleSpace: Container(
                  margin: EdgeInsets.only(top: 44, left: 15, right: 14),
                  child: Column(
                    children: [
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          IconButton(
                            onPressed: () {
                              Navigator.pop(context);
                            },
                            icon: const Icon(
                              Icons.arrow_back,
                              size: 25,
                              color: darkBlue,
                            ),
                          ),
                          _customerList[0].photo != null
                              ? Container(
                                  height: 93,
                                  width: 93,
                                  decoration: BoxDecoration(
                                      shape: BoxShape.circle,
                                      color: Color.fromRGBO(246, 87, 15, 1),
                                      image: DecorationImage(
                                          image: NetworkImage(MainUrl +
                                              'customer-image/${_customerList[0].photo}'),
                                          fit: BoxFit.cover)),
                                )
                              : Container(
                                  height: 93,
                                  width: 105,
                                  child: Stack(children: [
                                    Container(
                                      height: 93,
                                      width: 93,
                                      decoration: BoxDecoration(
                                          shape: BoxShape.circle,
                                          color:
                                              Color.fromRGBO(246, 87, 15, 1)),
                                      child: Center(
                                          child: Icon(
                                        Icons.person,
                                        size: 40,
                                        color: Colors.white,
                                      )),
                                    ),
                                    Positioned(
                                        bottom: 5,
                                        right: 3,
                                        child: IconButton(
                                          onPressed: () {
                                            showModalBottomSheet(
                                                shape: RoundedRectangleBorder(
                                                  borderRadius:
                                                      BorderRadius.only(
                                                          topLeft:
                                                              Radius.circular(
                                                                  20),
                                                          topRight:
                                                              Radius.circular(
                                                                  20)),
                                                ),
                                                backgroundColor: themeColor,
                                                context: context,
                                                builder: (builder) =>
                                                    bottomSheet());
                                          },
                                          icon: Icon(
                                            Icons.camera_alt,
                                            size: 30,
                                            color: Colors.white,
                                          ),
                                        ))
                                  ]),
                                ),
                          IconButton(
                            onPressed: () async {
                              SharedPreferences prefs =
                                  await SharedPreferences.getInstance();
                              prefs.clear();
                              Navigator.pushReplacement(context,
                                  MaterialPageRoute(builder: (_) {
                                return BottomNavigationBarScreen(
                                  pageIndex: 0,
                                );
                              }));
                            },
                            icon: const Icon(
                              Icons.logout_outlined,
                              size: 25,
                              color: Colors.red,
                            ),
                          ),
                        ],
                      ),
                      SizedBox(
                        height: 5,
                      ),
                      Text(
                        "${_customerList[0].name}",
                        style: TextStyle(
                            fontSize: 17,
                            color: Colors.white,
                            fontWeight: FontWeight.bold),
                      ),
                      Text(
                        " +91-${_customerList[0].phone}",
                        style: TextStyle(
                            fontSize: 14,
                            color: Colors.white,
                            fontWeight: FontWeight.bold),
                      ),
                      SizedBox(
                        height: 8,
                      ),
                      Text(
                        "Personal Details",
                        style: TextStyle(
                            fontSize: 12,
                            color: Colors.black,
                            fontWeight: FontWeight.bold),
                      )
                    ],
                  ),
                )),
            body: SizedBox(
              height: 700,
              child: Stack(
                children: [
                  Positioned(
                      bottom: 0,
                      child: Container(
                        height: 443,
                        width: 360,
                        decoration: const BoxDecoration(
                          borderRadius: BorderRadius.only(
                              topLeft: Radius.circular(20),
                              topRight: Radius.circular(20)),
                          color: blueColor,
                        ),
                      )),
                  Container(
                    // height: 815,
                    width: 375,
                    margin: const EdgeInsets.only(top: 10, left: 15, right: 14),
                    child: SingleChildScrollView(
                      child: Column(children: [
                        Container(
                          padding: const EdgeInsets.all(24),
                          height: 440,
                          width: 330,
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(20),
                              color: Colors.white),
                          child: Form(
                            key: _formKey,
                            child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  const Text(
                                    "Name",
                                    style: TextStyle(
                                        fontSize: 10,
                                        color:
                                            Color.fromRGBO(113, 123, 123, 1)),
                                  ),
                                  const SizedBox(
                                    height: 10,
                                  ),
                                  Container(
                                    height: 42,
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 10),
                                    decoration: BoxDecoration(boxShadow: const [
                                      BoxShadow(
                                        color: Color.fromRGBO(0, 0, 0, 0.16),
                                        offset: Offset(
                                          3.0,
                                          3.0,
                                        ),
                                        blurRadius: 6.0,
                                        spreadRadius: 2.0,
                                      ), //BoxShadow
                                      BoxShadow(
                                        color: Colors.white,
                                        offset: Offset(0.0, 0.0),
                                        blurRadius: 0.0,
                                        spreadRadius: 0.0,
                                      ), //BoxShadow
                                    ], borderRadius: BorderRadius.circular(10)),
                                    child: TextFormField(
                                      controller: name,
                                      decoration: const InputDecoration(
                                          border: InputBorder.none),
                                      style: const TextStyle(
                                          fontSize: 12,
                                          color: Colors.black,
                                          fontWeight: FontWeight.bold),
                                      validator: (value) {
                                        if (value == null || value.isEmpty) {
                                          return 'Please enter name';
                                        }
                                        return null;
                                      },
                                    ),
                                  ),
                                  const SizedBox(
                                    height: 20,
                                  ),
                                  const Text(
                                    "Email",
                                    style: TextStyle(
                                        fontSize: 10,
                                        color:
                                            Color.fromRGBO(113, 123, 123, 1)),
                                  ),
                                  const SizedBox(
                                    height: 10,
                                  ),
                                  Container(
                                    height: 42,
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 10),
                                    decoration: BoxDecoration(boxShadow: const [
                                      BoxShadow(
                                        color: Color.fromRGBO(0, 0, 0, 0.16),
                                        offset: Offset(
                                          3.0,
                                          3.0,
                                        ),
                                        blurRadius: 6.0,
                                        spreadRadius: 2.0,
                                      ), //BoxShadow
                                      BoxShadow(
                                        color: Colors.white,
                                        offset: Offset(0.0, 0.0),
                                        blurRadius: 0.0,
                                        spreadRadius: 0.0,
                                      ), //BoxShadow
                                    ], borderRadius: BorderRadius.circular(10)),
                                    child: TextFormField(
                                      controller: email,
                                      decoration: const InputDecoration(
                                          border: InputBorder.none),
                                      style: const TextStyle(
                                          fontSize: 12,
                                          color: Colors.black,
                                          fontWeight: FontWeight.bold),
                                      validator: (value) {
                                        if (value == null || value.isEmpty) {
                                          return 'Please enter email';
                                        }
                                        return null;
                                      },
                                    ),
                                  ),
                                  const SizedBox(
                                    height: 20,
                                  ),
                                  const Text(
                                    "Date Of Birth",
                                    style: TextStyle(
                                        fontSize: 10,
                                        color:
                                            Color.fromRGBO(113, 123, 123, 1)),
                                  ),
                                  const SizedBox(
                                    height: 10,
                                  ),
                                  Container(
                                    height: 42,
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 10),
                                    decoration: BoxDecoration(boxShadow: const [
                                      BoxShadow(
                                        color: Color.fromRGBO(0, 0, 0, 0.16),
                                        offset: Offset(
                                          3.0,
                                          3.0,
                                        ),
                                        blurRadius: 6.0,
                                        spreadRadius: 2.0,
                                      ), //BoxShadow
                                      BoxShadow(
                                        color: Colors.white,
                                        offset: Offset(0.0, 0.0),
                                        blurRadius: 0.0,
                                        spreadRadius: 0.0,
                                      ), //BoxShadow
                                    ], borderRadius: BorderRadius.circular(10)),
                                    child: TextFormField(
                                      controller: dob,
                                      readOnly: true,
                                      onTap: () async {
                                        DateTime? pickedDate =
                                            await showDatePicker(
                                                context: context,
                                                initialDate: DateTime.now(),
                                                firstDate: DateTime(
                                                    2000), //DateTime.now() - not to allow to choose before today.
                                                lastDate: DateTime(2101));

                                        if (pickedDate != null) {
                                          print(
                                              pickedDate); //pickedDate output format => 2021-03-10 00:00:00.000
                                          String formattedDate =
                                              DateFormat('yyyy-MM-dd')
                                                  .format(pickedDate);
                                          print(
                                              formattedDate); //formatted date output using intl package =>  2021-03-16
                                          //you can implement different kind of Date Format here according to your requirement

                                          setState(() {
                                            dob.text =
                                                formattedDate; //set output date to TextField value.
                                          });
                                        } else {
                                          print("Date is not selected");
                                        }
                                      },
                                      decoration: const InputDecoration(
                                        border: InputBorder.none,
                                        icon: Icon(Icons.calendar_today),
                                      ),
                                      style: const TextStyle(
                                          fontSize: 12,
                                          color: Colors.black,
                                          fontWeight: FontWeight.bold),
                                      validator: (value) {
                                        if (value == null || value.isEmpty) {
                                          return 'Choose Date';
                                        }
                                      },
                                    ),
                                  ),
                                  const SizedBox(
                                    height: 20,
                                  ),
                                  const Text(
                                    "Gender",
                                    style: TextStyle(
                                        fontSize: 10,
                                        color:
                                            Color.fromRGBO(113, 123, 123, 1)),
                                  ),
                                  const SizedBox(
                                    height: 10,
                                  ),
                                  Row(
                                    children: [
                                      SizedBox(
                                        width: 120,
                                        child: RadioListTile(
                                          title: const Text(
                                            "Male",
                                            style: TextStyle(
                                                fontSize: 12,
                                                color: Colors.black,
                                                fontWeight: FontWeight.bold),
                                          ),
                                          value: "male",
                                          groupValue: gender,
                                          onChanged: (value) {
                                            setState(() {
                                              gender = value.toString();
                                            });
                                          },
                                        ),
                                      ),
                                      Container(
                                        width: 130,
                                        child: RadioListTile(
                                          title: const Text(
                                            "Female",
                                            style: TextStyle(
                                                fontSize: 12,
                                                color: Colors.black,
                                                fontWeight: FontWeight.bold),
                                          ),
                                          value: "female",
                                          groupValue: gender,
                                          onChanged: (value) {
                                            setState(() {
                                              gender = value.toString();
                                            });
                                          },
                                        ),
                                      )
                                    ],
                                  ),
                                  const SizedBox(
                                    height: 20,
                                  ),
                                  GestureDetector(
                                    onTap: () async {
                                      if (_formKey.currentState!.validate()) {
                                        SharedPreferences prefs =
                                            await SharedPreferences
                                                .getInstance();
                                        var phone = prefs.getString("phone");
                                        setState(() {
                                          isloading = true;
                                        });
                                        Map<String, String> data = {
                                          'name': name.text,
                                          'email': email.text,
                                          'dob': dob.text,
                                          'gender': gender,
                                          'transdate': DateTime.now().toString()
                                        };
                                        var response =
                                            await networkHandler.post(
                                                'customer-profile/${phone}',
                                                data);

                                        if (response.statusCode == 200) {
                                          setState(() {
                                            isloading = false;
                                          });
                                          Map jsonResponse =
                                              jsonDecode(response.body);
                                          if (jsonResponse['status'] == true) {
                                            Fluttertoast.showToast(
                                                msg:
                                                    "Profile Updated Succesfully",
                                                toastLength: Toast.LENGTH_SHORT,
                                                gravity: ToastGravity.BOTTOM,
                                                timeInSecForIosWeb: 1,
                                                backgroundColor: themeColor,
                                                textColor: Colors.white,
                                                fontSize: 16.0);
                                            Navigator.push(
                                                context,
                                                MaterialPageRoute(
                                                    builder: (context) =>
                                                        CustomerProfile()));
                                          } else {
                                            Fluttertoast.showToast(
                                                msg:
                                                    "Something went wrong!, PLease try again..",
                                                toastLength: Toast.LENGTH_SHORT,
                                                gravity: ToastGravity.BOTTOM,
                                                timeInSecForIosWeb: 1,
                                                backgroundColor: themeColor,
                                                textColor: Colors.white,
                                                fontSize: 16.0);
                                          }
                                        }
                                      }
                                    },
                                    child: Container(
                                      height: 38,
                                      decoration: BoxDecoration(
                                          borderRadius:
                                              BorderRadius.circular(10),
                                          color: themeColor),
                                      child: const Center(
                                          child: Text(
                                        "Submit",
                                        style: TextStyle(
                                            fontSize: 14,
                                            color: Colors.white,
                                            fontWeight: FontWeight.bold),
                                      )),
                                    ),
                                  )
                                ]),
                          ),
                        ),
                      ]),
                    ),
                  ),
                ],
              ),
            ),
          )
        : const Scaffold(
            backgroundColor: themeColor,
            body: Center(child: LoadingIndicator()));
  }

  String gender = "male";
  PickedFile? _imageFile;
  final ImagePicker _picker = ImagePicker();
  bool imgsts = false;

  Widget bottomSheet() {
    return Container(
      height: 120.0,
      width: MediaQuery.of(context).size.width,
      margin: EdgeInsets.symmetric(horizontal: 20, vertical: 20),
      child: Column(
        children: [
          Text(
            "Choose profile Photo",
            style: TextStyle(fontSize: 20.0),
          ),
          SizedBox(
            height: 20,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              IconButton(
                onPressed: () {
                  takePhoto(ImageSource.camera);
                },
                icon: Icon(
                  Icons.camera,
                  color: Colors.white,
                ),
              ),
              IconButton(
                onPressed: () {
                  takePhoto(ImageSource.gallery);
                },
                icon: Icon(
                  Icons.image,
                  color: Colors.white,
                ),
              ),
            ],
          ),
          SizedBox(
            height: 20,
          )
        ],
      ),
    );
  }

  void takePhoto(ImageSource source) async {
    final pickedFile = await _picker.getImage(source: source);
    setState(() {
      imgsts = true;
      _imageFile = pickedFile;
    });
    Navigator.pop(context);
    var uri = Uri.parse(BaseUrl + 'customer-pic/${_customerList[0].phone}');
    var request = http.MultipartRequest('POST', uri);
    http.MultipartFile multipartFile =
        await http.MultipartFile.fromPath('photo', _imageFile!.path);
    request.files.add(multipartFile);
    request.send().then((response) {
      print("Uploaded!");
      Fluttertoast.showToast(
          msg: "Profile Photo Updated Succesfully",
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.BOTTOM,
          timeInSecForIosWeb: 1,
          backgroundColor: themeColor,
          textColor: Colors.white,
          fontSize: 16.0);

      print(response.statusCode);
    }).catchError((error) {
      Fluttertoast.showToast(
          msg: "Something went wrong!, Please try again..",
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.BOTTOM,
          timeInSecForIosWeb: 1,
          backgroundColor: themeColor,
          textColor: Colors.white,
          fontSize: 16.0);
    });
  }
}

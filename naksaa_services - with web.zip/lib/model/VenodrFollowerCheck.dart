// To parse this JSON data, do
//
//     final vendorFollowerCheck = vendorFollowerCheckFromJson(jsonString);

import 'package:meta/meta.dart';
import 'dart:convert';

VendorFollowerCheck vendorFollowerCheckFromJson(String str) =>
    VendorFollowerCheck.fromJson(json.decode(str));

String vendorFollowerCheckToJson(VendorFollowerCheck data) =>
    json.encode(data.toJson());

class VendorFollowerCheck {
  VendorFollowerCheck({
    required this.rowsCount,
    required this.status,
    required this.data,
  });

  int rowsCount;
  bool status;
  List<FollowDatum> data;

  factory VendorFollowerCheck.fromJson(Map<String, dynamic> json) =>
      VendorFollowerCheck(
        rowsCount: json["rowsCount"],
        status: json["status"],
        data: List<FollowDatum>.from(
            json["data"].map((x) => FollowDatum.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "rowsCount": rowsCount,
        "status": status,
        "data": List<dynamic>.from(data.map((x) => x.toJson())),
      };
}

class FollowDatum {
  FollowDatum({
    required this.id,
    required this.customerid,
    required this.vendorid,
    required this.follow,
  });

  int id;
  int customerid;
  int vendorid;
  String follow;

  factory FollowDatum.fromJson(Map<String, dynamic> json) => FollowDatum(
        id: json["id"],
        customerid: json["customerid"],
        vendorid: json["vendorid"],
        follow: json["follow"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "customerid": customerid,
        "vendorid": vendorid,
        "follow": follow,
      };
}

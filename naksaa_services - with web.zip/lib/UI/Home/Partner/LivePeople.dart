import 'package:flutter/material.dart';
import 'package:naksaa_services/UI/Home/Partner/VideoCall/VideoCallWithVendor.dart';

import '../VideoCallScreen.dart';

class LivePeople extends StatefulWidget {
  const LivePeople({super.key});

  @override
  State<LivePeople> createState() => _LivePeopleState();
}

class _LivePeopleState extends State<LivePeople> {
  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, constraints) {
      if (constraints.maxWidth > 1200) {
        return DesktopLiveScreen();
      } else if (constraints.maxWidth > 800 && constraints.maxWidth < 1200) {
        return DesktopLiveScreen();
      } else {
        return MobileLiveScreen();
      }
    });
  }

  Widget MobileLiveScreen() {
    return Container(
      height: 140,
      child: ListView.builder(
          itemCount: 10,
          scrollDirection: Axis.horizontal,
          itemBuilder: ((context, index) {
            return InkWell(
              onTap: () {
                // Navigator.push(
                //     context,
                //     MaterialPageRoute(
                //         builder: (context) => VideoCallWithVendor()));
              },
              child: Container(
                margin: EdgeInsets.only(right: 10),
                child: Stack(alignment: Alignment.center, children: [
                  Container(
                    height: 140,
                    width: 100,
                    decoration: BoxDecoration(
                        color: Colors.yellow,
                        borderRadius: BorderRadius.circular(10),
                        image: DecorationImage(
                            image: NetworkImage(
                                "https://www.tikli.in/wp-content/uploads/2022/02/rashmika-mandanna-10.jpg"),
                            fit: BoxFit.fill)),
                  ),
                  Positioned(
                      top: 85,
                      left: 30,
                      child: Container(
                        padding:
                            EdgeInsets.symmetric(vertical: 2, horizontal: 5),
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(5),
                            color: Color.fromRGBO(56, 56, 56, 1)
                                .withOpacity(0.55)),
                        child: Row(
                          children: [
                            Container(
                              height: 8,
                              width: 8,
                              decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: Color.fromRGBO(36, 220, 55, 1)),
                            ),
                            SizedBox(
                              width: 5,
                            ),
                            Text(
                              "Live",
                              style: TextStyle(fontSize: 10),
                            ),
                          ],
                        ),
                      )),
                  Positioned(
                      top: 105,
                      // left: 10,
                      child: Container(
                        child: Text(
                          "Rashmika Gautam",
                          style: TextStyle(
                              fontSize: 11, fontWeight: FontWeight.bold),
                        ),
                      ))
                ]),
              ),
            );
          })),
    );
  }

  Widget DesktopLiveScreen() {
    return Container(
      height: 230,
      child: ListView.builder(
          itemCount: 10,
          scrollDirection: Axis.horizontal,
          physics: AlwaysScrollableScrollPhysics(),
          itemBuilder: ((context, index) {
            return InkWell(
              onTap: () {
                // Navigator.push(
                //     context,
                //     MaterialPageRoute(
                //         builder: (context) => VideoCallWithVendor()));
              },
              child: Container(
                margin: EdgeInsets.only(right: 10),
                child: Stack(alignment: Alignment.center, children: [
                  Container(
                    height: 220,
                    width: 170,
                    decoration: BoxDecoration(
                        color: Colors.yellow,
                        borderRadius: BorderRadius.circular(10),
                        image: DecorationImage(
                            image: NetworkImage(
                                "http://t0.gstatic.com/licensed-image?q=tbn:ANd9GcRKx8DeyfgyNUR--S74z_5f0zFMNhJ3cdpXvKZjvLOnPGy-Oe3t7cY0tlN2vL68mkD6oQ0w-klevboekXU"),
                            fit: BoxFit.fill)),
                  ),
                  Positioned(
                      top: 175,
                      left: 60,
                      child: Container(
                        padding:
                            EdgeInsets.symmetric(vertical: 2, horizontal: 5),
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(5),
                            color: Colors.white),
                        child: Row(
                          children: [
                            Container(
                              height: 8,
                              width: 8,
                              decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: Color.fromRGBO(36, 220, 55, 1)),
                            ),
                            SizedBox(
                              width: 5,
                            ),
                            Text(
                              "Live",
                              style: TextStyle(fontSize: 10),
                            ),
                          ],
                        ),
                      )),
                  Positioned(
                      top: 200,
                      // left: 10,
                      child: Container(
                        child: Text(
                          "Rashmika Gautam",
                          style: TextStyle(
                              fontSize: 17, fontWeight: FontWeight.bold),
                        ),
                      ))
                ]),
              ),
            );
          })),
    );
  }
}

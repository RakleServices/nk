import 'package:flutter/material.dart';
import 'package:naksaa_services/Service/PaymentandWalletService.dart';
import 'package:naksaa_services/UI/REgister/project%20Assets/constants.dart';

import '../../../model/RechargeNowModel.dart';
import 'PaymentDetails.dart';

class RechargeNow extends StatefulWidget {
  const RechargeNow({super.key});

  @override
  State<RechargeNow> createState() => _RechargeNowState();
}

class _RechargeNowState extends State<RechargeNow> {
  List<Datum> recharge = [];

  var rechargeService = PaymentandWalletService();

  Future<List<Datum>> getdata() async {
    recharge = await rechargeService.viewRechargePlan();
    if (recharge != null) {
      return recharge;
    } else {
      throw Exception('Failed to load');
    }
  }

  final _navKey = GlobalKey<NavigatorState>();

  void gotoPaymentScreen(BuildContext context, String amount) {
    _navKey.currentState!.push(
      MaterialPageRoute(
          builder: (context) => PaymentDetails(
                amount: amount,
              )),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Container(
        height: 210,
        width: 320,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(10),
        ),
        alignment: Alignment.center,
        child: Column(
          children: [
            FutureBuilder(
              future: getdata(),
              builder: (BuildContext ctx, AsyncSnapshot<List> item) => item
                      .hasData
                  ? item.data!.isNotEmpty
                      ? Container(
                          height: 200,
                          margin: EdgeInsets.only(top: 10),
                          // color: Colors.black,
                          child: MediaQuery.removePadding(
                            context: context,
                            removeTop: true,
                            child: GridView.count(
                                childAspectRatio: (1 / .6),
                                crossAxisCount: 3,
                                padding: EdgeInsets.all(10),
                                crossAxisSpacing: 4.0,
                                // scrollDirection: Axis,
                                // physics: NeverScrollableScrollPhysics(),
                                mainAxisSpacing: 3.0,
                                children: List.generate(
                                    recharge.length,
                                    (index) => GestureDetector(
                                          onTap: () async {
                                            // print(recharge[index].amount);
                                            Navigator.push(
                                                context,
                                                MaterialPageRoute(
                                                    builder: (context) =>
                                                        PaymentDetails(
                                                            amount:
                                                                recharge[index]
                                                                    .amount)));
                                          },
                                          child: Container(
                                            height: 45,
                                            width: 78,
                                            margin: EdgeInsets.only(
                                                bottom: 10, right: 10),
                                            decoration: BoxDecoration(
                                                borderRadius:
                                                    BorderRadius.circular(5),
                                                boxShadow: const [
                                                  BoxShadow(
                                                    color: Color.fromRGBO(
                                                        0, 0, 0, 0.16),
                                                    offset: Offset(
                                                      3.0,
                                                      3.0,
                                                    ),
                                                    blurRadius: 6.0,
                                                    spreadRadius: 2.0,
                                                  ), //BoxShadow
                                                  BoxShadow(
                                                    color: Colors.white,
                                                    offset: Offset(0.0, 0.0),
                                                    blurRadius: 0.0,
                                                    spreadRadius: 0.0,
                                                  ), //BoxShadow
                                                ],
                                                color: themeColor),
                                            child: Center(
                                              child: Text(
                                                "₹ ${recharge[index].amount}",
                                                style: const TextStyle(
                                                    fontSize: 11,
                                                    color: Colors.black,
                                                    fontWeight:
                                                        FontWeight.bold),
                                              ),
                                            ),
                                          ),
                                        ))),
                          ),
                        )
                      : Center(
                          child: Text("No Data Found"),
                        )
                  : Container(
                      height: 200,
                      child: Center(
                        child: CircularProgressIndicator(),
                      ),
                    ),
            )
          ],
        ));
  }
}

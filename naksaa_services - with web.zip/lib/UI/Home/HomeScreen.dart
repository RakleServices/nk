import 'package:flutter/material.dart';
import 'package:naksaa_services/UI/Home/BottomNavigation.dart';
import 'package:naksaa_services/UI/Home/Partner/AllLiveVendor.dart';
import 'package:naksaa_services/UI/Home/Partner/ClientTestimonials.dart';
import 'package:naksaa_services/UI/Home/Partner/ConnectWithPeople.dart';
import 'package:naksaa_services/UI/Home/Partner/LivePeople.dart';
import 'package:naksaa_services/UI/Home/Partner/NaksaBlog.dart';
import 'package:naksaa_services/UI/REgister/PhoneRegister.dart';
import 'package:naksaa_services/UI/REgister/project%20Assets/MainSlider.dart';
import 'package:naksaa_services/UI/REgister/project%20Assets/constants.dart';
import 'package:naksaa_services/UI/REgister/project%20Assets/desktopNavbar.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../REgister/project Assets/AppBar.dart';
import '../REgister/project Assets/Navigationdrawer.dart';
import 'Service/ServiceMain.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, constraints) {
      if (constraints.maxWidth > 1200) {
        return DesktopHomeScreen();
      } else if (constraints.maxWidth > 800 && constraints.maxWidth < 1200) {
        return DesktopHomeScreen();
      } else {
        return MobileHomeScreen();
      }
    });
  }

  Widget DesktopHomeScreen() {
    var screenSize;
    return Scaffold(
      backgroundColor: const Color.fromRGBO(242, 244, 243, 1),
      // appBar: AppBar(title: Text("nkbn")),
      appBar: PreferredSize(
        preferredSize: Size(1000, 1000),
        child: NavBar(),
      ),
      drawer:
          const Drawer(backgroundColor: darkBlue, child: NavigationDrawer()),
      body: SingleChildScrollView(
        child: Column(children: [
          Container(
              color: backgroundColor,
              margin: const EdgeInsets.only(top: 10),
              child: const ServiceMainScreen()),
          const MainSlider(),
          Container(
            margin: const EdgeInsets.only(left: 10, right: 10),
            child: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      "Live Naksian",
                      style: TextStyle(fontSize: 12),
                    ),
                    GestureDetector(
                      onTap: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => AllLiveVendor()));
                      },
                      child: Text(
                        "View All >",
                        style: TextStyle(fontSize: 12),
                      ),
                    )
                  ],
                ),
                SizedBox(
                  height: 8,
                ),
                LivePeople(),
              ],
            ),
          ),
          SizedBox(
            height: 10,
          ),
          Container(
            margin: EdgeInsets.only(left: 10, right: 10),
            child: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      "Connect with Naksian",
                      style: TextStyle(fontSize: 12),
                    ),
                    Text(
                      "View All >",
                      style: TextStyle(fontSize: 12),
                    )
                  ],
                ),
                SizedBox(
                  height: 8,
                ),
                ConnectWithPeople(),
              ],
            ),
          ),
          SizedBox(
            height: 10,
          ),
          Container(
            margin: EdgeInsets.only(left: 10, right: 10, bottom: 20),
            child: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      "Client Testimonials",
                      style: TextStyle(fontSize: 12),
                    ),
                    Text(
                      "View All >",
                      style: TextStyle(fontSize: 12),
                    )
                  ],
                ),
                SizedBox(
                  height: 8,
                ),
                ClientTestimonials(),
              ],
            ),
          ),
          SizedBox(
            height: 10,
          ),
          Container(
            // margin: EdgeInsets.only(left: 10, right: 10),
            color: Colors.white,
            padding: EdgeInsets.all(15),
            child: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      "Latest News",
                      style: TextStyle(fontSize: 12),
                    ),
                    Text(
                      "View All >",
                      style: TextStyle(fontSize: 12),
                    )
                  ],
                ),
                SizedBox(
                  height: 8,
                ),
                NaksaBlog(),
              ],
            ),
          ),
        ]),
      ),
    );
  }

  Widget MobileHomeScreen() {
    return Scaffold(
      backgroundColor: const Color.fromRGBO(242, 244, 243, 1),
      // appBar: AppBar(title: Text("nkbn")),
      appBar: AppBar(
          backgroundColor: Colors.transparent,
          elevation: 0.0,
          toolbarHeight: 140,
          automaticallyImplyLeading: false,
          foregroundColor: const Color.fromRGBO(0, 0, 0, 1),
          flexibleSpace: const AppBarScreen()),
      drawer:
          const Drawer(backgroundColor: darkBlue, child: NavigationDrawer()),
      body: SingleChildScrollView(
        child: Column(children: [
          Container(
              color: Colors.white,
              margin: const EdgeInsets.only(top: 10),
              child: const ServiceMainScreen()),
          const MainSlider(),
          Container(
            margin: const EdgeInsets.only(left: 10, right: 10),
            child: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      "Live Naksian",
                      style: TextStyle(fontSize: 12),
                    ),
                    GestureDetector(
                      onTap: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => AllLiveVendor()));
                      },
                      child: Text(
                        "View All >",
                        style: TextStyle(fontSize: 12),
                      ),
                    )
                  ],
                ),
                SizedBox(
                  height: 8,
                ),
                LivePeople(),
              ],
            ),
          ),
          SizedBox(
            height: 10,
          ),
          Container(
            margin: EdgeInsets.only(left: 10, right: 10),
            child: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      "Connect with Naksian",
                      style: TextStyle(fontSize: 12),
                    ),
                    Text(
                      "View All >",
                      style: TextStyle(fontSize: 12),
                    )
                  ],
                ),
                SizedBox(
                  height: 8,
                ),
                ConnectWithPeople(),
              ],
            ),
          ),
          SizedBox(
            height: 10,
          ),
          Container(
            margin: EdgeInsets.only(left: 10, right: 10, bottom: 20),
            child: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      "Client Testimonials",
                      style: TextStyle(fontSize: 12),
                    ),
                    Text(
                      "View All >",
                      style: TextStyle(fontSize: 12),
                    )
                  ],
                ),
                SizedBox(
                  height: 8,
                ),
                ClientTestimonials(),
              ],
            ),
          ),
          SizedBox(
            height: 10,
          ),
          Container(
            // margin: EdgeInsets.only(left: 10, right: 10),
            color: Colors.white,
            padding: EdgeInsets.all(15),
            child: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      "Latest News",
                      style: TextStyle(fontSize: 12),
                    ),
                    Text(
                      "View All >",
                      style: TextStyle(fontSize: 12),
                    )
                  ],
                ),
                SizedBox(
                  height: 8,
                ),
                NaksaBlog(),
              ],
            ),
          ),
        ]),
      ),
    );
  }
}

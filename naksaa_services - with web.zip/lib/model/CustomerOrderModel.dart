// To parse this JSON data, do
//
//     final customerOrderModel = customerOrderModelFromJson(jsonString);

import 'package:meta/meta.dart';
import 'dart:convert';

CustomerOrderModel customerOrderModelFromJson(String str) =>
    CustomerOrderModel.fromJson(json.decode(str));

String customerOrderModelToJson(CustomerOrderModel data) =>
    json.encode(data.toJson());

class CustomerOrderModel {
  CustomerOrderModel({
    required this.data,
    required this.status,
  });

  List<CustomerOrderdata> data;
  bool status;

  factory CustomerOrderModel.fromJson(Map<String, dynamic> json) =>
      CustomerOrderModel(
        data: List<CustomerOrderdata>.from(
            json["data"].map((x) => CustomerOrderdata.fromJson(x))),
        status: json["status"],
      );

  Map<String, dynamic> toJson() => {
        "data": List<dynamic>.from(data.map((x) => x.toJson())),
        "status": status,
      };
}

class CustomerOrderdata {
  CustomerOrderdata({
    required this.orderid,
    required this.userid,
    required this.vid,
    required this.orderfor,
    required this.createdat,
    required this.orderstatus,
    required this.customerstatus,
    required this.waittime,
    required this.completecalltime,
    required this.callingamount,
    required this.name,
    required this.photo,
    required this.audicallprice,
    required this.chatprice,
  });

  int orderid;
  int userid;
  int vid;
  String orderfor;
  DateTime createdat;
  String orderstatus;
  dynamic customerstatus;
  dynamic waittime;
  dynamic completecalltime;
  dynamic callingamount;
  String name;
  String photo;
  String audicallprice;
  String chatprice;

  factory CustomerOrderdata.fromJson(Map<String, dynamic> json) =>
      CustomerOrderdata(
        orderid: json["orderid"],
        userid: json["userid"],
        vid: json["vid"],
        orderfor: json["orderfor"],
        createdat: DateTime.parse(json["createdat"]),
        orderstatus: json["orderstatus"],
        customerstatus: json["customerstatus"],
        waittime: json["waittime"],
        completecalltime: json["completecalltime"],
        callingamount: json["callingamount"],
        name: json["name"],
        photo: json["photo"],
        audicallprice: json["audicallprice"],
        chatprice: json["chatprice"],
      );

  Map<String, dynamic> toJson() => {
        "orderid": orderid,
        "userid": userid,
        "vid": vid,
        "orderfor": orderfor,
        "createdat": createdat.toIso8601String(),
        "orderstatus": orderstatus,
        "customerstatus": customerstatus,
        "waittime": waittime,
        "completecalltime": completecalltime,
        "callingamount": callingamount,
        "name": name,
        "photo": photo,
        "audicallprice": audicallprice,
        "chatprice": chatprice,
      };
}

import 'dart:convert';

import 'package:http/http.dart' as http;
import 'package:naksaa_services/MainAsset/URL.dart';
import 'package:naksaa_services/model/CustomerWalletModel.dart';

class CustomerWalletService {
  Future<List<Walletdatum>?> viewCustomerWallet(String uid) async {
    var client = http.Client();
    var uri = Uri.parse(BaseUrl + 'wallet-amount/${uid}');
    var response = await client.get(uri);
    if (response.statusCode == 200) {
      var json = response.body;
      print(json);
      // print(json);
      return CustomerWalletModel.fromJson(jsonDecode(json)).walletdata.toList();
    } else {
      throw Exception('failed to load data');
    }
  }
}

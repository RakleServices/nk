import 'package:flutter/material.dart';
import 'package:naksaa_services/UI/Home/Partner/VendorProfile.dart';
import 'package:naksaa_services/model/VendorWorkModel.dart';

import '../../../MainAsset/URL.dart';
import '../../REgister/project Assets/constants.dart';

class VendorProfileWork extends StatelessWidget {
  List<VendorWork> wportdata;
  VendorProfileWork({super.key, required this.wportdata});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Work Portfolio"),
        elevation: 0,
        backgroundColor: themeColor,
      ),
      body: Container(
        margin: const EdgeInsets.only(top: 15, bottom: 15, left: 5),
        child: GridView.builder(
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                childAspectRatio: 1,
                crossAxisCount: 3,
                crossAxisSpacing: 3.0,
                mainAxisSpacing: 3.0),
            itemCount: wportdata.length,
            itemBuilder: (context, index) {
              return GestureDetector(
                onTap: () async {
                  await showDialog(
                      context: context,
                      builder: (_) => ImageDialog(
                          MainUrl + 'vendor-work/' + wportdata[index].photo));
                },
                child: Container(
                  margin: const EdgeInsets.only(bottom: 10, right: 5),
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(30),
                      color: Colors.grey.withOpacity(0.25),
                      image: DecorationImage(
                          image: NetworkImage(MainUrl +
                              'vendor-work/' +
                              wportdata[index].photo),
                          fit: BoxFit.fill)),
                ),
              );
            }),
      ),
    );
  }
}

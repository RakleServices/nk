import 'package:flutter/material.dart';
import 'package:naksaa_services/UI/Home/MainSideBar.dart';
import 'package:naksaa_services/UI/Home/Notification.dart';
import 'package:naksaa_services/UI/Home/Profile.dart';
import 'package:naksaa_services/UI/Home/SearchScreen.dart';

class AppBarScreen extends StatefulWidget {
  const AppBarScreen({super.key});

  @override
  State<AppBarScreen> createState() => _AppBarScreenState();
}

class _AppBarScreenState extends State<AppBarScreen> {
  @override
  Widget build(BuildContext context) {
    Color themeColor = Color.fromRGBO(255, 215, 0, 1);
    Color secondColor = Color.fromRGBO(56, 56, 56, 1);
    return Container(
      // padding: EdgeInsets.only(left: 40, right: 40),
      decoration: BoxDecoration(
        color: themeColor,
        borderRadius: BorderRadius.only(
            bottomLeft: Radius.circular(30), bottomRight: Radius.circular(30)),
      ),
      child: Column(children: [
        Container(
          height: 43,
          margin: EdgeInsets.only(top: 44),
          child: Container(
            padding: EdgeInsets.only(left: 20, right: 10),
            child: Row(
              children: [
                InkWell(
                  onTap: () {
                    Scaffold.of(context).openDrawer();
                  },
                  child: Container(
                    child: Icon(
                      Icons.menu,
                      color: secondColor,
                      size: 25,
                    ),
                  ),
                ),
                SizedBox(
                  width: 12,
                ),
                Container(height: 35, child: Image.asset("assets/logo.png")),
                SizedBox(
                  width: 110,
                ),
                Container(
                  child: Row(children: [
                    Padding(
                        padding: EdgeInsets.only(right: 20.0),
                        child: GestureDetector(
                          onTap: () {
                            Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => CustomerProfile()));
                          },
                          child: Icon(
                            color: secondColor,
                            Icons.person,
                            size: 26.0,
                          ),
                        )),
                    Padding(
                        padding: EdgeInsets.only(right: 20.0),
                        child: GestureDetector(
                          onTap: () {
                            Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => NaksaNotifictaion()));
                          },
                          child: Icon(
                            color: secondColor,
                            Icons.notifications,
                            size: 26.0,
                          ),
                        )),
                  ]),
                )
              ],
            ),
          ),
        ),
        SizedBox(
          height: 18,
        ),
        InkWell(
          onTap: () {
            Navigator.push(context,
                MaterialPageRoute(builder: (context) => SearchScreen()));
          },
          child: Container(
            margin: EdgeInsets.only(left: 20, right: 20),
            padding: EdgeInsets.only(left: 8, right: 8),
            height: 45,
            decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10), color: Colors.white),
            child: Row(children: [
              Icon(
                Icons.search,
                color: Color.fromRGBO(183, 190, 198, 1),
                size: 30,
              ),
              SizedBox(
                width: 15,
              ),
              Text(
                "Search Service",
                style: TextStyle(
                  fontSize: 14,
                  color: Color.fromRGBO(183, 190, 198, 1),
                ),
              )
            ]),
          ),
        ),
        // Container(
        //   margin: EdgeInsets.only(left: 20, right: 20, top: 15),
        //   padding: EdgeInsets.only(left: 8, right: 8),
        //   height: 25,
        //   child: Row(children: [
        //     Icon(
        //       Icons.location_pin,
        //       color: secondColor,
        //       size: 20,
        //     ),
        //     // Container(
        //     //   child: Row(children: [
        //     //     Text(
        //     //       "Service Location near - Lucknow 226016",
        //     //       style: TextStyle(fontSize: 14, color: secondColor),
        //     //     ),
        //     //     Icon(
        //     //       Icons.keyboard_arrow_down_outlined,
        //     //       color: secondColor,
        //     //       size: 20,
        //     //     ),
        //     //   ]),
        //     // )
        //   ]),
        // )
      ]),
    );
  }
}

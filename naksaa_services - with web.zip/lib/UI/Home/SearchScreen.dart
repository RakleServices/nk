import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:naksaa_services/MainAsset/LoadingIndicator.dart';
import 'package:naksaa_services/UI/REgister/project%20Assets/constants.dart';
import 'package:naksaa_services/model/AllVendorModel.dart';

import '../../MainAsset/URL.dart';
import '../../Service/SearchVendorService.dart';
import 'Partner/VendorProfile.dart';
import 'Service/ServiceMain.dart';

class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key});

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  TextEditingController _searchController = TextEditingController();
  bool isSearch = true;
  List<Datum> services = [];
  bool isloading = false;
  String query = '';
  Timer? debouncer;
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
  }

  @override
  void dispose() {
    debouncer?.cancel();
    super.dispose();
    WidgetsBinding.instance.addPostFrameCallback((_) => init());
  }

  void debounce(
    VoidCallback callback, {
    Duration duration = const Duration(milliseconds: 1000),
  }) {
    if (debouncer != null) {
      debouncer!.cancel();
    }

    debouncer = Timer(duration, callback);
  }

  Future init() async {
    services = await SearchService.searchProducts(query);

    setState(() => this.services = services);
  }

  Future searchServiceDetails(String query) async => debounce(() async {
        setState(() {
          isloading = true;
        });
        final services = await SearchService.searchProducts(query);

        if (!mounted) return;

        setState(() {
          this.query = query;
          this.services = services;
          isloading = false;
        });
      });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: backgroundColor,
      appBar: AppBar(
        bottom: PreferredSize(
            preferredSize: Size.fromHeight(2.0),
            child: Container(
              color: blueColor,
              height: 1.0,
            )),
        elevation: 0,
        foregroundColor: Colors.black,
        backgroundColor: Colors.white,
        title: TextFormField(
            controller: _searchController,
            decoration: const InputDecoration(
                hintText: 'Search Interior desginer, Architecture....',
                hintStyle: TextStyle(
                  color: textColor,
                  fontSize: 15,
                  fontStyle: FontStyle.italic,
                ),
                border: InputBorder.none),
            style: const TextStyle(
              color: Colors.black,
            ),
            onChanged: (text) {
              if (text.trim().isEmpty) {
                setState(() {
                  isSearch = true;
                });
              } else {
                searchServiceDetails(text);
                setState(() {
                  isSearch = false;
                });
              }
            }),
      ),
      body: SingleChildScrollView(
        child: isSearch != false
            ? Column(children: [
                SizedBox(
                  height: 15,
                ),
                Container(
                    margin: EdgeInsets.only(left: 25, right: 25),
                    padding: EdgeInsets.all(8),
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(21),
                        color: Colors.white),
                    child: ListView.builder(
                        shrinkWrap: true,
                        itemCount: 5,
                        itemBuilder: ((context, index) {
                          return Container(
                            padding: EdgeInsets.all(7),
                            child: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Container(
                                    child: Row(children: [
                                      Icon(
                                        Icons.access_time_outlined,
                                        color: Color.fromRGBO(159, 152, 152, 1),
                                      ),
                                      SizedBox(
                                        width: 15,
                                      ),
                                      Text("Aditya roy"),
                                    ]),
                                  ),
                                  Icon(
                                    Icons.arrow_forward,
                                    size: 15,
                                  )
                                ]),
                          );
                        }))),
                SizedBox(
                  height: 20,
                ),
                Container(
                  height: 70,
                  padding: EdgeInsets.only(left: 20, right: 20),
                  margin: EdgeInsets.only(left: 25, right: 25),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(21),
                    color: darkBlue,
                  ),
                  child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              "Explore & Search For",
                              style:
                                  TextStyle(fontSize: 14, color: Colors.white),
                            ),
                            Text(
                              "More on Naksa Services",
                              style:
                                  TextStyle(fontSize: 13, color: Colors.white),
                            )
                          ],
                        ),
                        Container(
                          height: 25,
                          width: 25,
                          decoration: BoxDecoration(
                              color: themeColor, shape: BoxShape.circle),
                          child: Center(
                            child: Icon(
                              Icons.arrow_right_rounded,
                            ),
                          ),
                        )
                      ]),
                ),
                SizedBox(
                  height: 20,
                ),
                Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                        margin: const EdgeInsets.only(left: 20),
                        child: const Text(
                          "Quick Links",
                          style: TextStyle(
                              fontSize: 15, fontWeight: FontWeight.w500),
                        )),
                    const ServiceMainScreen(),
                  ],
                ),
              ])
            : Container(
                margin: EdgeInsets.only(top: 15),
                child: isloading != true
                    ? services.length > 0
                        ? Expanded(
                            child: ListView.builder(
                              shrinkWrap: true,
                              physics: NeverScrollableScrollPhysics(),
                              itemCount: services.length,
                              itemBuilder: (context, index) {
                                final service = services[index];

                                return buildService(service);
                              },
                            ),
                          )
                        : Container(
                            height: 70,
                            padding: EdgeInsets.only(left: 20, right: 20),
                            margin: EdgeInsets.only(left: 25, right: 25),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(21),
                              color: darkBlue,
                            ),
                            child: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        "No Results Founds!....",
                                        style: TextStyle(
                                            fontSize: 14, color: Colors.white),
                                      ),
                                      Text(
                                        "Please try again....",
                                        style: TextStyle(
                                            fontSize: 13, color: Colors.white),
                                      )
                                    ],
                                  ),
                                  Container(
                                    height: 25,
                                    width: 25,
                                    decoration: BoxDecoration(
                                        color: themeColor,
                                        shape: BoxShape.circle),
                                    child: Center(
                                      child: Icon(
                                        Icons.arrow_right_rounded,
                                      ),
                                    ),
                                  )
                                ]),
                          )
                    : const Center(
                        child: LoadingIndicator(),
                      ),
              ),
      ),
    );
  }

  Widget buildService(Datum service) => GestureDetector(
        onTap: () {
          Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (context) =>
                      VendorProfileScreen(vid: service.id.toString())));
        },
        child: Container(
          padding: EdgeInsets.all(10),
          height: 134,
          margin: EdgeInsets.only(bottom: 15, left: 14, right: 14),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10),
            color: Colors.white,
            boxShadow: [
              BoxShadow(
                color: Color.fromRGBO(0, 0, 0, 0.16),
                offset: const Offset(
                  3.0,
                  3.0,
                ),
                blurRadius: 6.0,
                spreadRadius: 2.0,
              ), //BoxShadow
              BoxShadow(
                color: Colors.white,
                offset: const Offset(0.0, 0.0),
                blurRadius: 0.0,
                spreadRadius: 0.0,
              ), //BoxShadow
            ],
          ),
          child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            Container(
              width: 65,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    height: 60,
                    width: 60,
                    decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(width: 1, color: themeColor),
                        image: DecorationImage(
                            image: NetworkImage(
                                MainUrl + 'vendor-image/' + service.photo),
                            fit: BoxFit.cover)),
                  ),
                  SizedBox(
                    height: 12,
                  ),
                  Container(
                    child: RatingBarIndicator(
                      rating: 4.5,
                      itemBuilder: (context, index) => Icon(
                        Icons.star,
                        color: Colors.amber,
                      ),
                      itemCount: 5,
                      itemSize: 13.0,
                      direction: Axis.horizontal,
                    ),
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  Container(
                    child: Center(
                        child: Text(
                      "734 Votes",
                      style:
                          TextStyle(fontSize: 9, fontWeight: FontWeight.w600),
                    )),
                  )
                ],
              ),
            ),
            SizedBox(
              width: 24,
            ),
            Container(
              child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      service.name,
                      style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          color: Colors.black),
                    ),
                    SizedBox(
                      height: 10,
                    ),
                    SizedBox(
                      width: 150,
                      child: Text(
                        service.primaryskills,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                            fontSize: 13,
                            fontWeight: FontWeight.normal,
                            color: Colors.black.withOpacity(0.53)),
                      ),
                    ),
                    SizedBox(
                      height: 5,
                    ),
                    SizedBox(
                      width: 150,
                      child: Text(
                        service.language,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                            fontSize: 13,
                            fontWeight: FontWeight.normal,
                            color: Colors.black.withOpacity(0.53)),
                      ),
                    ),
                    SizedBox(
                      height: 5,
                    ),
                    Text(
                      "${(service.enddate.difference(service.startdate).inDays)} Days",
                      style: TextStyle(
                          fontSize: 13,
                          fontWeight: FontWeight.normal,
                          color: Colors.black.withOpacity(0.53)),
                    ),
                    SizedBox(
                      height: 6,
                    ),
                    Text(
                      "₹ ${service.audicallprice}/min",
                      style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                          color: Colors.black.withOpacity(1)),
                    )
                  ]),
            ),
            Container(
              child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Container(
                      height: 40,
                      width: 40,
                      decoration: BoxDecoration(
                          image: DecorationImage(
                              image: AssetImage("assets/SVG/star2-2x.png"))),
                      child: Center(
                          child: Padding(
                        padding: EdgeInsets.only(bottom: 5),
                        child: Icon(
                          Icons.check,
                          color: Colors.white,
                          size: 16,
                        ),
                      )),
                    ),
                  ]),
            )
          ]),
        ),
      );
}

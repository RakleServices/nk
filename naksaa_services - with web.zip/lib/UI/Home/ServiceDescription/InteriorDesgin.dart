import 'package:carousel_slider/carousel_options.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:lecle_bubble_timeline/lecle_bubble_timeline.dart';
import 'package:lecle_bubble_timeline/models/timeline_item.dart';
import 'package:naksaa_services/UI/Home/BottomNavigation.dart';
import 'package:naksaa_services/UI/REgister/project%20Assets/MainSlider.dart';
import 'package:naksaa_services/UI/REgister/project%20Assets/constants.dart';

import '../Partner/ClientTestimonials.dart';
import '../Partner/ConnectWithPeople.dart';

class InteriorDesginDescription extends StatefulWidget {
  const InteriorDesginDescription({super.key});

  @override
  State<InteriorDesginDescription> createState() =>
      _InteriorDesginDescriptionState();
}

class _InteriorDesginDescriptionState extends State<InteriorDesginDescription> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text("Interior Desginer"),
          elevation: 0,
          backgroundColor: themeColor,
        ),
        body: SingleChildScrollView(
            child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            MainSlider(),
            Container(
              margin: EdgeInsets.only(left: 15, right: 15),
              child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      margin: EdgeInsets.only(left: 10, top: 15, bottom: 10),
                      child: BigText(
                        name: "How We Works?",
                        size: 17,
                      ),
                    ),
                    HowWeWork(),
                    SizedBox(
                      height: 8,
                    ),
                    BigText(
                      name: "Feeling Lost?",
                      size: 14,
                    ),
                    BigText(
                      name:
                          "when trying to explain your interior design needs?",
                      size: 14,
                    ),
                    SizedBox(
                      height: 10,
                    ),
                    Container(
                      child: Column(children: [
                        InteriorCard(
                            Icon(
                              Icons.list,
                              size: 35,
                            ),
                            "Not able to convey your style?",
                            "Do you get confused while searching for design ideas on instagram, pinterest & other websites? Let us help you"),
                        InteriorCard(
                            Icon(
                              Icons.list,
                              size: 35,
                            ),
                            "Not able to convey your style?",
                            "Do you get confused while searching for design ideas on instagram, pinterest & other websites? Let us help you"),
                        InteriorCard(
                            Icon(
                              Icons.list,
                              size: 35,
                            ),
                            "Not able to convey your style?",
                            "Do you get confused while searching for design ideas on instagram, pinterest & other websites? Let us help you"),
                        SizedBox(
                          height: 15,
                        ),
                        BigText(
                          name: "What you get on web call",
                          size: 18,
                          color: Colors.black.withOpacity(0.80),
                        ),
                        WhatYouGet(),
                        SizedBox(
                          height: 10,
                        ),
                        BigText(
                          name: "Our Expert's Portfolio",
                          size: 18,
                          color: Colors.black.withOpacity(0.80),
                        ),
                        SizedBox(
                          height: 8,
                        ),
                        OurExpertsPortfolio(),
                        SizedBox(
                          height: 10,
                        ),
                        Container(
                          margin: EdgeInsets.only(bottom: 20),
                          child: Column(
                            children: [
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(
                                    "Client Testimonials",
                                    style: TextStyle(fontSize: 12),
                                  ),
                                  Text(
                                    "View All >",
                                    style: TextStyle(fontSize: 12),
                                  )
                                ],
                              ),
                              SizedBox(
                                height: 8,
                              ),
                              ClientTestimonials(),
                              SizedBox(
                                height: 10,
                              ),
                              Container(
                                margin: EdgeInsets.only(bottom: 80),
                                child: Column(
                                  children: [
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        Text(
                                          "Connect with Naksian",
                                          style: TextStyle(fontSize: 12),
                                        ),
                                        Text(
                                          "View All >",
                                          style: TextStyle(fontSize: 12),
                                        )
                                      ],
                                    ),
                                    SizedBox(
                                      height: 8,
                                    ),
                                    ConnectWithPeople(),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ]),
                    ),
                  ]),
            )
          ],
        )),
        bottomNavigationBar: bottomNavigationBar());
  }

  Widget bottomNavigationBar() {
    return Container(
        height: 50,
        decoration: BoxDecoration(
            borderRadius: BorderRadius.only(
                topLeft: Radius.circular(10), topRight: Radius.circular(10)),
            border: Border.all(width: 1, color: blueColor.withOpacity(0.6))),
        child: Row(
          children: [
            Container(
              margin: EdgeInsets.only(left: 10, right: 5),
              width: 160,
              height: 42,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(5),
                color: themeColor,
              ),
              child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    Icon(
                      Icons.phone,
                      color: blueColor,
                      size: 20,
                    ),
                    Text(
                      "Call",
                      style: TextStyle(
                          fontSize: 14,
                          color: blueColor,
                          fontWeight: FontWeight.bold),
                    )
                  ]),
            ),
            Container(
              margin: EdgeInsets.only(left: 5, right: 10),
              width: 160,
              height: 42,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(5),
                color: themeColor,
              ),
              child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    Icon(
                      Icons.message,
                      color: blueColor,
                      size: 20,
                    ),
                    Text(
                      "Chat",
                      style: TextStyle(
                          fontSize: 14,
                          color: blueColor,
                          fontWeight: FontWeight.bold),
                    )
                  ]),
            )
          ],
        ));
  }

  Widget WhatYouGet() {
    return Container(
      margin: EdgeInsets.only(left: 10, right: 10),
      child: Column(
        children: [
          SizedBox(
            height: 15,
          ),
          Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Icon(
              Icons.check_circle_rounded,
              color: blueColor,
            ),
            SizedBox(
              width: 9,
            ),
            Container(
              width: 275,
              child: Text(
                "One-to-One live webcall with our expert Interior consultant.",
                textAlign: TextAlign.left,
                style: TextStyle(fontSize: 13.5),
              ),
            )
          ]),
          SizedBox(
            height: 5,
          ),
          Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Icon(
              Icons.check_circle_rounded,
              color: blueColor,
            ),
            SizedBox(
              width: 9,
            ),
            Container(
              width: 275,
              child: Text(
                "Detailed list of rooms to figure your requirements",
                textAlign: TextAlign.left,
                style: TextStyle(fontSize: 13.5),
              ),
            )
          ]),
          SizedBox(
            height: 5,
          ),
          Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Icon(
              Icons.check_circle_rounded,
              color: blueColor,
            ),
            SizedBox(
              width: 9,
            ),
            Container(
              width: 275,
              child: Text(
                "Clarity on the design of your every room individually",
                textAlign: TextAlign.left,
                style: TextStyle(fontSize: 13.5),
              ),
            )
          ]),
          SizedBox(
            height: 5,
          ),
          Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Icon(
              Icons.check_circle_rounded,
              color: blueColor,
            ),
            SizedBox(
              width: 9,
            ),
            Container(
              width: 275,
              child: Text(
                "Budget approximation to save lacs of rupees",
                textAlign: TextAlign.left,
                style: TextStyle(fontSize: 13.5),
              ),
            )
          ]),
          SizedBox(
            height: 5,
          ),
          Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Icon(
              Icons.check_circle_rounded,
              color: blueColor,
            ),
            SizedBox(
              width: 9,
            ),
            Container(
              width: 275,
              child: Text(
                "Gain a Functional understanding of Interior Design!",
                textAlign: TextAlign.left,
                style: TextStyle(fontSize: 13.5),
              ),
            )
          ]),
          SizedBox(
            height: 5,
          ),
          Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Icon(
              Icons.check_circle_rounded,
              color: blueColor,
            ),
            SizedBox(
              width: 9,
            ),
            Container(
              width: 275,
              child: Text(
                "Theme development according to your Style and Taste",
                textAlign: TextAlign.left,
                style: TextStyle(fontSize: 13.5),
              ),
            )
          ]),
          SizedBox(
            height: 5,
          ),
        ],
      ),
    );
  }

  Widget InteriorCard(Icon icon, String title, String desc) {
    return MediaQuery.removePadding(
      context: context,
      removeTop: true,
      child: Card(
        elevation: 2,
        child: ClipPath(
          clipper: ShapeBorderClipper(
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(4))),
          child: Container(
            padding: EdgeInsets.all(13),
            decoration: BoxDecoration(
              border: Border(
                top: BorderSide(color: themeColor, width: 5),
              ),
            ),
            width: 322,
            child: Column(children: [
              Container(
                height: 35,
                width: 35,
                child: icon,
              ),
              BigText(
                name: title,
                size: 13,
                color: Colors.black.withOpacity(0.83),
              ),
              SizedBox(
                height: 8,
              ),
              BigText(
                name: desc,
                size: 13,
                color: Colors.black.withOpacity(0.63),
              )
            ]),
          ),
        ),
      ),
    );
  }

  Widget HowWeWork() {
    return Container(
      child: BubbleTimeline(
        bubbleSize: 60,
        // List of Timeline Bubble Items
        items: [
          TimelineItem(
            title: 'View Interior Desginer',
            subtitle: 'Step 1',
            icon: Icon(
              Icons.directions_boat,
              color: Colors.white,
            ),
            bubbleColor: themeColor,
            // description: 'Description for boat',
            titleStyle: TextStyle(
                fontSize: 15.0, fontWeight: FontWeight.w700, color: blueColor),
            subtitleStyle:
                TextStyle(fontSize: 10.0, fontWeight: FontWeight.w500),
          ),
          TimelineItem(
            title: 'Choose Interior Desginer',
            subtitle: 'Step 2',
            icon: Icon(
              Icons.directions_bike,
              color: Colors.white,
            ),
            bubbleColor: Colors.yellow,
            titleStyle: TextStyle(
                fontSize: 15.0, fontWeight: FontWeight.w700, color: blueColor),
            subtitleStyle:
                TextStyle(fontSize: 10.0, fontWeight: FontWeight.w500),
          ),
          TimelineItem(
            title: 'Choose Room & Style',
            subtitle: 'Step 3',
            icon: Icon(
              Icons.directions_bus,
              color: Colors.white,
            ),
            bubbleColor: Colors.green,
            // description: 'Description for bus',
            titleStyle: TextStyle(
                fontSize: 15.0, fontWeight: FontWeight.w700, color: blueColor),
            subtitleStyle:
                TextStyle(fontSize: 10.0, fontWeight: FontWeight.w500),
          ),
          TimelineItem(
            title: 'Get Your Package',
            subtitle: 'Step 4',
            icon: Icon(
              Icons.directions_bus,
              color: Colors.white,
            ),
            bubbleColor: Colors.red,
            // description: 'Description for bus',
            titleStyle: TextStyle(
                fontSize: 15.0, fontWeight: FontWeight.w700, color: blueColor),
            subtitleStyle:
                TextStyle(fontSize: 10.0, fontWeight: FontWeight.w500),
          ),
        ],
        stripColor: blueColor,
        dividerCircleColor: Colors.white,
      ),
    );
  }

  Widget OurExpertsPortfolio() {
    return Container(
      height: 150,
      child: ListView(
        children: [
          CarouselSlider(
            items: [
              //1st Image of Slider
              Container(
                margin: EdgeInsets.all(6.0),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(8.0),
                  image: DecorationImage(
                    image: NetworkImage(
                        "https://images.unsplash.com/photo-1600210492493-0946911123ea?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=774&q=80"),
                    fit: BoxFit.fill,
                  ),
                ),
              ),

              //2nd Image of Slider
              Container(
                margin: EdgeInsets.all(6.0),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(8.0),
                  image: DecorationImage(
                    image: NetworkImage(
                        "https://plus.unsplash.com/premium_photo-1663126298656-33616be83c32?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=870&q=80"),
                    fit: BoxFit.fill,
                  ),
                ),
              ),

              //3rd Image of Slider
              Container(
                margin: EdgeInsets.all(6.0),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(8.0),
                  image: DecorationImage(
                    image: NetworkImage(
                        "https://images.unsplash.com/photo-1554995207-c18c203602cb?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=870&q=80"),
                    fit: BoxFit.fill,
                  ),
                ),
              ),

              //4th Image of Slider
              Container(
                margin: EdgeInsets.all(6.0),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(8.0),
                  image: DecorationImage(
                    image: NetworkImage(
                        "https://images.unsplash.com/photo-1631679706909-1844bbd07221?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=792&q=80"),
                    fit: BoxFit.fill,
                  ),
                ),
              ),

              //5th Image of Slider
              Container(
                margin: EdgeInsets.all(6.0),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(8.0),
                  image: DecorationImage(
                    image: NetworkImage(
                        "https://plus.unsplash.com/premium_photo-1663926404293-f41018ef409f?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=870&q=80"),
                    fit: BoxFit.fill,
                  ),
                ),
              ),
            ],

            //Slider Container properties
            options: CarouselOptions(
              height: 150.0,
              enlargeCenterPage: true,
              autoPlay: true,
              aspectRatio: 16 / 9,
              autoPlayCurve: Curves.fastOutSlowIn,
              enableInfiniteScroll: true,
              autoPlayAnimationDuration: Duration(milliseconds: 800),
              viewportFraction: 0.5,
            ),
          ),
        ],
      ),
    );
  }
}

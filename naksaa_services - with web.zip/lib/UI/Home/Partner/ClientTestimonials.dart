import 'package:flutter/material.dart';

class ClientTestimonials extends StatefulWidget {
  const ClientTestimonials({super.key});

  @override
  State<ClientTestimonials> createState() => _ClientTestimonialsState();
}

class _ClientTestimonialsState extends State<ClientTestimonials> {
  @override
  Widget build(BuildContext context) {
    return Container(
      height: 165,
      child: ListView.builder(
          itemCount: 10,
          scrollDirection: Axis.horizontal,
          itemBuilder: (context, index) {
            return Container(
              margin: EdgeInsets.only(right: 17, top: 5, bottom: 5),
              height: 161,
              width: 230,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                color: Colors.white,
                boxShadow: [
                  BoxShadow(
                    color: Color.fromRGBO(0, 0, 0, 0.16),
                    offset: const Offset(
                      0.0,
                      3.0,
                    ),
                    blurRadius: 6.0,
                    spreadRadius: 2.0,
                  ), //BoxShadow
                  BoxShadow(
                    color: Colors.white,
                    offset: const Offset(0.0, 0.0),
                    blurRadius: 0.0,
                    spreadRadius: 0.0,
                  ), //BoxShadow
                ],
              ),
              child: Column(children: [
                Container(
                  padding: EdgeInsets.all(14),
                  child: Text(
                    "This app helped me to get a job in my dream company. I was stressed about not getting a career opportunity after my graduation. One prediction from an astrologer gave me a ray of hope and within a few months, I got selected Thanks you so much ChatnFix.",
                    style: TextStyle(fontSize: 10),
                  ),
                ),
                Container(
                  child:
                      Row(mainAxisAlignment: MainAxisAlignment.end, children: [
                    Container(
                      child: Column(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            Text(
                              "Ashwin Pandey",
                              style: TextStyle(
                                  fontSize: 9,
                                  color: Color.fromRGBO(2, 44, 67, 1),
                                  fontWeight: FontWeight.bold),
                            ),
                            Text(
                              "Lucknow, India",
                              style: TextStyle(
                                  fontSize: 9,
                                  color: Color.fromRGBO(2, 44, 67, 1),
                                  fontWeight: FontWeight.normal),
                            )
                          ]),
                    ),
                    SizedBox(
                      width: 10,
                    ),
                    Container(
                      height: 47,
                      width: 47,
                      decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          border: Border.all(
                              width: 2, color: Color.fromRGBO(255, 215, 0, 1)),
                          image: DecorationImage(
                              image: NetworkImage(
                                  "http://rationcart.in/assets/img/team/rohit.jfif"))),
                    ),
                    SizedBox(
                      width: 14,
                    ),
                  ]),
                )
              ]),
            );
          }),
    );
  }
}

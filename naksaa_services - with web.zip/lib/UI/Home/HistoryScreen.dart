import 'package:flutter/material.dart';
import 'package:flutter/src/scheduler/ticker.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:naksaa_services/Service/WalletService.dart';
import 'package:naksaa_services/UI/REgister/project%20Assets/CustomerOrderScreenChat.dart';
import 'package:naksaa_services/UI/REgister/project%20Assets/Wallet.dart';
import 'package:naksaa_services/UI/REgister/project%20Assets/constants.dart';

import '../REgister/project Assets/AppBar.dart';
import '../REgister/project Assets/CustomerOrderScreen.dart';
import '../REgister/project Assets/Navigationdrawer.dart';

class HistoryScreen extends StatefulWidget {
  const HistoryScreen({super.key});

  @override
  State<HistoryScreen> createState() => _HistoryScreenState();
}

class _HistoryScreenState extends State<HistoryScreen>
    with TickerProviderStateMixin {
  late TabController _controller;
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _controller = TabController(
      vsync: this,
      length: 3,
      initialIndex: 0,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color.fromRGBO(242, 244, 243, 1),
      // appBar: AppBar(title: Text("nkbn")),
      appBar: AppBar(
          backgroundColor: Colors.transparent,
          elevation: 0.0,
          toolbarHeight: 140,
          automaticallyImplyLeading: false,
          foregroundColor: Color.fromRGBO(0, 0, 0, 1),
          flexibleSpace: AppBarScreen()),
      drawer:
          Drawer(backgroundColor: darkBlue, child: const NavigationDrawer()),
      body: Column(children: [
        Container(
          margin: EdgeInsets.all(20),
          height: 44,
          decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(22), color: Colors.white),
          child: TabBar(
            labelColor: themeColor,
            // labelStyle: theme.textTheme.headline1,
            indicatorColor: themeColor,
            indicatorSize: TabBarIndicatorSize.label,
            // indicatorPadding: tab,

            unselectedLabelColor: Colors.grey,
            controller: _controller,
            tabs: [
              Tab(
                child: Text("Wallet"),
              ),
              Tab(
                child: Text("Calls"),
              ),
              Tab(
                child: Text("Chats"),
              ),
            ],
          ),
        ),
        Container(
          height: 450,
          child: TabBarView(
            controller: _controller,
            children: [
              WalletSection(),
              CustomerOrderScreen(),
              CustomerOrderScreenForChat()
            ],
          ),
        )
      ]),
    );
  }
}

// To parse this JSON data, do
//
//     final customerPaymentLogsModel = customerPaymentLogsModelFromJson(jsonString);

import 'dart:convert';

CustomerPaymentLogsModel customerPaymentLogsModelFromJson(String str) =>
    CustomerPaymentLogsModel.fromJson(json.decode(str));

String customerPaymentLogsModelToJson(CustomerPaymentLogsModel data) =>
    json.encode(data.toJson());

class CustomerPaymentLogsModel {
  CustomerPaymentLogsModel({
    required this.rowsCount,
    required this.paymentlog,
  });

  int rowsCount;
  List<Paymentlog> paymentlog;

  factory CustomerPaymentLogsModel.fromJson(Map<String, dynamic> json) =>
      CustomerPaymentLogsModel(
        rowsCount: json["rowsCount"],
        paymentlog: List<Paymentlog>.from(
            json["paymentlog"].map((x) => Paymentlog.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "rowsCount": rowsCount,
        "paymentlog": List<dynamic>.from(paymentlog.map((x) => x.toJson())),
      };
}

class Paymentlog {
  Paymentlog({
    required this.id,
    required this.orderId,
    required this.amount,
    required this.userid,
    required this.status,
    required this.paymentId,
    required this.signature,
    required this.createdat,
    required this.updatedat,
    required this.currency,
    required this.gstamount,
  });

  int id;
  String orderId;
  String amount;
  int userid;
  String status;
  String paymentId;
  String signature;
  DateTime createdat;
  DateTime updatedat;
  String currency;
  dynamic gstamount;

  factory Paymentlog.fromJson(Map<String, dynamic> json) => Paymentlog(
        id: json["id"],
        orderId: json["order_id"],
        amount: json["amount"],
        userid: json["userid"],
        status: json["status"],
        paymentId: json["payment_id"] == null ? null : json["payment_id"],
        signature: json["signature"] == null ? null : json["signature"],
        createdat: DateTime.parse(json["createdat"]),
        updatedat: json["updatedat"] == null
            ? DateTime.now()
            : DateTime.parse(json["updatedat"]),
        currency: json["currency"],
        gstamount: json["gstamount"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "order_id": orderId,
        "amount": amount,
        "userid": userid,
        "status": status,
        "payment_id": paymentId == null ? null : paymentId,
        "signature": signature == null ? null : signature,
        "createdat": createdat.toIso8601String(),
        "updatedat": updatedat == null ? null : updatedat.toIso8601String(),
        "currency": currency,
        "gstamount": gstamount,
      };
}

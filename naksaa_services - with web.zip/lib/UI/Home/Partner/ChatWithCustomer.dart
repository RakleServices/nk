import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:naksaa_services/API/FirebaseMethods.dart';
import 'package:naksaa_services/MainAsset/LoadingIndicator.dart';
import 'package:naksaa_services/UI/Home/BottomNavigation.dart';
import 'package:naksaa_services/UI/REgister/project%20Assets/constants.dart';
import 'package:naksaa_services/model/CustomerProfileModel.dart';
import 'package:naksaa_services/model/VendorDetailsModel.dart';
import 'package:uuid/uuid.dart';

import '../../../API/AgoraConfig.dart';
import '../../../MainAsset/URL.dart';

class ChatWithCustomer extends StatefulWidget {
  final String chatRoomId;
  List<CustomerP?> customer;
  List<Vdatum> vdetails;
  ChatWithCustomer(
      {super.key,
      required this.chatRoomId,
      required this.customer,
      required this.vdetails});

  @override
  State<ChatWithCustomer> createState() => _ChatWithCustomerState();
}

class _ChatWithCustomerState extends State<ChatWithCustomer> {
  final TextEditingController _message = TextEditingController();
  final FirebaseFirestore _fireStore = FirebaseFirestore.instance;
  FirebaseAuth _auth = FirebaseAuth.instance;

  void onSendMessage(Map<String, dynamic> messages) async {}

  final _formKey = GlobalKey<FormState>();
  @override
  void initState() {
    super.initState();
  }

  File? imageFIle;
  Future getImage() async {
    ImagePicker _picker = ImagePicker();
    await _picker.pickImage(source: ImageSource.gallery).then((xFile) {
      if (xFile != null) {
        Navigator.pop(context);
        imageFIle = File(xFile.path);
        uploadImage();
      }
    });
  }

  Future getImageByCamera() async {
    ImagePicker _picker = ImagePicker();
    await _picker.pickImage(source: ImageSource.camera).then((xFile) {
      if (xFile != null) {
        Navigator.pop(context);
        imageFIle = File(xFile.path);
        uploadImage();
      }
    });
  }

  Future getDocumentForUpload() async {
    ImagePicker _picker = ImagePicker();
    await _picker.pickImage(source: ImageSource.camera).then((xFile) {
      if (xFile != null) {
        Navigator.pop(context);
        imageFIle = File(xFile.path);
        uploadImage();
      }
    });
  }

  Future uploadImage() async {
    String filename = Uuid().v1();
    int status = 1;
    await _fireStore
        .collection('chatRoom')
        .doc(widget.chatRoomId)
        .collection('chats')
        .doc(filename)
        .set({
      "sendby": _auth.currentUser!.displayName,
      "message": "",
      "type": "img",
      "time": FieldValue.serverTimestamp()
    });
    var ref =
        FirebaseStorage.instance.ref().child('images').child('$filename.jpg');
    var uploadTask = await ref.putFile(imageFIle!).catchError((error) async {
      await _fireStore
          .collection('chatRoom')
          .doc(widget.chatRoomId)
          .collection('chats')
          .doc(filename)
          .delete();
      status = 0;
    });

    if (status == 1) {
      String imageurl = await uploadTask.ref.getDownloadURL();

      await _fireStore
          .collection('chatRoom')
          .doc(widget.chatRoomId)
          .collection('chats')
          .doc(filename)
          .update({"message": imageurl});
      print(imageurl);
    }

    // String imageUrl = await uploadTask.ref.getDownloadURL();
  }

  @override
  Widget build(BuildContext context) {
    final Size size = MediaQuery.of(context).size;
    print(size.height);
    print(size.width);
    return Scaffold(
      backgroundColor: themeColor,
      appBar: AppBar(
          backgroundColor: Colors.transparent,
          elevation: 0.0,
          toolbarHeight: 120,
          automaticallyImplyLeading: false,
          foregroundColor: Color.fromRGBO(0, 0, 0, 1),
          flexibleSpace: Container(
            margin: EdgeInsets.only(top: 44, left: 10, right: 10),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    IconButton(
                      icon: const Icon(
                        Icons.arrow_back,
                        size: 20,
                      ),
                      onPressed: () {
                        Navigator.pop(context);
                      },
                    ),
                    Container(
                      height: 60,
                      width: 60,
                      decoration: BoxDecoration(
                          border: Border.all(width: 1, color: themeColor),
                          shape: BoxShape.circle,
                          image: DecorationImage(
                              image: NetworkImage(MainUrl +
                                  'vendor-image/' +
                                  widget.vdetails[0].photo))),
                    ),
                    GestureDetector(
                      onTap: () {
                        Logout();
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) =>
                                    BottomNavigationBarScreen(pageIndex: 0)));
                      },
                      child: Container(
                        height: 24,
                        width: 60,
                        decoration: BoxDecoration(
                            border: Border.all(
                                width: 1, color: Color.fromRGBO(47, 47, 47, 1)),
                            borderRadius: BorderRadius.circular(5)),
                        child: Center(
                            child: Text(
                          "END",
                          style: TextStyle(
                              fontSize: 13,
                              color: Color.fromRGBO(47, 47, 47, 1)),
                        )),
                      ),
                    ),
                  ],
                ),
                SizedBox(
                  height: 5,
                ),
                Container(
                  child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(widget.vdetails[0].name),
                        const SizedBox(
                          width: 10,
                        ),
                        // snapshot.data!['status'] == "Offline"
                        // ?
                        Container(
                          height: 10,
                          width: 10,
                          decoration: const BoxDecoration(
                              shape: BoxShape.circle, color: Colors.red),
                        )
                        // : Container(
                        //     height: 10,
                        //     width: 10,
                        //     decoration: const BoxDecoration(
                        //         shape: BoxShape.circle,
                        //         color: Colors.green),
                        //   )
                      ]),
                ),
                const SizedBox(
                  height: 8,
                ),
                const Center(
                    child: Text(
                  "03:34",
                  style: TextStyle(
                      fontSize: 13, color: Color.fromRGBO(47, 47, 47, 1)),
                )),
              ],
            ),
          )),
      body: Container(
        height: size.height / 1.12,
        child: Stack(
          children: [
            Positioned(
                bottom: 0,
                child: Container(
                  height: size.height / 2.88,
                  width: size.width,
                  decoration: const BoxDecoration(
                    borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(20),
                        topRight: Radius.circular(20)),
                    color: blueColor,
                  ),
                )),
            Container(
              width: size.width,
              margin: const EdgeInsets.only(top: 10, left: 15, right: 14),
              child: SingleChildScrollView(
                child: Column(children: [
                  Container(
                    padding: const EdgeInsets.all(10),
                    height: size.height / 1.45,
                    width: 330,
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        color: Colors.white),
                    child: StreamBuilder<QuerySnapshot>(
                        stream: _fireStore
                            .collection('chatRoom')
                            .doc(widget.chatRoomId)
                            .collection('chats')
                            .orderBy("time", descending: false)
                            .snapshots(),
                        builder: (BuildContext context,
                            AsyncSnapshot<QuerySnapshot> snapshot) {
                          print(snapshot.data);
                          if (snapshot.data != null) {
                            return ListView.builder(
                              shrinkWrap: true,
                              itemCount: snapshot.data!.docs.length,
                              itemBuilder: (context, index) {
                                Object? map = snapshot.data!.docs[index].data();
                                return messageScreen(size, map!);
                              },
                            );
                          } else {
                            return Container();
                          }
                        }),
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                  SizedBox(
                    height: 50,
                    child: Row(children: [
                      GestureDetector(
                          onTap: () {
                            showDialog<void>(
                              barrierDismissible: true,
                              context: context,
                              builder: (BuildContext context) {
                                return Column(
                                  mainAxisAlignment: MainAxisAlignment.end,
                                  children: <Widget>[
                                    Padding(
                                      padding: const EdgeInsets.all(0),
                                      child: Container(
                                        height: 100,
                                        width:
                                            MediaQuery.of(context).size.width,
                                        color: darkBlue,
                                        child: Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceEvenly,
                                          children: <Widget>[
                                            GestureDetector(
                                              onTap: () => getImageByCamera(),
                                              child: Container(
                                                height: 65,
                                                width: 65,
                                                decoration: BoxDecoration(
                                                    color: darkBlue,
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            50),
                                                    image: const DecorationImage(
                                                        image: AssetImage(
                                                            "assets/SVG/upload-2x.png"),
                                                        fit: BoxFit.fill)),
                                              ),
                                            ),
                                            GestureDetector(
                                              onTap: () => getImage(),
                                              child: Container(
                                                height: 65,
                                                width: 65,
                                                decoration: BoxDecoration(
                                                    color: darkBlue,
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            50),
                                                    image: const DecorationImage(
                                                        image: AssetImage(
                                                            "assets/SVG/upload-2x.png"),
                                                        fit: BoxFit.fill)),
                                              ),
                                            ),
                                            Container(
                                              height: 65,
                                              width: 65,
                                              decoration: BoxDecoration(
                                                  color: darkBlue,
                                                  borderRadius:
                                                      BorderRadius.circular(50),
                                                  image: const DecorationImage(
                                                      image: AssetImage(
                                                          "assets/SVG/upload-2x.png"),
                                                      fit: BoxFit.fill)),
                                            )
                                          ],
                                        ),
                                      ),
                                    )
                                  ],
                                );
                              },
                            );
                          },
                          child: Container(
                            height: 49,
                            width: 49,
                            decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                image: DecorationImage(
                                    image:
                                        AssetImage("assets/SVG/upload-2x.png"),
                                    fit: BoxFit.fill)),
                          )),
                      SizedBox(
                        width: 10,
                      ),
                      Container(
                        height: 49,
                        width: 272,
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(20),
                            color: Colors.white),
                        child: Row(children: [
                          Form(
                            key: _formKey,
                            child: Container(
                              padding: EdgeInsets.only(left: 10, right: 10),
                              height: 49,
                              width: 232,
                              child: TextFormField(
                                controller: _message,
                                decoration: new InputDecoration(
                                    border: InputBorder.none,
                                    focusedBorder: InputBorder.none,
                                    enabledBorder: InputBorder.none,
                                    errorBorder: InputBorder.none,
                                    disabledBorder: InputBorder.none,
                                    contentPadding: EdgeInsets.only(
                                        left: 15,
                                        bottom: 11,
                                        top: 11,
                                        right: 15),
                                    hintText: "Type message here",
                                    hintStyle: TextStyle(
                                        fontSize: 14,
                                        color:
                                            Color.fromRGBO(196, 196, 196, 1))),
                                style: TextStyle(
                                  fontSize: 14,
                                  color: blueColor,
                                ),
                                keyboardType: TextInputType.multiline,
                                maxLines: null,
                                validator: (value) {
                                  if (value == null || value.isEmpty) {
                                    return 'Please enter message';
                                  }
                                  return null;
                                },
                              ),
                            ),
                          ),
                          SizedBox(
                            width: 10,
                          ),
                          GestureDetector(
                            onTap: () async {
                              if (_formKey.currentState!.validate()) {
                                Map<String, dynamic> messages = {
                                  "sendby": widget.customer[0]!.name,
                                  "message": _message.text,
                                  "type": "text",
                                  "time": FieldValue.serverTimestamp()
                                };
                                await _fireStore
                                    .collection('chatRoom')
                                    .doc(widget.chatRoomId)
                                    .collection('chats')
                                    .add(messages);
                                _message.clear();
                              }
                            },
                            child: Container(
                              height: 21,
                              width: 25,
                              decoration: BoxDecoration(
                                  // shape: BoxShape.circle,
                                  image: DecorationImage(
                                      image: AssetImage("assets/SVG/Group.png"),
                                      fit: BoxFit.fill)),
                            ),
                          ),
                        ]),
                      )
                    ]),
                  )
                ]),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget messageScreen(Size size, Object snapshot) {
    return (snapshot as Map)['type'] != "img"
        ? Container(
            width: size.width / 2.5,
            alignment: (snapshot as Map)['sendby'] == widget.customer[0]!.name
                ? Alignment.centerRight
                : Alignment.centerLeft,
            child: Container(
              decoration: BoxDecoration(
                  color: darkBlue,
                  borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(20),
                      topRight: Radius.circular(20),
                      bottomLeft: Radius.circular(20))),
              padding: EdgeInsets.symmetric(vertical: 8, horizontal: 14),
              margin: EdgeInsets.symmetric(vertical: 5, horizontal: 8),
              child: Text(
                snapshot['message'],
                style: TextStyle(color: Colors.white, fontSize: 15),
              ),
            ))
        : Container(
            alignment: (snapshot as Map)['sendby'] == widget.customer[0]!.name
                ? Alignment.centerRight
                : Alignment.centerLeft,
            child: snapshot['message'] != ""
                ? GestureDetector(
                    onTap: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => broadImageView(
                                    image: snapshot['message'],
                                  )));
                    },
                    child: Container(
                      width: size.width / 2,
                      height: size.height / 3,
                      decoration: BoxDecoration(
                          color: darkBlue,
                          borderRadius: const BorderRadius.only(
                              topLeft: Radius.circular(20),
                              topRight: Radius.circular(20),
                              bottomLeft: Radius.circular(20)),
                          image: DecorationImage(
                              image: NetworkImage(snapshot['message']),
                              fit: BoxFit.cover)),
                      padding: const EdgeInsets.symmetric(
                          vertical: 8, horizontal: 14),
                      margin: const EdgeInsets.symmetric(
                          vertical: 5, horizontal: 8),
                      alignment: Alignment.center,
                    ),
                  )
                : Container(
                    width: size.width / 2,
                    height: size.height / 3,
                    decoration: BoxDecoration(
                      color: darkBlue,
                      borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(20),
                          topRight: Radius.circular(20),
                          bottomLeft: Radius.circular(20)),
                    ),
                    padding:
                        const EdgeInsets.symmetric(vertical: 8, horizontal: 14),
                    margin:
                        const EdgeInsets.symmetric(vertical: 5, horizontal: 8),
                    alignment: Alignment.center,
                    child: const Center(child: LoadingIndicator()),
                  ),
          );
  }
}

class broadImageView extends StatelessWidget {
  String image;
  broadImageView({super.key, required this.image});

  @override
  Widget build(BuildContext context) {
    final Size size = MediaQuery.of(context).size;
    return Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.transparent,
          foregroundColor: darkBlue,
          elevation: 0,
          actions: [
            IconButton(onPressed: () {}, icon: const Icon(Icons.share)),
            IconButton(onPressed: () {}, icon: const Icon(Icons.more_vert))
          ],
        ),
        body: Container(
          height: size.height / 1.2,
          width: size.width,
          decoration: BoxDecoration(
            image: DecorationImage(image: NetworkImage(image)),
          ),
        ));
  }
}

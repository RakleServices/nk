const String BaseUrl =
    'http://ec2-43-204-32-65.ap-south-1.compute.amazonaws.com:3000/api/v1/';
const String MainUrl =
    'http://ec2-43-204-32-65.ap-south-1.compute.amazonaws.com:3000/';

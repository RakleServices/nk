import 'package:carousel_slider/carousel_options.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/src/widgets/container.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter/material.dart';
import 'package:naksaa_services/MainAsset/LoadingIndicator.dart';
import 'package:naksaa_services/MainAsset/URL.dart';
import 'package:naksaa_services/Service/BannerService.dart';
import 'package:naksaa_services/UI/REgister/project%20Assets/constants.dart';
import 'package:naksaa_services/model/BannerModel.dart';

class MainSlider extends StatefulWidget {
  const MainSlider({super.key});

  @override
  State<MainSlider> createState() => _MainSliderState();
}

class _MainSliderState extends State<MainSlider> {
  List<BDatum> results = [];
  var vendorService = BannerService();
  bool isloading = false;
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getdata();
    // allVendor = vendorService.viewallVendor();
  }

  Future<List<BDatum>> getdata() async {
    setState(() {
      isloading = true;
    });
    results = (await vendorService.viewallBanner())!;
    if (results != null) {
      setState(() {
        isloading = false;
      });
      return results;
    } else {
      throw Exception('Failed to load');
    }
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, constraints) {
      if (constraints.maxWidth > 1200) {
        return DesktopBanner();
      } else if (constraints.maxWidth > 800 && constraints.maxWidth < 1200) {
        return DesktopBanner();
      } else {
        return Mobilebanner();
      }
    });
  }

  Widget DesktopBanner() {
    return isloading != true
        ? Container(
            margin: EdgeInsets.only(left: 10, right: 10),
            height: 400,
            color: backgroundColor,
            child: ListView(
              children: [
                CarouselSlider(
                  items: results
                      .map((e) => Container(
                            margin: EdgeInsets.all(6.0),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(8.0),
                              image: DecorationImage(
                                image: NetworkImage(
                                    MainUrl + 'banner/' + e.banimage),
                                fit: BoxFit.fill,
                              ),
                            ),
                          ))
                      .toList(),

                  // //Slider Container properties
                  options: CarouselOptions(
                    height: 400.0,
                    enlargeCenterPage: true,
                    autoPlay: true,
                    aspectRatio: 16 / 9,
                    autoPlayCurve: Curves.fastOutSlowIn,
                    enableInfiniteScroll: true,
                    autoPlayAnimationDuration: Duration(milliseconds: 800),
                    viewportFraction: 0.9,
                  ),
                ),
              ],
            ),
          )
        : Container(
            height: 120,
            child: LoadingIndicator(),
          );
  }

  Widget Mobilebanner() {
    return isloading != true
        ? Container(
            height: 120,
            child: ListView(
              children: [
                CarouselSlider(
                  items: results
                      .map((e) => Container(
                            margin: EdgeInsets.all(6.0),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(8.0),
                              image: DecorationImage(
                                image: NetworkImage(
                                    MainUrl + 'banner/' + e.banimage),
                                fit: BoxFit.fill,
                              ),
                            ),
                          ))
                      .toList(),

                  // //Slider Container properties
                  options: CarouselOptions(
                    height: 120.0,
                    enlargeCenterPage: true,
                    autoPlay: true,
                    aspectRatio: 16 / 9,
                    autoPlayCurve: Curves.fastOutSlowIn,
                    enableInfiniteScroll: true,
                    autoPlayAnimationDuration: Duration(milliseconds: 800),
                    viewportFraction: 0.9,
                  ),
                ),
              ],
            ),
          )
        : Container(
            height: 120,
            child: LoadingIndicator(),
          );
  }
}

import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:naksaa_services/API/NetworkProvider.dart';
import 'package:naksaa_services/UI/Home/BottomNavigation.dart';
import 'package:naksaa_services/UI/REgister/project%20Assets/constants.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sms_autofill/sms_autofill.dart';

import '../../Service/CustomerProfileService.dart';
import '../../model/CustomerProfileModel.dart';
import '../Home/ChatScreen.dart';
import '../Home/CompleteProfileScreen.dart';
import '../Home/HomeScreen.dart';

class OTPVarification extends StatefulWidget {
  String mobile;
  OTPVarification({super.key, required this.mobile});

  @override
  State<OTPVarification> createState() => _OTPVarificationState();
}

class _OTPVarificationState extends State<OTPVarification>
    with SingleTickerProviderStateMixin {
  var networkHandler = NetworkHandler();
  bool isloading = false;
  TextEditingController _otp1 = TextEditingController();
  TextEditingController _otp2 = TextEditingController();
  TextEditingController _otp3 = TextEditingController();
  TextEditingController _otp4 = TextEditingController();
  AnimationController? _animationController;
  int levelClock = 60;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
        vsync: this, duration: Duration(seconds: levelClock));

    _animationController!.forward();
  }

  final _formKey = GlobalKey<FormState>();
  @override
  Widget build(BuildContext context) {
    var screenWidth = MediaQuery.of(context).size.width;
    var screenHeight = MediaQuery.of(context).size.height;
    Size size = MediaQuery.of(context).size;
    return LayoutBuilder(builder: (context, constraints) {
      if (constraints.maxWidth > 1200) {
        return DesktopOTPVarification();
      } else if (constraints.maxWidth > 800 && constraints.maxWidth < 1200) {
        return DesktopOTPVarification();
      } else {
        return MobileOTPVarification();
      }
    });
  }

  Widget DesktopOTPVarification() {
    return Scaffold(
      body: Center(
        child: Container(
          height: 1000,
          width: 700,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Container(
                margin: EdgeInsets.only(top: 60, left: 21),
                height: 140,
                width: 150,
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Container(
                        height: 100,
                        child: Image.asset(
                          "assets/logo.png",
                          fit: BoxFit.fill,
                        ),
                      ),
                      SizedBox(
                        height: 5,
                      ),
                      Text(
                        "DISCOVER THE BEST SOLUTION EASY & SIMPLE",
                        textAlign: TextAlign.center,
                        style: TextStyle(
                            fontSize: 12,
                            color: Color.fromRGBO(112, 112, 112, 1)),
                      )
                    ]),
              ),
              Container(
                margin: EdgeInsets.only(top: 60),
                height: 400,
                padding: EdgeInsets.only(left: 30, right: 30),
                width: double.infinity,
                decoration: BoxDecoration(
                    image: DecorationImage(
                        image: AssetImage("assets/SVG/back.png"))),
                child: Container(
                  height: 281,
                  width: 227,
                  margin: EdgeInsets.only(left: 65, right: 65),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    color: Colors.white,
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.12),
                        offset: const Offset(
                          3.0,
                          3.0,
                        ),
                        blurRadius: 8.0,
                        spreadRadius: 2.0,
                      ), //BoxShadow
                      BoxShadow(
                        color: Colors.white,
                        offset: const Offset(0.0, 0.0),
                        blurRadius: 0.0,
                        spreadRadius: 0.0,
                      ), //BoxShadow
                    ],
                  ),
                  child: Column(children: [
                    Container(
                      height: 121,
                      child: Stack(
                        children: [
                          Container(
                            margin: EdgeInsets.only(top: 45),
                            height: 76,
                            width: 76,
                            padding: EdgeInsets.all(10),
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              border: Border.all(
                                  width: 8,
                                  color: Color.fromRGBO(240, 240, 240, 1)),
                            ),
                            child: Image(
                              image: AssetImage("assets/SVG/ic-contact-2x.png"),
                              fit: BoxFit.contain,
                            ),
                          ),
                          Positioned(
                              top: 37,
                              // left: 150,
                              right: 0,
                              child: Container(
                                height: 23,
                                width: 23,
                                decoration: BoxDecoration(
                                    image: DecorationImage(
                                        image: AssetImage(
                                            "assets/SVG/message-2x.png"))),
                              ))
                        ],
                      ),
                    ),
                    SizedBox(
                      height: 16,
                    ),
                    Container(
                        child: Text(
                      "Enter 4 Digits code",
                      style: TextStyle(
                        fontSize: 12,
                        color: Color.fromRGBO(164, 164, 164, 1),
                      ),
                    )),
                    // Container(
                    //   margin: EdgeInsets.all(10),
                    //   child: Center(
                    //     child: PinFieldAutoFill(
                    //       controller: _otp,
                    //       codeLength: 4,
                    //       autoFocus: true,
                    //       decoration: UnderlineDecoration(
                    //         lineHeight: 2,
                    //         lineStrokeCap: StrokeCap.square,
                    //         bgColorBuilder: PinListenColorBuilder(
                    //             Colors.green.shade200, Colors.yellow),
                    //         colorBuilder: const FixedColorBuilder(Colors.white),
                    //       ),
                    //       onCodeChanged: (value) {
                    //         otp = value.toString();
                    //       },
                    //       onCodeSubmitted: (code) async {
                    //         print(code);
                    //       },
                    //     ),
                    //   ),
                    // ),
                    Container(
                      margin: EdgeInsets.all(10),
                      child: Form(
                        key: _formKey,
                        child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              SizedBox(
                                height: 60,
                                width: 60,
                                child: TextFormField(
                                  controller: _otp1,
                                  onChanged: ((value) {
                                    if (value.length == 1) {
                                      FocusScope.of(context).nextFocus();
                                    }
                                  }),
                                  decoration: new InputDecoration(
                                    focusedBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(15),
                                      borderSide: BorderSide(
                                          color: darkBlue, width: 2.0),
                                    ),
                                    enabledBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(15),
                                      borderSide: BorderSide(
                                          color: themeColor, width: 1.0),
                                    ),
                                  ),
                                  // style: Theme.of(context).textTheme.headline6,
                                  keyboardType: TextInputType.number,
                                  textAlign: TextAlign.center,
                                  inputFormatters: [
                                    LengthLimitingTextInputFormatter(1),
                                    FilteringTextInputFormatter.digitsOnly
                                  ],
                                ),
                              ),
                              SizedBox(
                                height: 60,
                                width: 60,
                                child: TextFormField(
                                  controller: _otp2,

                                  onChanged: ((value) {
                                    if (value.length == 1) {
                                      FocusScope.of(context).nextFocus();
                                    }
                                  }),
                                  decoration: new InputDecoration(
                                    focusedBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(15),
                                      borderSide: BorderSide(
                                          color: darkBlue, width: 2.0),
                                    ),
                                    enabledBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(15),
                                      borderSide: BorderSide(
                                          color: themeColor, width: 1.0),
                                    ),
                                  ),
                                  // style: Theme.of(context).textTheme.headline6,
                                  keyboardType: TextInputType.number,
                                  textAlign: TextAlign.center,
                                  inputFormatters: [
                                    LengthLimitingTextInputFormatter(1),
                                    FilteringTextInputFormatter.digitsOnly
                                  ],
                                ),
                              ),
                              SizedBox(
                                height: 60,
                                width: 60,
                                child: TextFormField(
                                  controller: _otp3,
                                  onChanged: ((value) {
                                    if (value.length == 1) {
                                      FocusScope.of(context).nextFocus();
                                    }
                                  }),
                                  decoration: InputDecoration(
                                    focusedBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(15),
                                      borderSide: const BorderSide(
                                          color: darkBlue, width: 2.0),
                                    ),
                                    enabledBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(15),
                                      borderSide: const BorderSide(
                                          color: themeColor, width: 1.0),
                                    ),
                                  ),
                                  // style: Theme.of(context).textTheme.headline6,
                                  keyboardType: TextInputType.number,
                                  textAlign: TextAlign.center,
                                  inputFormatters: [
                                    LengthLimitingTextInputFormatter(1),
                                    FilteringTextInputFormatter.digitsOnly
                                  ],
                                ),
                              ),
                              SizedBox(
                                height: 60,
                                width: 60,
                                child: TextFormField(
                                  controller: _otp4,
                                  onChanged: ((value) {
                                    if (value.length == 1) {
                                      FocusScope.of(context).nextFocus();
                                    }
                                  }),
                                  decoration: InputDecoration(
                                    focusedBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(15),
                                      borderSide: const BorderSide(
                                          color: darkBlue, width: 2.0),
                                    ),
                                    enabledBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(15),
                                      borderSide: const BorderSide(
                                          color: themeColor, width: 1.0),
                                    ),
                                  ),
                                  // style: Theme.of(context).textTheme.headline6,
                                  keyboardType: TextInputType.number,
                                  textAlign: TextAlign.center,
                                  inputFormatters: [
                                    LengthLimitingTextInputFormatter(1),
                                    FilteringTextInputFormatter.digitsOnly
                                  ],
                                ),
                              )
                            ]),
                      ),
                    ),
                    Container(
                      margin: EdgeInsets.only(left: 10, right: 10),
                      child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Countdown(
                              animation: StepTween(
                                begin:
                                    levelClock, // THIS IS A USER ENTERED NUMBER
                                end: 0,
                              ).animate(_animationController!),
                            ),
                            GestureDetector(
                              onTap: () async {
                                _animationController!.reset();
                                _animationController!.forward();
                              },
                              child: Container(
                                child: Row(
                                  children: [
                                    Text("Resend >",
                                        style: TextStyle(
                                          fontSize: 12,
                                          color: Color.fromRGBO(2, 44, 67, 1),
                                        ))
                                  ],
                                ),
                              ),
                            )
                          ]),
                    ),
                    SizedBox(
                      height: 25,
                    ),
                    GestureDetector(
                      onTap: () async {
                        String otpnumber =
                            '${_otp1.text}${_otp2.text}${_otp3.text}${_otp4.text}';

                        if (_formKey.currentState!.validate()) {
                          setState(() {
                            isloading = true;
                          });
                          Map<String, String> data = {
                            'phone': widget.mobile,
                            'otp': otpnumber
                          };
                          var response = await networkHandler.post(
                              'customer-verify_otp', data);

                          if (response.statusCode == 200) {
                            setState(() {
                              isloading = false;
                            });
                            Map jsonResponse = jsonDecode(response.body);
                            if (jsonResponse['status'] == true) {
                              Fluttertoast.showToast(
                                  msg: "OTP Verified Succesfully",
                                  toastLength: Toast.LENGTH_SHORT,
                                  gravity: ToastGravity.BOTTOM,
                                  timeInSecForIosWeb: 1,
                                  backgroundColor: themeColor,
                                  textColor: Colors.white,
                                  fontSize: 16.0);

                              getProfileDetails(widget.mobile);

                              Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) =>
                                          CustomerProfileScreen()));
                            } else {
                              Fluttertoast.showToast(
                                  msg: "Please enter correct OTP",
                                  toastLength: Toast.LENGTH_SHORT,
                                  gravity: ToastGravity.BOTTOM,
                                  timeInSecForIosWeb: 1,
                                  backgroundColor: themeColor,
                                  textColor: Colors.white,
                                  fontSize: 16.0);
                            }
                          }
                        }
                      },
                      child: Container(
                        margin: EdgeInsets.only(left: 10, right: 10),
                        width: 247,
                        height: 56,
                        decoration: BoxDecoration(
                            color: Colors.yellow,
                            borderRadius: BorderRadius.circular(25),
                            border: Border.all(width: 2, color: Colors.yellow)),
                        child: Center(
                          child: isloading == false
                              ? const Text(
                                  "CONFIRM",
                                  style: TextStyle(
                                      fontSize: 17, color: Colors.white),
                                )
                              : const CircularProgressIndicator(
                                  color: Colors.white,
                                ),
                        ),
                      ),
                    )
                  ]),
                ),
              ),
              Center(
                child: Container(
                  margin: EdgeInsets.only(
                    top: 50,
                  ),
                  width: 196,
                  child: Text(
                    "Welcome To ChatnFix Discover the Best Solution Easy & Simple",
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 16, color: Colors.black),
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }

  Widget MobileOTPVarification() {
    return Scaffold(
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Container(
            margin: EdgeInsets.only(top: 94, left: 21),
            height: 84,
            width: double.infinity,
            child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    height: 65,
                    child: Image.asset(
                      "assets/logo.png",
                      fit: BoxFit.fill,
                    ),
                  ),
                  SizedBox(
                    height: 5,
                  ),
                  Text(
                    "DISCOVER THE BEST SOLUTION EASY & SIMPLE",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                        fontSize: 12, color: Color.fromRGBO(112, 112, 112, 1)),
                  )
                ]),
          ),
          Container(
            margin: EdgeInsets.only(top: 60),
            height: 300,
            width: double.infinity,
            decoration: BoxDecoration(
                image:
                    DecorationImage(image: AssetImage("assets/SVG/back.png"))),
            child: Container(
              height: 281,
              width: 227,
              margin: EdgeInsets.only(left: 65, right: 65),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                color: Colors.white,
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.12),
                    offset: const Offset(
                      3.0,
                      3.0,
                    ),
                    blurRadius: 8.0,
                    spreadRadius: 2.0,
                  ), //BoxShadow
                  BoxShadow(
                    color: Colors.white,
                    offset: const Offset(0.0, 0.0),
                    blurRadius: 0.0,
                    spreadRadius: 0.0,
                  ), //BoxShadow
                ],
              ),
              child: Column(children: [
                Container(
                  height: 121,
                  child: Stack(
                    children: [
                      Container(
                        margin: EdgeInsets.only(top: 45),
                        height: 76,
                        width: 76,
                        padding: EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          border: Border.all(
                              width: 8,
                              color: Color.fromRGBO(240, 240, 240, 1)),
                        ),
                        child: Image(
                          image: AssetImage("assets/SVG/ic-contact-2x.png"),
                          fit: BoxFit.contain,
                        ),
                      ),
                      Positioned(
                          top: 37,
                          // left: 150,
                          right: 0,
                          child: Container(
                            height: 23,
                            width: 23,
                            decoration: BoxDecoration(
                                image: DecorationImage(
                                    image: AssetImage(
                                        "assets/SVG/message-2x.png"))),
                          ))
                    ],
                  ),
                ),
                SizedBox(
                  height: 16,
                ),
                Container(
                    child: Text(
                  "Enter 4 Digits code",
                  style: TextStyle(
                    fontSize: 12,
                    color: Color.fromRGBO(164, 164, 164, 1),
                  ),
                )),
                // Container(
                //   margin: EdgeInsets.all(10),
                //   child: Center(
                //     child: PinFieldAutoFill(
                //       controller: _otp,
                //       codeLength: 4,
                //       autoFocus: true,
                //       decoration: UnderlineDecoration(
                //         lineHeight: 2,
                //         lineStrokeCap: StrokeCap.square,
                //         bgColorBuilder: PinListenColorBuilder(
                //             Colors.green.shade200, Colors.yellow),
                //         colorBuilder: const FixedColorBuilder(Colors.white),
                //       ),
                //       onCodeChanged: (value) {
                //         otp = value.toString();
                //       },
                //       onCodeSubmitted: (code) async {
                //         print(code);
                //       },
                //     ),
                //   ),
                // ),
                Container(
                  margin: EdgeInsets.all(10),
                  child: Form(
                    key: _formKey,
                    child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          SizedBox(
                            height: 60,
                            width: 60,
                            child: TextFormField(
                              controller: _otp1,
                              onChanged: ((value) {
                                if (value.length == 1) {
                                  FocusScope.of(context).nextFocus();
                                }
                              }),
                              decoration: new InputDecoration(
                                focusedBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(15),
                                  borderSide:
                                      BorderSide(color: darkBlue, width: 2.0),
                                ),
                                enabledBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(15),
                                  borderSide:
                                      BorderSide(color: themeColor, width: 1.0),
                                ),
                              ),
                              // style: Theme.of(context).textTheme.headline6,
                              keyboardType: TextInputType.number,
                              textAlign: TextAlign.center,
                              inputFormatters: [
                                LengthLimitingTextInputFormatter(1),
                                FilteringTextInputFormatter.digitsOnly
                              ],
                            ),
                          ),
                          SizedBox(
                            height: 60,
                            width: 60,
                            child: TextFormField(
                              controller: _otp2,

                              onChanged: ((value) {
                                if (value.length == 1) {
                                  FocusScope.of(context).nextFocus();
                                }
                              }),
                              decoration: new InputDecoration(
                                focusedBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(15),
                                  borderSide:
                                      BorderSide(color: darkBlue, width: 2.0),
                                ),
                                enabledBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(15),
                                  borderSide:
                                      BorderSide(color: themeColor, width: 1.0),
                                ),
                              ),
                              // style: Theme.of(context).textTheme.headline6,
                              keyboardType: TextInputType.number,
                              textAlign: TextAlign.center,
                              inputFormatters: [
                                LengthLimitingTextInputFormatter(1),
                                FilteringTextInputFormatter.digitsOnly
                              ],
                            ),
                          ),
                          SizedBox(
                            height: 60,
                            width: 60,
                            child: TextFormField(
                              controller: _otp3,
                              onChanged: ((value) {
                                if (value.length == 1) {
                                  FocusScope.of(context).nextFocus();
                                }
                              }),
                              decoration: InputDecoration(
                                focusedBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(15),
                                  borderSide: const BorderSide(
                                      color: darkBlue, width: 2.0),
                                ),
                                enabledBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(15),
                                  borderSide: const BorderSide(
                                      color: themeColor, width: 1.0),
                                ),
                              ),
                              // style: Theme.of(context).textTheme.headline6,
                              keyboardType: TextInputType.number,
                              textAlign: TextAlign.center,
                              inputFormatters: [
                                LengthLimitingTextInputFormatter(1),
                                FilteringTextInputFormatter.digitsOnly
                              ],
                            ),
                          ),
                          SizedBox(
                            height: 60,
                            width: 60,
                            child: TextFormField(
                              controller: _otp4,
                              onChanged: ((value) {
                                if (value.length == 1) {
                                  FocusScope.of(context).nextFocus();
                                }
                              }),
                              decoration: InputDecoration(
                                focusedBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(15),
                                  borderSide: const BorderSide(
                                      color: darkBlue, width: 2.0),
                                ),
                                enabledBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(15),
                                  borderSide: const BorderSide(
                                      color: themeColor, width: 1.0),
                                ),
                              ),
                              // style: Theme.of(context).textTheme.headline6,
                              keyboardType: TextInputType.number,
                              textAlign: TextAlign.center,
                              inputFormatters: [
                                LengthLimitingTextInputFormatter(1),
                                FilteringTextInputFormatter.digitsOnly
                              ],
                            ),
                          )
                        ]),
                  ),
                ),
                Container(
                  margin: EdgeInsets.only(left: 10, right: 10),
                  child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Countdown(
                          animation: StepTween(
                            begin: levelClock, // THIS IS A USER ENTERED NUMBER
                            end: 0,
                          ).animate(_animationController!),
                        ),
                        GestureDetector(
                          onTap: () async {
                            _animationController!.reset();
                            _animationController!.forward();
                          },
                          child: Container(
                            child: Row(
                              children: [
                                Text("Resend >",
                                    style: TextStyle(
                                      fontSize: 12,
                                      color: Color.fromRGBO(2, 44, 67, 1),
                                    ))
                              ],
                            ),
                          ),
                        )
                      ]),
                ),
                SizedBox(
                  height: 25,
                ),
                GestureDetector(
                  onTap: () async {
                    String otpnumber =
                        '${_otp1.text}${_otp2.text}${_otp3.text}${_otp4.text}';

                    if (_formKey.currentState!.validate()) {
                      setState(() {
                        isloading = true;
                      });
                      Map<String, String> data = {
                        'phone': widget.mobile,
                        'otp': otpnumber
                      };
                      var response = await networkHandler.post(
                          'customer-verify_otp', data);

                      if (response.statusCode == 200) {
                        setState(() {
                          isloading = false;
                        });
                        Map jsonResponse = jsonDecode(response.body);
                        if (jsonResponse['status'] == true) {
                          Fluttertoast.showToast(
                              msg: "OTP Verified Succesfully",
                              toastLength: Toast.LENGTH_SHORT,
                              gravity: ToastGravity.BOTTOM,
                              timeInSecForIosWeb: 1,
                              backgroundColor: themeColor,
                              textColor: Colors.white,
                              fontSize: 16.0);

                          getProfileDetails(widget.mobile);

                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) =>
                                      CustomerProfileScreen()));
                        } else {
                          Fluttertoast.showToast(
                              msg: "Please enter correct OTP",
                              toastLength: Toast.LENGTH_SHORT,
                              gravity: ToastGravity.BOTTOM,
                              timeInSecForIosWeb: 1,
                              backgroundColor: themeColor,
                              textColor: Colors.white,
                              fontSize: 16.0);
                        }
                      }
                    }
                  },
                  child: Container(
                    margin: EdgeInsets.only(left: 10, right: 10),
                    width: 247,
                    height: 56,
                    decoration: BoxDecoration(
                        color: Colors.yellow,
                        borderRadius: BorderRadius.circular(25),
                        border: Border.all(width: 2, color: Colors.yellow)),
                    child: Center(
                      child: isloading == false
                          ? const Text(
                              "CONFIRM",
                              style:
                                  TextStyle(fontSize: 17, color: Colors.white),
                            )
                          : const CircularProgressIndicator(
                              color: Colors.white,
                            ),
                    ),
                  ),
                )
              ]),
            ),
          ),
          Center(
            child: Container(
              margin: EdgeInsets.only(
                top: 50,
              ),
              width: 196,
              child: Text(
                "Welcome To ChatnFix Discover the Best Solution Easy & Simple",
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 16, color: Colors.black),
              ),
            ),
          )
        ],
      ),
    );
  }

  List<CustomerP> _customerList = [];
  var customerService = CustomerProfileService();
  Future<void> getProfileDetails(String phone) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();

    var response = await customerService.viewCustomerProfile(phone);
    print(response);
    if (response != null) {
      _customerList = response;
      SharedPreferences pref = await SharedPreferences.getInstance();
      pref.setBool("islogin", true);
      pref.setString("phone", _customerList[0].phone);
      pref.setString("uid", _customerList[0].id.toString());
      if (_customerList[0].name != null) {
        Navigator.push(
            context,
            MaterialPageRoute(
                builder: (context) => BottomNavigationBarScreen(pageIndex: 0)));
      } else {
        Navigator.push(context,
            MaterialPageRoute(builder: (context) => CustomerProfileScreen()));
      }
    } else {
      throw Exception("Failed to load data");
    }
  }
}

class Countdown extends AnimatedWidget {
  Countdown({Key? key, required this.animation})
      : super(key: key, listenable: animation);
  Animation<int> animation;

  @override
  build(BuildContext context) {
    String value = '';
    Duration clockTimer = Duration(seconds: animation.value);
    print(animation.value);

    String timerText =
        '${clockTimer.inMinutes.remainder(60).toString()}:${clockTimer.inSeconds.remainder(60).toString().padLeft(2, '0')}';
    return Text(timerText,
        style: TextStyle(
          fontSize: 12,
          color: Color.fromRGBO(2, 44, 67, 1),
        ));
  }
}

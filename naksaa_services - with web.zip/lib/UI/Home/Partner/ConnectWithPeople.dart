import 'package:flutter/material.dart';
import 'package:naksaa_services/MainAsset/URL.dart';
import 'package:naksaa_services/UI/Home/Partner/VendorProfile.dart';
import 'package:naksaa_services/UI/REgister/project%20Assets/constants.dart';

import '../../../Service/AllVendorService.dart';
import '../../../model/AllVendorModel.dart';

class ConnectWithPeople extends StatefulWidget {
  const ConnectWithPeople({super.key});

  @override
  State<ConnectWithPeople> createState() => _ConnectWithPeopleState();
}

class _ConnectWithPeopleState extends State<ConnectWithPeople> {
  List<Datum> results = [];
  var vendorService = AllVendorService();

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getdata();
    // allVendor = vendorService.viewallVendor();
  }

  Future<List<Datum>> getdata() async {
    results = (await vendorService.viewallVendor())!;
    if (results != null) {
      return results;
    } else {
      throw Exception('Failed to load');
    }
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, constraints) {
      if (constraints.maxWidth > 1200) {
        return DesktopConnectWithPeople();
      } else if (constraints.maxWidth > 800 && constraints.maxWidth < 1200) {
        return DesktopConnectWithPeople();
      } else {
        return MobileConnectWithPeople();
      }
    });
  }

  Widget MobileConnectWithPeople() {
    return Container(
        height: 135,
        child: FutureBuilder(
          future: getdata(),
          builder: (BuildContext ctx, AsyncSnapshot<List> item) => item.hasData
              ? item.data!.length != 0
                  ? ListView.builder(
                      itemCount: results.length >= 10 ? 10 : results.length,
                      scrollDirection: Axis.horizontal,
                      itemBuilder: ((context, index) {
                        return GestureDetector(
                          onTap: () {
                            Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => VendorProfileScreen(
                                        vid: results[index].id.toString())));
                          },
                          child: Container(
                            height: 135,
                            width: 90,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10),
                              color: Color.fromRGBO(2, 44, 67, 1),
                            ),
                            margin: EdgeInsets.only(right: 10),
                            child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Container(
                                    height: 60,
                                    width: 60,
                                    decoration: BoxDecoration(
                                        color: Color.fromRGBO(2, 44, 67, 1),
                                        border: Border.all(
                                            width: 2,
                                            color:
                                                Color.fromRGBO(255, 215, 0, 1)),
                                        shape: BoxShape.circle,
                                        image: DecorationImage(
                                            image: NetworkImage(MainUrl +
                                                'vendor-image/' +
                                                results[index].photo),
                                            fit: BoxFit.contain)),
                                  ),
                                  SizedBox(
                                    height: 8,
                                  ),
                                  Container(
                                    child: Text(
                                      results[index].name,
                                      style: TextStyle(
                                          fontSize: 8,
                                          fontWeight: FontWeight.bold,
                                          color: Colors.white),
                                    ),
                                  ),
                                  SizedBox(
                                    height: 8,
                                  ),
                                  Container(
                                    child: Text(
                                      "₹ ${results[index].audicallprice} /min",
                                      style: TextStyle(
                                          fontSize: 8,
                                          fontWeight: FontWeight.bold,
                                          color: Colors.white),
                                    ),
                                  ),
                                  SizedBox(
                                    height: 8,
                                  ),
                                  Container(
                                    height: 17,
                                    width: 47,
                                    decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(10),
                                        border: Border.all(
                                            width: 1, color: Colors.white)),
                                    child: Center(
                                      child: Text(
                                        "Connect",
                                        style: TextStyle(
                                            fontSize: 8,
                                            fontWeight: FontWeight.bold,
                                            color: Colors.white),
                                      ),
                                    ),
                                  )
                                ]),
                          ),
                        );
                      }))
                  : Center(
                      child: Text("No Data Found"),
                    )
              : Center(
                  child: CircularProgressIndicator(),
                ),
        ));
  }

  Widget DesktopConnectWithPeople() {
    return Container(
        height: 250,
        child: FutureBuilder(
          future: getdata(),
          builder: (BuildContext ctx, AsyncSnapshot<List> item) => item.hasData
              ? item.data!.length != 0
                  ? ListView.builder(
                      itemCount: results.length >= 10 ? 10 : results.length,
                      scrollDirection: Axis.horizontal,
                      itemBuilder: ((context, index) {
                        return cardConnect(index);
                      }))
                  : Center(
                      child: Text("No Data Found"),
                    )
              : Center(
                  child: CircularProgressIndicator(),
                ),
        ));
  }

  List isHover = [false, false];
  Widget cardConnect(int index) {
    return InkWell(
      onHover: (s) {
        setState(() {
          s ? isHover[index] = true : isHover[index] = false;
        });
      },
      onTap: () {
        Navigator.push(
            context,
            MaterialPageRoute(
                builder: (context) =>
                    VendorProfileScreen(vid: results[index].id.toString())));
      },
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        height: 170,
        width: 170,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          color: Color.fromRGBO(2, 44, 67, 1),
        ),
        margin: EdgeInsets.only(right: 10),
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Container(
            height: 110,
            width: 110,
            decoration: BoxDecoration(
                color:
                    isHover[index] ? themeColor : Color.fromRGBO(2, 44, 67, 1),
                border:
                    Border.all(width: 2, color: Color.fromRGBO(255, 215, 0, 1)),
                shape: BoxShape.circle,
                image: DecorationImage(
                    image: NetworkImage(
                        MainUrl + 'vendor-image/' + results[index].photo),
                    fit: BoxFit.contain)),
          ),
          SizedBox(
            height: 8,
          ),
          Container(
            child: Text(
              results[index].name,
              style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  color: Colors.white),
            ),
          ),
          SizedBox(
            height: 8,
          ),
          Container(
            child: Text(
              "₹ ${results[index].audicallprice} /min",
              style: TextStyle(
                  fontSize: 11,
                  fontWeight: FontWeight.bold,
                  color: Colors.white),
            ),
          ),
          SizedBox(
            height: 8,
          ),
          Container(
            height: 28,
            width: 80,
            decoration: BoxDecoration(
                color: isHover[index] ? themeColor : Colors.transparent,
                borderRadius: BorderRadius.circular(10),
                border: Border.all(width: 1, color: Colors.white)),
            child: Center(
              child: Text(
                "Connect",
                style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                    color: Colors.white),
              ),
            ),
          )
        ]),
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:naksaa_services/UI/REgister/project%20Assets/MainSlider.dart';

class ServiceDescription extends StatefulWidget {
  String title;
  ServiceDescription({super.key, required this.title});

  @override
  State<ServiceDescription> createState() =>
      _ServiceDescriptionState(this.title);
}

class _ServiceDescriptionState extends State<ServiceDescription> {
  String title;
  _ServiceDescriptionState(this.title);
  @override
  Widget build(BuildContext context) {
    return Container(
      child: Center(child: MainSlider()),
    );
  }
}

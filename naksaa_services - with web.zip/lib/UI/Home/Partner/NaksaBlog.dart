import 'package:flutter/material.dart';
import 'package:naksaa_services/UI/Home/Partner/CallRequest.dart';

class NaksaBlog extends StatefulWidget {
  const NaksaBlog({super.key});

  @override
  State<NaksaBlog> createState() => _NaksaBlogState();
}

class _NaksaBlogState extends State<NaksaBlog> {
  @override
  Widget build(BuildContext context) {
    return Container(
      height: 190,
      child: ListView.builder(
          itemCount: 10,
          scrollDirection: Axis.horizontal,
          itemBuilder: (context, index) {
            return GestureDetector(
              onTap: () {
                // Navigator.push(
                //     context,
                //     MaterialPageRoute(
                //         builder: (context) => IncomingCallRequest(
                //             channelname: 'bbkj',
                //             token: 'token',
                //             vendorimage: 'vendorimage')));
              },
              child: Container(
                margin: EdgeInsets.only(right: 10),
                // decoration: BoxDecoration(
                //     border:
                //         Border.all(width: 1, color: Color.fromRGBO(2, 44, 67, 1)),
                //     borderRadius: BorderRadius.circular(10)),
                child: Column(children: [
                  Container(
                    height: 143,
                    width: 236,
                    child: Stack(children: [
                      Container(
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.only(
                                topLeft: Radius.circular(10),
                                topRight: Radius.circular(10)),
                            image: DecorationImage(
                                image: NetworkImage(
                                    "https://images.indianexpress.com/2020/11/diwali-feature-1.jpg"),
                                fit: BoxFit.fill)),
                      ),
                      Positioned(
                          top: 9,
                          left: 186,
                          child: Container(
                            padding: EdgeInsets.symmetric(
                                vertical: 2, horizontal: 5),
                            decoration: BoxDecoration(
                                color: Colors.white.withOpacity(0.78),
                                borderRadius: BorderRadius.circular(5)),
                            child: Row(children: [
                              Icon(
                                Icons.remove_red_eye_rounded,
                                size: 15,
                              ),
                              Text(
                                "3222",
                                style: TextStyle(
                                    fontSize: 8, fontWeight: FontWeight.bold),
                              )
                            ]),
                          ))
                    ]),
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  Container(
                    width: 236,
                    child: Text(
                      "Navratri 2022 is round the corner: Here is your whole information about Navratri parv",
                      textAlign: TextAlign.left,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style:
                          TextStyle(fontSize: 13, fontWeight: FontWeight.bold),
                    ),
                  )
                ]),
              ),
            );
          }),
    );
  }
}

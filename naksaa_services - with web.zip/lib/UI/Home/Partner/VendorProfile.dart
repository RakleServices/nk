import 'dart:convert';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:flutter_smart_dialog/flutter_smart_dialog.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:naksaa_services/API/NetworkProvider.dart';
import 'package:naksaa_services/MainAsset/URL.dart';
import 'package:naksaa_services/Service/WalletService.dart';
import 'package:naksaa_services/UI/Home/Partner/VendorAvailability.dart';
import 'package:naksaa_services/UI/Home/Partner/VendorProfileWork.dart';
import 'dart:math' as math;

import 'package:naksaa_services/UI/REgister/project%20Assets/constants.dart';
import 'package:naksaa_services/model/RatingReviewModel.dart';
import 'package:naksaa_services/model/VendorDetailsModel.dart';
import 'package:naksaa_services/model/VendorWorkModel.dart';
import 'package:naksaa_services/model/VenodrFollowerCheck.dart';
import 'package:screenshot/screenshot.dart';
import 'package:share_plus/share_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../../Service/AllVendorService.dart';
import '../../../Service/VendorFollowerChekerService.dart';
import '../../../model/AllVendorModel.dart';
import '../../../model/CustomerWalletModel.dart';
import '../Utility/PaymentDetails.dart';
import '../Utility/rechargeNowUtility.dart';
import 'ChatRequest.dart';
import 'VideoCall/VideoCallandAudioCallModal.dart';

class VendorProfileScreen extends StatefulWidget {
  String vid;
  VendorProfileScreen({super.key, required this.vid});

  @override
  State<VendorProfileScreen> createState() =>
      _VendorProfileScreenState(this.vid);
}

class _VendorProfileScreenState extends State<VendorProfileScreen> {
  String vid;
  _VendorProfileScreenState(this.vid);
  List<Vdatum> results = [];
  List<VendorWork> wportdata = [];
  List<RatingData> ratingReviewData = [];
  var vendorService = AllVendorService();
  var networkProvider = NetworkHandler();

  @override
  void initState() {
    super.initState();
    // getVendorDetails();
    // getWorkPortfolio();
    getWalletAmount();
    getReviews();
    _getvendorFollower();
  }

  Future<List<Vdatum>> getVendorDetails() async {
    var response = await vendorService.viewSingleVendor(vid);

    results = VendorDetailsmodel.fromJson(jsonDecode(response)).vdata.toList();
    if (results != null) {
      return results;
    } else {
      throw Exception('Failed to load');
    }
  }

  Future<List<VendorWork>> getWorkPortfolio() async {
    wportdata = await vendorService.viewWorkPortfolio(vid);

    if (wportdata != null) {
      return wportdata;
    } else {
      throw Exception('Failed to load');
    }
  }

  bool isfollowing = false;

  List<FollowDatum> _vendorFollwer = [];
  var followerCheker = FollowerService();
  Future<void> _getvendorFollower() async {
    SharedPreferences pref = await SharedPreferences.getInstance();
    String? uid = pref.getString("uid");
    print(uid!);
    var response = await followerCheker.viewVendorFollower(vid, uid);
    if (response != null) {
      _vendorFollwer = response;
      if (_vendorFollwer[0].follow == "true") {
        setState(() {
          isfollowing = true;
        });
      }
    } else {
      setState(() {
        isfollowing = false;
      });
    }
  }

  ScreenshotController screenshotController = ScreenshotController();
  Future<List<RatingData>> getReviews() async {
    ratingReviewData = await vendorService.viewRatingReview(vid);
    print("vhjv");
    print(ratingReviewData);
    if (ratingReviewData != null) {
      return ratingReviewData;
    } else {
      throw Exception('Failed to load');
    }
  }

  Future<void> _takeScreenShotAndShare() async {
    final imageFile = await screenshotController.capture();
    print("captured");
    Uint8List pngimage = imageFile!;
    Share.shareFiles(['${imageFile}'], text: "This is okay");
  }

  bool isloading = false;
  List<Walletdatum> _walletList = [];
  var walletService = CustomerWalletService();
  Future<void> getWalletAmount() async {
    SharedPreferences pref = await SharedPreferences.getInstance();
    String? uid = pref.getString("uid");
    var response = await walletService.viewCustomerWallet(uid!);
    if (response != null) {
      setState(() {
        isloading = true;
      });
      _walletList = response;
    }
  }

  final scaffoldKey = GlobalKey<ScaffoldState>();
  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, constraints) {
      if (constraints.maxWidth > 1200) {
        return DesktopVendorProfile();
      } else if (constraints.maxWidth > 800 && constraints.maxWidth < 1200) {
        return DesktopVendorProfile();
      } else {
        return MobileVendorProfile();
      }
    });
  }

  Widget DesktopVendorProfile() {
    return Scaffold(
      key: scaffoldKey,
      backgroundColor: Colors.white,
      body: SingleChildScrollView(
          child: Column(
        children: [
          FutureBuilder(
              future: getVendorDetails(),
              builder: (BuildContext ctx, AsyncSnapshot<List> item) => item
                      .hasData
                  ? item.data!.length != 0
                      ? Container(
                          height: 650,
                          color: Color.fromRGBO(255, 215, 0, 1),
                          margin: EdgeInsets.only(top: 35),
                          child: Column(children: [
                            Container(
                              margin: EdgeInsets.only(left: 14, right: 14),
                              height: 50,
                              child: Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    GestureDetector(
                                      onTap: () {
                                        Navigator.pop(context);
                                      },
                                      child: Icon(
                                        Icons.arrow_back,
                                        size: 25,
                                      ),
                                    ),
                                    IconButton(
                                      icon: const Icon(
                                        Icons.share,
                                        size: 25,
                                      ),
                                      onPressed: () async {
                                        // _takeScreenShotAndShare();
                                        // screenshotController
                                        //     .capture(
                                        //         delay:
                                        //             Duration(milliseconds: 10))
                                        //     .then((capturedImage) async {
                                        //   // ShowCapturedWidget(
                                        //   //     context, capturedImage!);
                                        //   await Share.shareFiles(
                                        //       ['${capturedImage}'],
                                        //       text: 'Great picture');
                                        // }).catchError((onError) {
                                        //   print(onError);
                                        // });
                                      },
                                    )
                                  ]),
                            ),
                            Container(
                              height: 285,
                              width: 1000,
                              child: Row(
                                children: [
                                  Column(
                                    children: [
                                      Container(
                                        height: 220,
                                        width: 300,
                                        child: Stack(
                                          alignment: Alignment.topCenter,
                                          children: [
                                            Positioned(
                                              top: 5,
                                              child: Container(
                                                height: 200,
                                                width: 200,
                                                decoration: BoxDecoration(
                                                    shape: BoxShape.circle,
                                                    border: Border.all(
                                                        width: 2,
                                                        color: lightblueColor),
                                                    image: DecorationImage(
                                                        image: NetworkImage(
                                                            MainUrl +
                                                                'vendor-image/' +
                                                                results[0]
                                                                    .photo),
                                                        fit: BoxFit.contain)),
                                              ),
                                            ),
                                            Positioned(
                                                top: 5,
                                                left: 190,
                                                child: Container(
                                                  height: 40,
                                                  width: 40,
                                                  decoration: BoxDecoration(
                                                      image: DecorationImage(
                                                          image: AssetImage(
                                                              "assets/SVG/star2-2x.png"),
                                                          fit: BoxFit.fill)),
                                                )),
                                          ],
                                        ),
                                      ),
                                      SizedBox(
                                        height: 5,
                                      ),
                                      GestureDetector(
                                        onTap: () async {
                                          SharedPreferences pref =
                                              await SharedPreferences
                                                  .getInstance();
                                          String? uid = pref.getString("uid");
                                          followVendor(uid!, vid, !isfollowing);
                                        },
                                        child: Container(
                                          height: 37,
                                          width: 121,
                                          decoration: BoxDecoration(
                                              borderRadius:
                                                  BorderRadius.circular(45),
                                              color: Color.fromRGBO(
                                                  17, 81, 115, 1)),
                                          child: Center(
                                            child: isfollowing != true
                                                ? Text(
                                                    "Follow",
                                                    style: TextStyle(
                                                        color: Colors.white,
                                                        fontWeight:
                                                            FontWeight.bold,
                                                        fontSize: 15),
                                                  )
                                                : Text(
                                                    "Following",
                                                    style: TextStyle(
                                                        color: Colors.white,
                                                        fontWeight:
                                                            FontWeight.bold,
                                                        fontSize: 15),
                                                  ),
                                          ),
                                        ),
                                      ),
                                      SizedBox(
                                        height: 20,
                                      ),
                                    ],
                                  ),
                                  Container(
                                    child: Column(
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Container(
                                            child: Column(
                                                mainAxisAlignment:
                                                    MainAxisAlignment.start,
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                children: [
                                                  const SizedBox(
                                                    height: 20,
                                                  ),
                                                  Text(
                                                    results[0].name,
                                                    style: const TextStyle(
                                                        fontSize: 22,
                                                        color: Color.fromRGBO(
                                                            17, 81, 115, 1),
                                                        fontWeight:
                                                            FontWeight.bold),
                                                  ),
                                                  SizedBox(
                                                    height: 10,
                                                  ),
                                                  Text(
                                                    results[0].primaryskills,
                                                    style: const TextStyle(
                                                        fontSize: 16,
                                                        color: Colors.black,
                                                        fontWeight:
                                                            FontWeight.bold),
                                                  ),
                                                  const SizedBox(
                                                    height: 10,
                                                  ),
                                                  Text(
                                                    results[0].language,
                                                    style: const TextStyle(
                                                        fontSize: 16,
                                                        color: Colors.black,
                                                        fontWeight:
                                                            FontWeight.bold),
                                                  ),
                                                  const SizedBox(
                                                    height: 10,
                                                  ),
                                                  const Text(
                                                    "Exp: 5 Years",
                                                    style: TextStyle(
                                                        fontSize: 14,
                                                        color: Colors.black,
                                                        fontWeight:
                                                            FontWeight.bold),
                                                  ),
                                                  SizedBox(
                                                    height: 10,
                                                  ),
                                                  Text(
                                                    "₹ ${results[0].audicallprice} / min",
                                                    style: const TextStyle(
                                                        fontSize: 15,
                                                        color: Colors.black,
                                                        fontWeight:
                                                            FontWeight.bold),
                                                  ),
                                                  SizedBox(
                                                    height: 17,
                                                  ),
                                                  Container(
                                                    width: 650,
                                                    child: Row(
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .spaceBetween,
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .start,
                                                        children: [
                                                          Container(
                                                            child: Column(
                                                                children: [
                                                                  Text(
                                                                    "Chat",
                                                                    style: TextStyle(
                                                                        fontSize:
                                                                            18,
                                                                        color: Colors
                                                                            .black,
                                                                        fontWeight:
                                                                            FontWeight.bold),
                                                                  ),
                                                                  SizedBox(
                                                                    height: 10,
                                                                  ),
                                                                  Text(
                                                                    "49k",
                                                                    style: TextStyle(
                                                                        fontSize:
                                                                            30,
                                                                        color: Color.fromRGBO(
                                                                            17,
                                                                            81,
                                                                            115,
                                                                            1),
                                                                        fontWeight:
                                                                            FontWeight.bold),
                                                                  ),
                                                                  SizedBox(
                                                                    height: 5,
                                                                  ),
                                                                  Text(
                                                                    "mins",
                                                                    style: TextStyle(
                                                                        fontSize:
                                                                            14,
                                                                        color: Colors
                                                                            .black,
                                                                        fontWeight:
                                                                            FontWeight.bold),
                                                                  ),
                                                                ]),
                                                          ),
                                                          Container(
                                                            child: Column(
                                                                children: [
                                                                  Text(
                                                                    "Calls",
                                                                    style: TextStyle(
                                                                        fontSize:
                                                                            18,
                                                                        color: Colors
                                                                            .black,
                                                                        fontWeight:
                                                                            FontWeight.bold),
                                                                  ),
                                                                  SizedBox(
                                                                    height: 10,
                                                                  ),
                                                                  Text(
                                                                    "49k",
                                                                    style: TextStyle(
                                                                        fontSize:
                                                                            30,
                                                                        color: Color.fromRGBO(
                                                                            17,
                                                                            81,
                                                                            115,
                                                                            1),
                                                                        fontWeight:
                                                                            FontWeight.bold),
                                                                  ),
                                                                  SizedBox(
                                                                    height: 5,
                                                                  ),
                                                                  Text(
                                                                    "mins",
                                                                    style: TextStyle(
                                                                        fontSize:
                                                                            14,
                                                                        color: Colors
                                                                            .black,
                                                                        fontWeight:
                                                                            FontWeight.bold),
                                                                  ),
                                                                ]),
                                                          ),
                                                          Container(
                                                            child: Column(
                                                                children: [
                                                                  Text(
                                                                    "Video Chat",
                                                                    style: TextStyle(
                                                                        fontSize:
                                                                            18,
                                                                        color: Colors
                                                                            .black,
                                                                        fontWeight:
                                                                            FontWeight.bold),
                                                                  ),
                                                                  SizedBox(
                                                                    height: 10,
                                                                  ),
                                                                  Text(
                                                                    "500",
                                                                    style: TextStyle(
                                                                        fontSize:
                                                                            30,
                                                                        color: Color.fromRGBO(
                                                                            17,
                                                                            81,
                                                                            115,
                                                                            1),
                                                                        fontWeight:
                                                                            FontWeight.bold),
                                                                  ),
                                                                  SizedBox(
                                                                    height: 5,
                                                                  ),
                                                                  Text(
                                                                    "mins",
                                                                    style: TextStyle(
                                                                        fontSize:
                                                                            14,
                                                                        color: Colors
                                                                            .black,
                                                                        fontWeight:
                                                                            FontWeight.bold),
                                                                  ),
                                                                ]),
                                                          ),
                                                          Container(
                                                            child: Column(
                                                                children: const [
                                                                  Text(
                                                                    "Followers",
                                                                    style: TextStyle(
                                                                        fontSize:
                                                                            18,
                                                                        color: Colors
                                                                            .black,
                                                                        fontWeight:
                                                                            FontWeight.bold),
                                                                  ),
                                                                  SizedBox(
                                                                    height: 10,
                                                                  ),
                                                                  Text(
                                                                    "2k",
                                                                    style: TextStyle(
                                                                        fontSize:
                                                                            30,
                                                                        color: Color.fromRGBO(
                                                                            17,
                                                                            81,
                                                                            115,
                                                                            1),
                                                                        fontWeight:
                                                                            FontWeight.bold),
                                                                  ),
                                                                  SizedBox(
                                                                    height: 5,
                                                                  ),
                                                                  Text(
                                                                    "Following",
                                                                    style: TextStyle(
                                                                        fontSize:
                                                                            14,
                                                                        color: Colors
                                                                            .black,
                                                                        fontWeight:
                                                                            FontWeight.bold),
                                                                  ),
                                                                ]),
                                                          )
                                                        ]),
                                                  )
                                                ]),
                                          ),
                                        ]),
                                  )
                                ],
                              ),
                            ),
                            Container(
                                margin: EdgeInsets.only(
                                    top: 55, left: 20, right: 70),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      "About ${results[0].name}",
                                      textAlign: TextAlign.center,
                                      style: TextStyle(
                                          fontSize: 13,
                                          fontWeight: FontWeight.bold),
                                    ),
                                    SizedBox(
                                      height: 20,
                                    ),
                                    Text(
                                      results[0].aboutus,
                                      textAlign: TextAlign.left,
                                      style: TextStyle(
                                          fontSize: 13,
                                          fontWeight: FontWeight.normal,
                                          color:
                                              Color.fromRGBO(17, 81, 115, 1)),
                                    ),
                                  ],
                                ))
                          ]),
                        )
                      : Center(
                          child: Text("No Data Found"),
                        )
                  : Container(
                      height: 800,
                      child: Center(
                        child: CircularProgressIndicator(),
                      ),
                    )),
          SizedBox(
            height: 22,
          ),
          Container(
            child: Column(children: [
              Container(
                margin: EdgeInsets.only(left: 20, right: 20, top: 30),
                child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        "Photos",
                        style: TextStyle(
                            fontSize: 13,
                            fontWeight: FontWeight.normal,
                            color: Colors.black),
                      ),
                      Transform.rotate(
                          angle: 180 * math.pi / 180,
                          child: GestureDetector(
                              onTap: () {
                                Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) => VendorProfileWork(
                                            wportdata: wportdata)));
                              },
                              child: Icon(Icons.arrow_back)))
                    ]),
              ),
              Container(
                height: 110,
                margin: EdgeInsets.all(15),
                child: FutureBuilder(
                    future: getWorkPortfolio(),
                    builder: (BuildContext ctx, AsyncSnapshot<List> item) =>
                        item.hasData
                            ? item.data!.length != 0
                                ? ListView.builder(
                                    itemCount: wportdata.length,
                                    scrollDirection: Axis.horizontal,
                                    shrinkWrap: true,
                                    itemBuilder: (context, index) {
                                      return GestureDetector(
                                        onTap: () async {
                                          await showDialog(
                                              context: context,
                                              builder: (_) => ImageDialog(
                                                  MainUrl +
                                                      'vendor-work/' +
                                                      wportdata[index].photo));
                                        },
                                        child: Container(
                                          height: 110,
                                          width: 110,
                                          margin: EdgeInsets.only(right: 10),
                                          decoration: BoxDecoration(
                                              borderRadius:
                                                  BorderRadius.circular(50),
                                              image: DecorationImage(
                                                  image: NetworkImage(MainUrl +
                                                      'vendor-work/' +
                                                      wportdata[index].photo),
                                                  fit: BoxFit.fill)),
                                        ),
                                      );
                                    })
                                : Center(
                                    child: Text("No Data Found"),
                                  )
                            : Container(
                                height: 800,
                                child: Center(
                                  child: CircularProgressIndicator(),
                                ),
                              )),
              )
            ]),
          ),
          Column(
            children: [
              Container(
                margin: EdgeInsets.only(left: 15, right: 15),
                height: 208,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  color: Colors.white,
                  boxShadow: [
                    BoxShadow(
                      color: Color.fromRGBO(0, 0, 0, 0.16),
                      offset: const Offset(
                        3.0,
                        3.0,
                      ),
                      blurRadius: 6.0,
                      spreadRadius: 2.0,
                    ), //BoxShadow
                    BoxShadow(
                      color: Colors.white,
                      offset: const Offset(0.0, 0.0),
                      blurRadius: 0.0,
                      spreadRadius: 0.0,
                    ), //BoxShadow
                  ],
                ),
                child: Column(children: [
                  Container(
                    margin: EdgeInsets.only(left: 15, right: 15, top: 22),
                    child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            "Rating & Reviews",
                            style: TextStyle(
                                fontSize: 13,
                                fontWeight: FontWeight.normal,
                                color: Colors.black),
                          ),
                          Transform.rotate(
                              angle: 180 * math.pi / 180,
                              child: Icon(Icons.arrow_back))
                        ]),
                  ),
                  Container(
                    margin: EdgeInsets.only(top: 10),
                    child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          Container(
                            width: 100,
                            child: Column(children: [
                              Text(
                                "4.93",
                                style: TextStyle(
                                    fontSize: 38,
                                    fontWeight: FontWeight.bold,
                                    color: blueColor),
                              ),
                              SizedBox(
                                height: 10,
                              ),
                              Container(
                                child: RatingBarIndicator(
                                  rating: 4.5,
                                  itemBuilder: (context, index) => Icon(
                                    Icons.star,
                                    color: Colors.amber,
                                  ),
                                  itemCount: 5,
                                  itemSize: 13.0,
                                  direction: Axis.horizontal,
                                ),
                              ),
                              SizedBox(
                                height: 10,
                              ),
                              Text(
                                "734 Reviews",
                                style: TextStyle(
                                    fontSize: 11,
                                    fontWeight: FontWeight.bold,
                                    color: blueColor),
                              ),
                            ]),
                          ),
                          Container(
                            child: Column(
                              children: [
                                Row(children: [
                                  Container(
                                    child: Text(
                                      "5",
                                      style: TextStyle(
                                          fontSize: 16, color: blueColor),
                                    ),
                                  ),
                                  SizedBox(
                                    width: 15,
                                  ),
                                  Container(
                                    height: 20,
                                    width: 145,
                                    decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(10),
                                        boxShadow: [
                                          BoxShadow(
                                            color:
                                                Color.fromRGBO(0, 0, 0, 0.16),
                                            offset: const Offset(
                                              3.0,
                                              3.0,
                                            ),
                                            blurRadius: 6.0,
                                            spreadRadius: 2.0,
                                          ), //BoxShadow
                                          BoxShadow(
                                            color: Colors.white,
                                            offset: const Offset(0.0, 0.0),
                                            blurRadius: 0.0,
                                            spreadRadius: 0.0,
                                          ), //BoxShadow
                                        ],
                                        color: Colors.white),
                                    child: Container(
                                      height: 20,
                                      width: 85,
                                      decoration: BoxDecoration(
                                          borderRadius:
                                              BorderRadius.circular(10),
                                          color: themeColor),
                                    ),
                                  )
                                ]),
                                SizedBox(
                                  height: 10,
                                ),
                                Row(children: [
                                  Container(
                                    child: Text(
                                      "4",
                                      style: TextStyle(
                                          fontSize: 16, color: blueColor),
                                    ),
                                  ),
                                  SizedBox(
                                    width: 15,
                                  ),
                                  Container(
                                    height: 20,
                                    width: 145,
                                    decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(10),
                                        boxShadow: [
                                          BoxShadow(
                                            color:
                                                Color.fromRGBO(0, 0, 0, 0.16),
                                            offset: const Offset(
                                              3.0,
                                              3.0,
                                            ),
                                            blurRadius: 6.0,
                                            spreadRadius: 2.0,
                                          ), //BoxShadow
                                          BoxShadow(
                                            color: Colors.white,
                                            offset: const Offset(0.0, 0.0),
                                            blurRadius: 0.0,
                                            spreadRadius: 0.0,
                                          ), //BoxShadow
                                        ],
                                        color: Colors.white),
                                    child: Container(
                                      height: 20,
                                      width: 85,
                                      decoration: BoxDecoration(
                                          borderRadius:
                                              BorderRadius.circular(10),
                                          color: themeColor),
                                    ),
                                  )
                                ]),
                                const SizedBox(
                                  height: 10,
                                ),
                                Row(children: [
                                  Container(
                                    child: const Text(
                                      "3",
                                      style: TextStyle(
                                          fontSize: 16, color: blueColor),
                                    ),
                                  ),
                                  const SizedBox(
                                    width: 15,
                                  ),
                                  Container(
                                    height: 20,
                                    width: 145,
                                    decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(10),
                                        boxShadow: const [
                                          BoxShadow(
                                            color:
                                                Color.fromRGBO(0, 0, 0, 0.16),
                                            offset: Offset(
                                              3.0,
                                              3.0,
                                            ),
                                            blurRadius: 6.0,
                                            spreadRadius: 2.0,
                                          ), //BoxShadow
                                          BoxShadow(
                                            color: Colors.white,
                                            offset: Offset(0.0, 0.0),
                                            blurRadius: 0.0,
                                            spreadRadius: 0.0,
                                          ), //BoxShadow
                                        ],
                                        color: Colors.white),
                                    child: Container(
                                      height: 20,
                                      width: 85,
                                      decoration: BoxDecoration(
                                          borderRadius:
                                              BorderRadius.circular(10),
                                          color: themeColor),
                                    ),
                                  )
                                ]),
                                SizedBox(
                                  height: 10,
                                ),
                                Row(children: [
                                  Container(
                                    child: Text(
                                      "2",
                                      style: TextStyle(
                                          fontSize: 16, color: blueColor),
                                    ),
                                  ),
                                  SizedBox(
                                    width: 15,
                                  ),
                                  Container(
                                    height: 20,
                                    width: 145,
                                    decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(10),
                                        boxShadow: [
                                          BoxShadow(
                                            color:
                                                Color.fromRGBO(0, 0, 0, 0.16),
                                            offset: const Offset(
                                              3.0,
                                              3.0,
                                            ),
                                            blurRadius: 6.0,
                                            spreadRadius: 2.0,
                                          ), //BoxShadow
                                          BoxShadow(
                                            color: Colors.white,
                                            offset: const Offset(0.0, 0.0),
                                            blurRadius: 0.0,
                                            spreadRadius: 0.0,
                                          ), //BoxShadow
                                        ],
                                        color: Colors.white),
                                    child: Container(
                                      height: 20,
                                      width: 85,
                                      decoration: BoxDecoration(
                                          borderRadius:
                                              BorderRadius.circular(10),
                                          color: themeColor),
                                    ),
                                  )
                                ]),
                                SizedBox(
                                  height: 10,
                                ),
                                Row(children: [
                                  Container(
                                    child: Text(
                                      "1",
                                      style: TextStyle(
                                          fontSize: 16, color: blueColor),
                                    ),
                                  ),
                                  SizedBox(
                                    width: 15,
                                  ),
                                  Container(
                                    height: 20,
                                    width: 145,
                                    decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(10),
                                        boxShadow: [
                                          BoxShadow(
                                            color:
                                                Color.fromRGBO(0, 0, 0, 0.16),
                                            offset: const Offset(
                                              3.0,
                                              3.0,
                                            ),
                                            blurRadius: 6.0,
                                            spreadRadius: 2.0,
                                          ), //BoxShadow
                                          BoxShadow(
                                            color: Colors.white,
                                            offset: const Offset(0.0, 0.0),
                                            blurRadius: 0.0,
                                            spreadRadius: 0.0,
                                          ), //BoxShadow
                                        ],
                                        color: Colors.white),
                                    child: Container(
                                      height: 20,
                                      width: 85,
                                      decoration: BoxDecoration(
                                          borderRadius:
                                              BorderRadius.circular(10),
                                          color: themeColor),
                                    ),
                                  )
                                ]),
                              ],
                            ),
                          )
                        ]),
                  )
                ]),
              ),
              Container(
                height: 400,
                child: Column(children: [
                  Container(
                    margin: EdgeInsets.only(left: 20, right: 20, top: 10),
                    child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            "User Reviews",
                            style: TextStyle(
                                fontSize: 13,
                                fontWeight: FontWeight.normal,
                                color: Colors.black),
                          ),
                          InkWell(
                            onTap: () {
                              scaffoldKey.currentState!.showBottomSheet(
                                  (context) => StatefulBuilder(builder:
                                          (BuildContext context,
                                              StateSetter setState) {
                                        return DraggableScrollableSheet(
                                          expand: false,
                                          maxChildSize: 0.8,
                                          minChildSize: 0.75,
                                          initialChildSize: 0.75,
                                          builder: (BuildContext context,
                                              ScrollController
                                                  scrollController) {
                                            return AllReviews(scrollController);
                                          },
                                        );
                                      }));
                            },
                            child: Transform.rotate(
                                angle: 180 * math.pi / 180,
                                child: Icon(Icons.arrow_back)),
                          )
                        ]),
                  ),
                  Container(
                    // height: 280,
                    margin: EdgeInsets.only(left: 15, right: 15, top: 10),
                    child: MediaQuery.removePadding(
                      context: context,
                      removeTop: true,
                      child: FutureBuilder(
                          future: getReviews(),
                          builder: (BuildContext ctx,
                                  AsyncSnapshot<List> item) =>
                              item.hasData
                                  ? item.data!.length != 0
                                      ? ListView.builder(
                                          itemCount:
                                              ratingReviewData.length >= 3
                                                  ? 3
                                                  : ratingReviewData.length,
                                          shrinkWrap: true,
                                          physics:
                                              NeverScrollableScrollPhysics(),
                                          itemBuilder: (context, index) {
                                            return Container(
                                              padding: EdgeInsets.all(15),
                                              margin:
                                                  EdgeInsets.only(bottom: 10),
                                              // height: 130,
                                              decoration: BoxDecoration(
                                                borderRadius:
                                                    BorderRadius.circular(10),
                                                color: Colors.white,
                                                boxShadow: [
                                                  BoxShadow(
                                                    color: Color.fromRGBO(
                                                        0, 0, 0, 0.16),
                                                    offset: const Offset(
                                                      3.0,
                                                      3.0,
                                                    ),
                                                    blurRadius: 6.0,
                                                    spreadRadius: 2.0,
                                                  ), //BoxShadow
                                                  BoxShadow(
                                                    color: Colors.white,
                                                    offset:
                                                        const Offset(0.0, 0.0),
                                                    blurRadius: 0.0,
                                                    spreadRadius: 0.0,
                                                  ), //BoxShadow
                                                ],
                                              ),
                                              child: Column(
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.start,
                                                  children: [
                                                    Row(
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .spaceBetween,
                                                      children: [
                                                        Container(
                                                          child: Row(children: [
                                                            Container(
                                                              height: 44,
                                                              width: 44,
                                                              decoration: BoxDecoration(
                                                                  shape: BoxShape
                                                                      .circle,
                                                                  image: DecorationImage(
                                                                      image: NetworkImage(MainUrl +
                                                                          "customer-image/" +
                                                                          ratingReviewData[index]
                                                                              .photo),
                                                                      fit: BoxFit
                                                                          .fill)),
                                                            ),
                                                            SizedBox(
                                                              width: 15,
                                                            ),
                                                            Container(
                                                              child: Column(
                                                                  crossAxisAlignment:
                                                                      CrossAxisAlignment
                                                                          .start,
                                                                  children: [
                                                                    Text(
                                                                      ratingReviewData[
                                                                              index]
                                                                          .name,
                                                                      style: const TextStyle(
                                                                          fontSize:
                                                                              14,
                                                                          fontWeight:
                                                                              FontWeight.bold),
                                                                    ),
                                                                    Container(
                                                                      child:
                                                                          RatingBarIndicator(
                                                                        rating: double.parse(ratingReviewData[index]
                                                                            .rating
                                                                            .toString()),
                                                                        itemBuilder:
                                                                            (context, index) =>
                                                                                Icon(
                                                                          Icons
                                                                              .star,
                                                                          color:
                                                                              Colors.amber,
                                                                        ),
                                                                        itemCount:
                                                                            5,
                                                                        itemSize:
                                                                            13.0,
                                                                        direction:
                                                                            Axis.horizontal,
                                                                      ),
                                                                    ),
                                                                  ]),
                                                            ),
                                                          ]),
                                                        ),
                                                        Container(
                                                          child:
                                                              PopupMenuButton<
                                                                  int>(
                                                            itemBuilder:
                                                                (context) => [
                                                              // popupmenu item 1
                                                              PopupMenuItem(
                                                                value: 1,
                                                                // row has two child icon and text.
                                                                child: Row(
                                                                  children: [
                                                                    Text(
                                                                        "Report Review")
                                                                  ],
                                                                ),
                                                              ),
                                                              // popupmenu item 2
                                                              PopupMenuItem(
                                                                value: 2,
                                                                // row has two child icon and text
                                                                child: Row(
                                                                  children: [
                                                                    Text(
                                                                        "Block Review")
                                                                  ],
                                                                ),
                                                              ),
                                                            ],
                                                            offset:
                                                                Offset(10, 40),
                                                            color: Colors.white,
                                                            elevation: 4,
                                                          ),
                                                          //  Icon(
                                                          //   Icons.more_vert,
                                                          //   size: 28,
                                                          // ),
                                                        )
                                                      ],
                                                    ),
                                                    SizedBox(
                                                      height: 10,
                                                    ),
                                                    Container(
                                                      child: Text(
                                                        ratingReviewData[index]
                                                            .review,
                                                        textAlign:
                                                            TextAlign.start,
                                                        style: TextStyle(
                                                            fontSize: 12,
                                                            color: Colors.black
                                                                .withOpacity(
                                                                    0.53)),
                                                      ),
                                                    )
                                                  ]),
                                            );
                                          })
                                      : Center(
                                          child: Text("No Data Found"),
                                        )
                                  : Container(
                                      height: 100,
                                      child: Center(
                                        child: CircularProgressIndicator(),
                                      ),
                                    )),
                    ),
                  ),
                  InkWell(
                    onTap: () {
                      scaffoldKey.currentState!.showBottomSheet((context) =>
                          StatefulBuilder(builder:
                              (BuildContext context, StateSetter setState) {
                            return DraggableScrollableSheet(
                              expand: false,
                              maxChildSize: 0.8,
                              minChildSize: 0.75,
                              initialChildSize: 0.75,
                              builder: (BuildContext context,
                                  ScrollController scrollController) {
                                return AllReviews(scrollController);
                              },
                            );
                          }));
                    },
                    child: Text(
                      "See All Reviews",
                      style: TextStyle(
                          fontSize: 13,
                          color: blueColor,
                          fontWeight: FontWeight.bold),
                    ),
                  )
                ]),
              ),
            ],
          ),
          SizedBox(
            height: 10,
          ),
          GestureDetector(
            onTap: () {
              Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => VendorAvailabilityScreen(
                          Vendor: results, wallet: _walletList)));
            },
            child: Container(
              padding: EdgeInsets.all(15),
              margin: EdgeInsets.only(bottom: 10, left: 15, right: 15),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                color: Colors.white,
                boxShadow: [
                  BoxShadow(
                    color: Color.fromRGBO(0, 0, 0, 0.16),
                    offset: const Offset(
                      3.0,
                      3.0,
                    ),
                    blurRadius: 6.0,
                    spreadRadius: 2.0,
                  ), //BoxShadow
                  BoxShadow(
                    color: Colors.white,
                    offset: const Offset(0.0, 0.0),
                    blurRadius: 0.0,
                    spreadRadius: 0.0,
                  ), //BoxShadow
                ],
              ),
              child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Container(
                      child: Row(children: [
                        Icon(Icons.calendar_month,
                            size: 22, color: Color.fromRGBO(68, 68, 68, 1)),
                        SizedBox(
                          width: 10,
                        ),
                        Text(
                          "Availability",
                          style: TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.bold,
                              color: Color.fromRGBO(68, 68, 68, 1)),
                        )
                      ]),
                    ),
                    Icon(
                      Icons.arrow_forward_ios,
                      size: 18,
                    )
                  ]),
            ),
          ),
          SizedBox(
            height: 10,
          ),
          isfollowing != true
              ? GestureDetector(
                  onTap: () async {
                    SharedPreferences pref =
                        await SharedPreferences.getInstance();
                    String? uid = pref.getString("uid");
                    followVendor(uid!, vid, !isfollowing);
                  },
                  child: Container(
                    padding: EdgeInsets.all(15),
                    margin: EdgeInsets.only(bottom: 10, left: 15, right: 15),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      color: Colors.white,
                      boxShadow: [
                        BoxShadow(
                          color: Color.fromRGBO(0, 0, 0, 0.16),
                          offset: const Offset(
                            3.0,
                            3.0,
                          ),
                          blurRadius: 6.0,
                          spreadRadius: 2.0,
                        ), //BoxShadow
                        BoxShadow(
                          color: Colors.white,
                          offset: const Offset(0.0, 0.0),
                          blurRadius: 0.0,
                          spreadRadius: 0.0,
                        ), //BoxShadow
                      ],
                    ),
                    child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Container(
                            child: Row(children: [
                              Transform.rotate(
                                angle: 0,
                                child: Icon(Icons.push_pin_sharp,
                                    size: 22,
                                    color: Color.fromRGBO(68, 68, 68, 1)),
                              ),
                              SizedBox(
                                width: 10,
                              ),
                              Text(
                                "Follow Aditya Roy",
                                style: TextStyle(
                                    fontSize: 14,
                                    fontWeight: FontWeight.bold,
                                    color: Color.fromRGBO(68, 68, 68, 1)),
                              )
                            ]),
                          ),
                          Icon(
                            Icons.arrow_forward_ios,
                            size: 18,
                          )
                        ]),
                  ),
                )
              : Container(),
          SizedBox(
            height: 10,
          ),
          GestureDetector(
            onTap: () {
              SmartDialog.show(builder: (_) {
                return RechargeNow();
              });
            },
            child: Container(
              padding: EdgeInsets.all(15),
              margin: EdgeInsets.only(bottom: 10, left: 15, right: 15),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                color: Colors.white,
                boxShadow: [
                  BoxShadow(
                    color: Color.fromRGBO(0, 0, 0, 0.16),
                    offset: const Offset(
                      3.0,
                      3.0,
                    ),
                    blurRadius: 6.0,
                    spreadRadius: 2.0,
                  ), //BoxShadow
                  BoxShadow(
                    color: Colors.white,
                    offset: const Offset(0.0, 0.0),
                    blurRadius: 0.0,
                    spreadRadius: 0.0,
                  ), //BoxShadow
                ],
              ),
              child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Container(
                      child: Row(children: [
                        Icon(Icons.video_call,
                            size: 22, color: Color.fromRGBO(68, 68, 68, 1)),
                        SizedBox(
                          width: 10,
                        ),
                        Text(
                          "Video Call @ ₹ 40 / min",
                          style: TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.bold,
                              color: Color.fromRGBO(68, 68, 68, 1)),
                        )
                      ]),
                    ),
                    Icon(
                      Icons.arrow_forward_ios,
                      size: 18,
                    )
                  ]),
            ),
          ),
          SizedBox(
            height: 10,
          ),
          GestureDetector(
            onTap: () {
              showModalBottomSheet(
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10.0),
                ),
                context: context,
                builder: (context) {
                  return SendGift(_walletList[0].walletamount);
                },
              );
            },
            child: Container(
              padding: EdgeInsets.all(15),
              margin: EdgeInsets.only(bottom: 10, left: 15, right: 15),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                color: Colors.white,
                boxShadow: [
                  BoxShadow(
                    color: Color.fromRGBO(0, 0, 0, 0.16),
                    offset: const Offset(
                      3.0,
                      3.0,
                    ),
                    blurRadius: 6.0,
                    spreadRadius: 2.0,
                  ), //BoxShadow
                  BoxShadow(
                    color: Colors.white,
                    offset: const Offset(0.0, 0.0),
                    blurRadius: 0.0,
                    spreadRadius: 0.0,
                  ), //BoxShadow
                ],
              ),
              child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Container(
                      child: Row(children: [
                        Icon(Icons.diamond,
                            size: 22, color: Color.fromRGBO(68, 68, 68, 1)),
                        SizedBox(
                          width: 10,
                        ),
                        Text(
                          "Send Gift to Aditya",
                          style: TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.bold,
                              color: Color.fromRGBO(68, 68, 68, 1)),
                        )
                      ]),
                    ),
                    Icon(
                      Icons.arrow_forward_ios,
                      size: 18,
                    )
                  ]),
            ),
          ),
          SizedBox(
            height: 10,
          ),
        ],
      )),
      bottomNavigationBar: Container(
          height: 50,
          decoration: BoxDecoration(
              borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(10), topRight: Radius.circular(10)),
              border: Border.all(width: 1, color: blueColor.withOpacity(0.6))),
          child: Row(
            children: [
              GestureDetector(
                onTap: () {
                  if (double.parse(_walletList[0].walletamount) >= 100.0) {
                    showDialog(
                        context: context,
                        builder: (BuildContext context) =>
                            VideoCallAndAudioCallModal(
                                name: results[0].name,
                                image: results[0].photo,
                                vid: results[0].id.toString(),
                                audioCallPrice: results[0].audicallprice,
                                videoCallPrice: results[0].audicallprice));
                  } else {
                    showDialog<void>(
                      context: context,
                      barrierDismissible: false, // user must tap button!
                      builder: (BuildContext context) {
                        return AlertDialog(
                          elevation: 0.6,
                          contentPadding: EdgeInsets.only(
                              left: 20, right: 10, top: 5, bottom: 5),
                          titlePadding: EdgeInsets.only(
                              left: 20, right: 10, top: 5, bottom: 5),
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(15)),
                          title: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              const Text('Recharge Plan'),
                              IconButton(
                                icon: Icon(
                                  Icons.close,
                                  color: Colors.red,
                                ),
                                onPressed: () {
                                  Navigator.of(context).pop();
                                },
                              )
                            ],
                          ),
                          content: RechargeNow(),
                        );
                      },
                    );
                  }
                },
                child: Container(
                  margin: EdgeInsets.only(left: 10, right: 5),
                  width: 160,
                  height: 42,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(5),
                    color: themeColor,
                  ),
                  child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: const [
                        Icon(
                          Icons.phone,
                          color: blueColor,
                          size: 20,
                        ),
                        Text(
                          "Call",
                          style: TextStyle(
                              fontSize: 14,
                              color: blueColor,
                              fontWeight: FontWeight.bold),
                        )
                      ]),
                ),
              ),
              GestureDetector(
                onTap: () {
                  showDialog<void>(
                    context: context,
                    barrierDismissible: false, // user must tap button!
                    builder: (BuildContext context) {
                      return AlertDialog(
                        elevation: 0.6,
                        contentPadding: EdgeInsets.only(
                            left: 20, right: 10, top: 5, bottom: 5),
                        titlePadding: EdgeInsets.only(
                            left: 20, right: 10, top: 5, bottom: 5),
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(15)),
                        title: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            const Text('Recharge Plan'),
                            IconButton(
                              icon: Icon(
                                Icons.close,
                                color: Colors.red,
                              ),
                              onPressed: () {
                                Navigator.of(context).pop();
                              },
                            )
                          ],
                        ),
                        content: RechargeNow(),
                      );
                    },
                  );
                },
                child: Container(
                  margin: EdgeInsets.only(left: 5, right: 10),
                  width: 160,
                  height: 42,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(5),
                    color: themeColor,
                  ),
                  child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        Icon(
                          Icons.message,
                          color: blueColor,
                          size: 20,
                        ),
                        Text(
                          "Chat",
                          style: TextStyle(
                              fontSize: 14,
                              color: blueColor,
                              fontWeight: FontWeight.bold),
                        )
                      ]),
                ),
              )
            ],
          )),
    );
  }

  Widget MobileVendorProfile() {
    return Scaffold(
      key: scaffoldKey,
      backgroundColor: Colors.white,
      body: SingleChildScrollView(
          child: Column(
        children: [
          FutureBuilder(
              future: getVendorDetails(),
              builder: (BuildContext ctx, AsyncSnapshot<List> item) => item
                      .hasData
                  ? item.data!.length != 0
                      ? Container(
                          height: 650,
                          color: Color.fromRGBO(255, 215, 0, 1),
                          margin: EdgeInsets.only(top: 35),
                          child: Column(children: [
                            Container(
                              margin: EdgeInsets.only(left: 14, right: 14),
                              height: 50,
                              child: Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    GestureDetector(
                                      onTap: () {
                                        Navigator.pop(context);
                                      },
                                      child: Icon(
                                        Icons.arrow_back,
                                        size: 25,
                                      ),
                                    ),
                                    IconButton(
                                      icon: const Icon(
                                        Icons.share,
                                        size: 25,
                                      ),
                                      onPressed: () async {
                                        // _takeScreenShotAndShare();
                                        // screenshotController
                                        //     .capture(
                                        //         delay:
                                        //             Duration(milliseconds: 10))
                                        //     .then((capturedImage) async {
                                        //   // ShowCapturedWidget(
                                        //   //     context, capturedImage!);
                                        //   await Share.shareFiles(
                                        //       ['${capturedImage}'],
                                        //       text: 'Great picture');
                                        // }).catchError((onError) {
                                        //   print(onError);
                                        // });
                                      },
                                    )
                                  ]),
                            ),
                            Screenshot(
                              controller: screenshotController,
                              child: Container(
                                height: 600,
                                child: Stack(
                                  alignment: Alignment.topCenter,
                                  children: [
                                    Positioned(
                                      top: 5,
                                      child: Container(
                                        height: 106,
                                        width: 106,
                                        decoration: BoxDecoration(
                                            borderRadius:
                                                BorderRadius.circular(45),
                                            border: Border.all(
                                                width: 2,
                                                color: lightblueColor),
                                            image: DecorationImage(
                                                image: NetworkImage(MainUrl +
                                                    'vendor-image/' +
                                                    results[0].photo),
                                                fit: BoxFit.contain)),
                                      ),
                                    ),
                                    Positioned(
                                        top: 5,
                                        left: 205,
                                        child: Container(
                                          height: 25,
                                          width: 25,
                                          decoration: BoxDecoration(
                                              image: DecorationImage(
                                                  image: AssetImage(
                                                      "assets/SVG/star2-2x.png"),
                                                  fit: BoxFit.fill)),
                                        )),
                                    Positioned(
                                        top: 135,
                                        child: Container(
                                          child: Column(children: [
                                            Text(
                                              results[0].name,
                                              style: TextStyle(
                                                  fontSize: 20,
                                                  color: Color.fromRGBO(
                                                      17, 81, 115, 1),
                                                  fontWeight: FontWeight.bold),
                                            ),
                                            SizedBox(
                                              height: 10,
                                            ),
                                            Text(
                                              results[0].primaryskills,
                                              style: TextStyle(
                                                  fontSize: 14,
                                                  color: Colors.black,
                                                  fontWeight: FontWeight.bold),
                                            ),
                                            SizedBox(
                                              height: 10,
                                            ),
                                            Text(
                                              results[0].language,
                                              style: TextStyle(
                                                  fontSize: 14,
                                                  color: Colors.black,
                                                  fontWeight: FontWeight.bold),
                                            ),
                                            SizedBox(
                                              height: 10,
                                            ),
                                            Text(
                                              "Exp: 5 Years",
                                              style: TextStyle(
                                                  fontSize: 14,
                                                  color: Colors.black,
                                                  fontWeight: FontWeight.bold),
                                            ),
                                            SizedBox(
                                              height: 10,
                                            ),
                                            Text(
                                              "₹ ${results[0].audicallprice} / min",
                                              style: TextStyle(
                                                  fontSize: 12,
                                                  color: Colors.black,
                                                  fontWeight: FontWeight.bold),
                                            ),
                                            SizedBox(
                                              height: 17,
                                            ),
                                            GestureDetector(
                                              onTap: () async {
                                                SharedPreferences pref =
                                                    await SharedPreferences
                                                        .getInstance();
                                                String? uid =
                                                    pref.getString("uid");
                                                followVendor(
                                                    uid!, vid, !isfollowing);
                                              },
                                              child: Container(
                                                height: 37,
                                                width: 121,
                                                decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            45),
                                                    color: Color.fromRGBO(
                                                        17, 81, 115, 1)),
                                                child: Center(
                                                  child: isfollowing != true
                                                      ? Text(
                                                          "Follow",
                                                          style: TextStyle(
                                                              color:
                                                                  Colors.white,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .bold,
                                                              fontSize: 15),
                                                        )
                                                      : Text(
                                                          "Following",
                                                          style: TextStyle(
                                                              color:
                                                                  Colors.white,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .bold,
                                                              fontSize: 15),
                                                        ),
                                                ),
                                              ),
                                            ),
                                            SizedBox(
                                              height: 20,
                                            ),
                                            Container(
                                              width: 350,
                                              child: Row(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment
                                                          .spaceEvenly,
                                                  children: [
                                                    Container(
                                                      child: Column(children: [
                                                        Text(
                                                          "Chat",
                                                          style: TextStyle(
                                                              fontSize: 11,
                                                              color:
                                                                  Colors.black,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .bold),
                                                        ),
                                                        SizedBox(
                                                          height: 10,
                                                        ),
                                                        Text(
                                                          "49k",
                                                          style: TextStyle(
                                                              fontSize: 20,
                                                              color: Color
                                                                  .fromRGBO(
                                                                      17,
                                                                      81,
                                                                      115,
                                                                      1),
                                                              fontWeight:
                                                                  FontWeight
                                                                      .bold),
                                                        ),
                                                        SizedBox(
                                                          height: 5,
                                                        ),
                                                        Text(
                                                          "mins",
                                                          style: TextStyle(
                                                              fontSize: 9,
                                                              color:
                                                                  Colors.black,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .bold),
                                                        ),
                                                      ]),
                                                    ),
                                                    Container(
                                                      child: Column(children: [
                                                        Text(
                                                          "Calls",
                                                          style: TextStyle(
                                                              fontSize: 11,
                                                              color:
                                                                  Colors.black,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .bold),
                                                        ),
                                                        SizedBox(
                                                          height: 10,
                                                        ),
                                                        Text(
                                                          "49k",
                                                          style: TextStyle(
                                                              fontSize: 20,
                                                              color: Color
                                                                  .fromRGBO(
                                                                      17,
                                                                      81,
                                                                      115,
                                                                      1),
                                                              fontWeight:
                                                                  FontWeight
                                                                      .bold),
                                                        ),
                                                        SizedBox(
                                                          height: 5,
                                                        ),
                                                        Text(
                                                          "mins",
                                                          style: TextStyle(
                                                              fontSize: 9,
                                                              color:
                                                                  Colors.black,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .bold),
                                                        ),
                                                      ]),
                                                    ),
                                                    Container(
                                                      child: Column(children: [
                                                        Text(
                                                          "Video Chat",
                                                          style: TextStyle(
                                                              fontSize: 11,
                                                              color:
                                                                  Colors.black,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .bold),
                                                        ),
                                                        SizedBox(
                                                          height: 10,
                                                        ),
                                                        Text(
                                                          "500",
                                                          style: TextStyle(
                                                              fontSize: 20,
                                                              color: Color
                                                                  .fromRGBO(
                                                                      17,
                                                                      81,
                                                                      115,
                                                                      1),
                                                              fontWeight:
                                                                  FontWeight
                                                                      .bold),
                                                        ),
                                                        SizedBox(
                                                          height: 5,
                                                        ),
                                                        Text(
                                                          "mins",
                                                          style: TextStyle(
                                                              fontSize: 9,
                                                              color:
                                                                  Colors.black,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .bold),
                                                        ),
                                                      ]),
                                                    ),
                                                    Container(
                                                      child: Column(children: [
                                                        Text(
                                                          "Followers",
                                                          style: TextStyle(
                                                              fontSize: 11,
                                                              color:
                                                                  Colors.black,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .bold),
                                                        ),
                                                        SizedBox(
                                                          height: 10,
                                                        ),
                                                        Text(
                                                          "2k",
                                                          style: TextStyle(
                                                              fontSize: 20,
                                                              color: Color
                                                                  .fromRGBO(
                                                                      17,
                                                                      81,
                                                                      115,
                                                                      1),
                                                              fontWeight:
                                                                  FontWeight
                                                                      .bold),
                                                        ),
                                                        SizedBox(
                                                          height: 5,
                                                        ),
                                                        Text(
                                                          "Following",
                                                          style: TextStyle(
                                                              fontSize: 9,
                                                              color:
                                                                  Colors.black,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .bold),
                                                        ),
                                                      ]),
                                                    )
                                                  ]),
                                            )
                                          ]),
                                        )),
                                    Positioned(
                                        top: 413,
                                        left: 0,
                                        width: 374,
                                        height: 312,
                                        child: Container(
                                          decoration: BoxDecoration(
                                              image: DecorationImage(
                                                  image: AssetImage(
                                                      "assets/SVG/Path 2-2x.png"))),
                                        )),
                                    Positioned(
                                        top: 418,
                                        left: 134,
                                        width: 374,
                                        height: 312,
                                        child: Container(
                                          decoration: BoxDecoration(
                                              image: DecorationImage(
                                                  image: AssetImage(
                                                      "assets/SVG/Path 4-2x.png"))),
                                        )),
                                    Positioned(
                                        top: 417,
                                        left: 0.63,
                                        width: 412,
                                        height: 449,
                                        child: Container(
                                          decoration: BoxDecoration(
                                              image: DecorationImage(
                                                  image: AssetImage(
                                                      "assets/SVG/Path 3-2x.png"))),
                                          child: Container(
                                              margin: EdgeInsets.only(
                                                  top: 55, left: 20, right: 70),
                                              child: Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                children: [
                                                  Text(
                                                    "About ${results[0].name}",
                                                    textAlign: TextAlign.center,
                                                    style: TextStyle(
                                                        fontSize: 13,
                                                        fontWeight:
                                                            FontWeight.bold),
                                                  ),
                                                  SizedBox(
                                                    height: 20,
                                                  ),
                                                  Text(
                                                    results[0].aboutus,
                                                    textAlign: TextAlign.left,
                                                    style: TextStyle(
                                                        fontSize: 13,
                                                        fontWeight:
                                                            FontWeight.normal,
                                                        color: Color.fromRGBO(
                                                            17, 81, 115, 1)),
                                                  ),
                                                ],
                                              )),
                                        ))
                                  ],
                                ),
                              ),
                            ),
                          ]),
                        )
                      : Center(
                          child: Text("No Data Found"),
                        )
                  : Container(
                      height: 800,
                      child: Center(
                        child: CircularProgressIndicator(),
                      ),
                    )),
          SizedBox(
            height: 22,
          ),
          Container(
            margin: EdgeInsets.only(left: 15, right: 15),
            height: 208,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(10),
              color: Colors.white,
              boxShadow: [
                BoxShadow(
                  color: Color.fromRGBO(0, 0, 0, 0.16),
                  offset: const Offset(
                    3.0,
                    3.0,
                  ),
                  blurRadius: 6.0,
                  spreadRadius: 2.0,
                ), //BoxShadow
                BoxShadow(
                  color: Colors.white,
                  offset: const Offset(0.0, 0.0),
                  blurRadius: 0.0,
                  spreadRadius: 0.0,
                ), //BoxShadow
              ],
            ),
            child: Column(children: [
              Container(
                margin: EdgeInsets.only(left: 15, right: 15, top: 22),
                child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        "Rating & Reviews",
                        style: TextStyle(
                            fontSize: 13,
                            fontWeight: FontWeight.normal,
                            color: Colors.black),
                      ),
                      Transform.rotate(
                          angle: 180 * math.pi / 180,
                          child: Icon(Icons.arrow_back))
                    ]),
              ),
              Container(
                margin: EdgeInsets.only(top: 10),
                child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Container(
                        width: 100,
                        child: Column(children: [
                          Text(
                            "4.93",
                            style: TextStyle(
                                fontSize: 38,
                                fontWeight: FontWeight.bold,
                                color: blueColor),
                          ),
                          SizedBox(
                            height: 10,
                          ),
                          Container(
                            child: RatingBarIndicator(
                              rating: 4.5,
                              itemBuilder: (context, index) => Icon(
                                Icons.star,
                                color: Colors.amber,
                              ),
                              itemCount: 5,
                              itemSize: 13.0,
                              direction: Axis.horizontal,
                            ),
                          ),
                          SizedBox(
                            height: 10,
                          ),
                          Text(
                            "734 Reviews",
                            style: TextStyle(
                                fontSize: 11,
                                fontWeight: FontWeight.bold,
                                color: blueColor),
                          ),
                        ]),
                      ),
                      Container(
                        child: Column(
                          children: [
                            Row(children: [
                              Container(
                                child: Text(
                                  "5",
                                  style:
                                      TextStyle(fontSize: 16, color: blueColor),
                                ),
                              ),
                              SizedBox(
                                width: 15,
                              ),
                              Container(
                                height: 20,
                                width: 145,
                                decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(10),
                                    boxShadow: [
                                      BoxShadow(
                                        color: Color.fromRGBO(0, 0, 0, 0.16),
                                        offset: const Offset(
                                          3.0,
                                          3.0,
                                        ),
                                        blurRadius: 6.0,
                                        spreadRadius: 2.0,
                                      ), //BoxShadow
                                      BoxShadow(
                                        color: Colors.white,
                                        offset: const Offset(0.0, 0.0),
                                        blurRadius: 0.0,
                                        spreadRadius: 0.0,
                                      ), //BoxShadow
                                    ],
                                    color: Colors.white),
                                child: Container(
                                  height: 20,
                                  width: 85,
                                  decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(10),
                                      color: themeColor),
                                ),
                              )
                            ]),
                            SizedBox(
                              height: 10,
                            ),
                            Row(children: [
                              Container(
                                child: Text(
                                  "4",
                                  style:
                                      TextStyle(fontSize: 16, color: blueColor),
                                ),
                              ),
                              SizedBox(
                                width: 15,
                              ),
                              Container(
                                height: 20,
                                width: 145,
                                decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(10),
                                    boxShadow: [
                                      BoxShadow(
                                        color: Color.fromRGBO(0, 0, 0, 0.16),
                                        offset: const Offset(
                                          3.0,
                                          3.0,
                                        ),
                                        blurRadius: 6.0,
                                        spreadRadius: 2.0,
                                      ), //BoxShadow
                                      BoxShadow(
                                        color: Colors.white,
                                        offset: const Offset(0.0, 0.0),
                                        blurRadius: 0.0,
                                        spreadRadius: 0.0,
                                      ), //BoxShadow
                                    ],
                                    color: Colors.white),
                                child: Container(
                                  height: 20,
                                  width: 85,
                                  decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(10),
                                      color: themeColor),
                                ),
                              )
                            ]),
                            const SizedBox(
                              height: 10,
                            ),
                            Row(children: [
                              Container(
                                child: const Text(
                                  "3",
                                  style:
                                      TextStyle(fontSize: 16, color: blueColor),
                                ),
                              ),
                              const SizedBox(
                                width: 15,
                              ),
                              Container(
                                height: 20,
                                width: 145,
                                decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(10),
                                    boxShadow: const [
                                      BoxShadow(
                                        color: Color.fromRGBO(0, 0, 0, 0.16),
                                        offset: Offset(
                                          3.0,
                                          3.0,
                                        ),
                                        blurRadius: 6.0,
                                        spreadRadius: 2.0,
                                      ), //BoxShadow
                                      BoxShadow(
                                        color: Colors.white,
                                        offset: Offset(0.0, 0.0),
                                        blurRadius: 0.0,
                                        spreadRadius: 0.0,
                                      ), //BoxShadow
                                    ],
                                    color: Colors.white),
                                child: Container(
                                  height: 20,
                                  width: 85,
                                  decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(10),
                                      color: themeColor),
                                ),
                              )
                            ]),
                            SizedBox(
                              height: 10,
                            ),
                            Row(children: [
                              Container(
                                child: Text(
                                  "2",
                                  style:
                                      TextStyle(fontSize: 16, color: blueColor),
                                ),
                              ),
                              SizedBox(
                                width: 15,
                              ),
                              Container(
                                height: 20,
                                width: 145,
                                decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(10),
                                    boxShadow: [
                                      BoxShadow(
                                        color: Color.fromRGBO(0, 0, 0, 0.16),
                                        offset: const Offset(
                                          3.0,
                                          3.0,
                                        ),
                                        blurRadius: 6.0,
                                        spreadRadius: 2.0,
                                      ), //BoxShadow
                                      BoxShadow(
                                        color: Colors.white,
                                        offset: const Offset(0.0, 0.0),
                                        blurRadius: 0.0,
                                        spreadRadius: 0.0,
                                      ), //BoxShadow
                                    ],
                                    color: Colors.white),
                                child: Container(
                                  height: 20,
                                  width: 85,
                                  decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(10),
                                      color: themeColor),
                                ),
                              )
                            ]),
                            SizedBox(
                              height: 10,
                            ),
                            Row(children: [
                              Container(
                                child: Text(
                                  "1",
                                  style:
                                      TextStyle(fontSize: 16, color: blueColor),
                                ),
                              ),
                              SizedBox(
                                width: 15,
                              ),
                              Container(
                                height: 20,
                                width: 145,
                                decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(10),
                                    boxShadow: [
                                      BoxShadow(
                                        color: Color.fromRGBO(0, 0, 0, 0.16),
                                        offset: const Offset(
                                          3.0,
                                          3.0,
                                        ),
                                        blurRadius: 6.0,
                                        spreadRadius: 2.0,
                                      ), //BoxShadow
                                      BoxShadow(
                                        color: Colors.white,
                                        offset: const Offset(0.0, 0.0),
                                        blurRadius: 0.0,
                                        spreadRadius: 0.0,
                                      ), //BoxShadow
                                    ],
                                    color: Colors.white),
                                child: Container(
                                  height: 20,
                                  width: 85,
                                  decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(10),
                                      color: themeColor),
                                ),
                              )
                            ]),
                          ],
                        ),
                      )
                    ]),
              )
            ]),
          ),
          Container(
            child: Column(children: [
              Container(
                margin: EdgeInsets.only(left: 20, right: 20, top: 30),
                child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        "Photos",
                        style: TextStyle(
                            fontSize: 13,
                            fontWeight: FontWeight.normal,
                            color: Colors.black),
                      ),
                      Transform.rotate(
                          angle: 180 * math.pi / 180,
                          child: GestureDetector(
                              onTap: () {
                                Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) => VendorProfileWork(
                                            wportdata: wportdata)));
                              },
                              child: Icon(Icons.arrow_back)))
                    ]),
              ),
              Container(
                height: 110,
                margin: EdgeInsets.all(15),
                child: FutureBuilder(
                    future: getWorkPortfolio(),
                    builder: (BuildContext ctx, AsyncSnapshot<List> item) =>
                        item.hasData
                            ? item.data!.length != 0
                                ? ListView.builder(
                                    itemCount: wportdata.length,
                                    scrollDirection: Axis.horizontal,
                                    shrinkWrap: true,
                                    itemBuilder: (context, index) {
                                      return GestureDetector(
                                        onTap: () async {
                                          await showDialog(
                                              context: context,
                                              builder: (_) => ImageDialog(
                                                  MainUrl +
                                                      'vendor-work/' +
                                                      wportdata[index].photo));
                                        },
                                        child: Container(
                                          height: 110,
                                          width: 110,
                                          margin: EdgeInsets.only(right: 10),
                                          decoration: BoxDecoration(
                                              borderRadius:
                                                  BorderRadius.circular(50),
                                              image: DecorationImage(
                                                  image: NetworkImage(MainUrl +
                                                      'vendor-work/' +
                                                      wportdata[index].photo),
                                                  fit: BoxFit.fill)),
                                        ),
                                      );
                                    })
                                : Center(
                                    child: Text("No Data Found"),
                                  )
                            : Container(
                                height: 800,
                                child: Center(
                                  child: CircularProgressIndicator(),
                                ),
                              )),
              )
            ]),
          ),
          Container(
            child: Column(children: [
              Container(
                margin: EdgeInsets.only(left: 20, right: 20, top: 10),
                child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        "User Reviews",
                        style: TextStyle(
                            fontSize: 13,
                            fontWeight: FontWeight.normal,
                            color: Colors.black),
                      ),
                      InkWell(
                        onTap: () {
                          scaffoldKey.currentState!.showBottomSheet((context) =>
                              StatefulBuilder(builder:
                                  (BuildContext context, StateSetter setState) {
                                return DraggableScrollableSheet(
                                  expand: false,
                                  maxChildSize: 0.8,
                                  minChildSize: 0.75,
                                  initialChildSize: 0.75,
                                  builder: (BuildContext context,
                                      ScrollController scrollController) {
                                    return AllReviews(scrollController);
                                  },
                                );
                              }));
                        },
                        child: Transform.rotate(
                            angle: 180 * math.pi / 180,
                            child: Icon(Icons.arrow_back)),
                      )
                    ]),
              ),
              Container(
                // height: 280,
                margin: EdgeInsets.only(left: 15, right: 15, top: 10),
                child: MediaQuery.removePadding(
                  context: context,
                  removeTop: true,
                  child: FutureBuilder(
                      future: getReviews(),
                      builder: (BuildContext ctx, AsyncSnapshot<List> item) =>
                          item.hasData
                              ? item.data!.length != 0
                                  ? ListView.builder(
                                      itemCount: ratingReviewData.length >= 3
                                          ? 3
                                          : ratingReviewData.length,
                                      shrinkWrap: true,
                                      physics: NeverScrollableScrollPhysics(),
                                      itemBuilder: (context, index) {
                                        return Container(
                                          padding: EdgeInsets.all(15),
                                          margin: EdgeInsets.only(bottom: 10),
                                          // height: 130,
                                          decoration: BoxDecoration(
                                            borderRadius:
                                                BorderRadius.circular(10),
                                            color: Colors.white,
                                            boxShadow: [
                                              BoxShadow(
                                                color: Color.fromRGBO(
                                                    0, 0, 0, 0.16),
                                                offset: const Offset(
                                                  3.0,
                                                  3.0,
                                                ),
                                                blurRadius: 6.0,
                                                spreadRadius: 2.0,
                                              ), //BoxShadow
                                              BoxShadow(
                                                color: Colors.white,
                                                offset: const Offset(0.0, 0.0),
                                                blurRadius: 0.0,
                                                spreadRadius: 0.0,
                                              ), //BoxShadow
                                            ],
                                          ),
                                          child: Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                Row(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment
                                                          .spaceBetween,
                                                  children: [
                                                    Container(
                                                      child: Row(children: [
                                                        Container(
                                                          height: 44,
                                                          width: 44,
                                                          decoration: BoxDecoration(
                                                              shape: BoxShape
                                                                  .circle,
                                                              image: DecorationImage(
                                                                  image: NetworkImage(MainUrl +
                                                                      "customer-image/" +
                                                                      ratingReviewData[
                                                                              index]
                                                                          .photo),
                                                                  fit: BoxFit
                                                                      .fill)),
                                                        ),
                                                        SizedBox(
                                                          width: 15,
                                                        ),
                                                        Container(
                                                          child: Column(
                                                              crossAxisAlignment:
                                                                  CrossAxisAlignment
                                                                      .start,
                                                              children: [
                                                                Text(
                                                                  ratingReviewData[
                                                                          index]
                                                                      .name,
                                                                  style: const TextStyle(
                                                                      fontSize:
                                                                          14,
                                                                      fontWeight:
                                                                          FontWeight
                                                                              .bold),
                                                                ),
                                                                Container(
                                                                  child:
                                                                      RatingBarIndicator(
                                                                    rating: double.parse(ratingReviewData[
                                                                            index]
                                                                        .rating
                                                                        .toString()),
                                                                    itemBuilder:
                                                                        (context,
                                                                                index) =>
                                                                            Icon(
                                                                      Icons
                                                                          .star,
                                                                      color: Colors
                                                                          .amber,
                                                                    ),
                                                                    itemCount:
                                                                        5,
                                                                    itemSize:
                                                                        13.0,
                                                                    direction: Axis
                                                                        .horizontal,
                                                                  ),
                                                                ),
                                                              ]),
                                                        ),
                                                      ]),
                                                    ),
                                                    Container(
                                                      child:
                                                          PopupMenuButton<int>(
                                                        itemBuilder:
                                                            (context) => [
                                                          // popupmenu item 1
                                                          PopupMenuItem(
                                                            value: 1,
                                                            // row has two child icon and text.
                                                            child: Row(
                                                              children: [
                                                                Text(
                                                                    "Report Review")
                                                              ],
                                                            ),
                                                          ),
                                                          // popupmenu item 2
                                                          PopupMenuItem(
                                                            value: 2,
                                                            // row has two child icon and text
                                                            child: Row(
                                                              children: [
                                                                Text(
                                                                    "Block Review")
                                                              ],
                                                            ),
                                                          ),
                                                        ],
                                                        offset: Offset(10, 40),
                                                        color: Colors.white,
                                                        elevation: 4,
                                                      ),
                                                      //  Icon(
                                                      //   Icons.more_vert,
                                                      //   size: 28,
                                                      // ),
                                                    )
                                                  ],
                                                ),
                                                SizedBox(
                                                  height: 10,
                                                ),
                                                Container(
                                                  child: Text(
                                                    ratingReviewData[index]
                                                        .review,
                                                    textAlign: TextAlign.start,
                                                    style: TextStyle(
                                                        fontSize: 12,
                                                        color: Colors.black
                                                            .withOpacity(0.53)),
                                                  ),
                                                )
                                              ]),
                                        );
                                      })
                                  : Center(
                                      child: Text("No Data Found"),
                                    )
                              : Container(
                                  height: 100,
                                  child: Center(
                                    child: CircularProgressIndicator(),
                                  ),
                                )),
                ),
              ),
              InkWell(
                onTap: () {
                  scaffoldKey.currentState!.showBottomSheet((context) =>
                      StatefulBuilder(builder:
                          (BuildContext context, StateSetter setState) {
                        return DraggableScrollableSheet(
                          expand: false,
                          maxChildSize: 0.8,
                          minChildSize: 0.75,
                          initialChildSize: 0.75,
                          builder: (BuildContext context,
                              ScrollController scrollController) {
                            return AllReviews(scrollController);
                          },
                        );
                      }));
                },
                child: Text(
                  "See All Reviews",
                  style: TextStyle(
                      fontSize: 13,
                      color: blueColor,
                      fontWeight: FontWeight.bold),
                ),
              )
            ]),
          ),
          SizedBox(
            height: 10,
          ),
          GestureDetector(
            onTap: () {
              Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => VendorAvailabilityScreen(
                          Vendor: results, wallet: _walletList)));
            },
            child: Container(
              padding: EdgeInsets.all(15),
              margin: EdgeInsets.only(bottom: 10, left: 15, right: 15),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                color: Colors.white,
                boxShadow: [
                  BoxShadow(
                    color: Color.fromRGBO(0, 0, 0, 0.16),
                    offset: const Offset(
                      3.0,
                      3.0,
                    ),
                    blurRadius: 6.0,
                    spreadRadius: 2.0,
                  ), //BoxShadow
                  BoxShadow(
                    color: Colors.white,
                    offset: const Offset(0.0, 0.0),
                    blurRadius: 0.0,
                    spreadRadius: 0.0,
                  ), //BoxShadow
                ],
              ),
              child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Container(
                      child: Row(children: [
                        Icon(Icons.calendar_month,
                            size: 22, color: Color.fromRGBO(68, 68, 68, 1)),
                        SizedBox(
                          width: 10,
                        ),
                        Text(
                          "Availability",
                          style: TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.bold,
                              color: Color.fromRGBO(68, 68, 68, 1)),
                        )
                      ]),
                    ),
                    Icon(
                      Icons.arrow_forward_ios,
                      size: 18,
                    )
                  ]),
            ),
          ),
          SizedBox(
            height: 10,
          ),
          isfollowing != true
              ? GestureDetector(
                  onTap: () async {
                    SharedPreferences pref =
                        await SharedPreferences.getInstance();
                    String? uid = pref.getString("uid");
                    followVendor(uid!, vid, !isfollowing);
                  },
                  child: Container(
                    padding: EdgeInsets.all(15),
                    margin: EdgeInsets.only(bottom: 10, left: 15, right: 15),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      color: Colors.white,
                      boxShadow: [
                        BoxShadow(
                          color: Color.fromRGBO(0, 0, 0, 0.16),
                          offset: const Offset(
                            3.0,
                            3.0,
                          ),
                          blurRadius: 6.0,
                          spreadRadius: 2.0,
                        ), //BoxShadow
                        BoxShadow(
                          color: Colors.white,
                          offset: const Offset(0.0, 0.0),
                          blurRadius: 0.0,
                          spreadRadius: 0.0,
                        ), //BoxShadow
                      ],
                    ),
                    child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Container(
                            child: Row(children: [
                              Transform.rotate(
                                angle: 0,
                                child: Icon(Icons.push_pin_sharp,
                                    size: 22,
                                    color: Color.fromRGBO(68, 68, 68, 1)),
                              ),
                              SizedBox(
                                width: 10,
                              ),
                              Text(
                                "Follow Aditya Roy",
                                style: TextStyle(
                                    fontSize: 14,
                                    fontWeight: FontWeight.bold,
                                    color: Color.fromRGBO(68, 68, 68, 1)),
                              )
                            ]),
                          ),
                          Icon(
                            Icons.arrow_forward_ios,
                            size: 18,
                          )
                        ]),
                  ),
                )
              : Container(),
          SizedBox(
            height: 10,
          ),
          GestureDetector(
            onTap: () {
              SmartDialog.show(builder: (_) {
                return RechargeNow();
              });
            },
            child: Container(
              padding: EdgeInsets.all(15),
              margin: EdgeInsets.only(bottom: 10, left: 15, right: 15),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                color: Colors.white,
                boxShadow: [
                  BoxShadow(
                    color: Color.fromRGBO(0, 0, 0, 0.16),
                    offset: const Offset(
                      3.0,
                      3.0,
                    ),
                    blurRadius: 6.0,
                    spreadRadius: 2.0,
                  ), //BoxShadow
                  BoxShadow(
                    color: Colors.white,
                    offset: const Offset(0.0, 0.0),
                    blurRadius: 0.0,
                    spreadRadius: 0.0,
                  ), //BoxShadow
                ],
              ),
              child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Container(
                      child: Row(children: [
                        Icon(Icons.video_call,
                            size: 22, color: Color.fromRGBO(68, 68, 68, 1)),
                        SizedBox(
                          width: 10,
                        ),
                        Text(
                          "Video Call @ ₹ 40 / min",
                          style: TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.bold,
                              color: Color.fromRGBO(68, 68, 68, 1)),
                        )
                      ]),
                    ),
                    Icon(
                      Icons.arrow_forward_ios,
                      size: 18,
                    )
                  ]),
            ),
          ),
          SizedBox(
            height: 10,
          ),
          GestureDetector(
            onTap: () {
              showModalBottomSheet(
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10.0),
                ),
                context: context,
                builder: (context) {
                  return SendGift(_walletList[0].walletamount);
                },
              );
            },
            child: Container(
              padding: EdgeInsets.all(15),
              margin: EdgeInsets.only(bottom: 10, left: 15, right: 15),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                color: Colors.white,
                boxShadow: [
                  BoxShadow(
                    color: Color.fromRGBO(0, 0, 0, 0.16),
                    offset: const Offset(
                      3.0,
                      3.0,
                    ),
                    blurRadius: 6.0,
                    spreadRadius: 2.0,
                  ), //BoxShadow
                  BoxShadow(
                    color: Colors.white,
                    offset: const Offset(0.0, 0.0),
                    blurRadius: 0.0,
                    spreadRadius: 0.0,
                  ), //BoxShadow
                ],
              ),
              child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Container(
                      child: Row(children: [
                        Icon(Icons.diamond,
                            size: 22, color: Color.fromRGBO(68, 68, 68, 1)),
                        SizedBox(
                          width: 10,
                        ),
                        Text(
                          "Send Gift to Aditya",
                          style: TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.bold,
                              color: Color.fromRGBO(68, 68, 68, 1)),
                        )
                      ]),
                    ),
                    Icon(
                      Icons.arrow_forward_ios,
                      size: 18,
                    )
                  ]),
            ),
          ),
          SizedBox(
            height: 10,
          ),
        ],
      )),
      bottomNavigationBar: Container(
          height: 50,
          decoration: BoxDecoration(
              borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(10), topRight: Radius.circular(10)),
              border: Border.all(width: 1, color: blueColor.withOpacity(0.6))),
          child: Row(
            children: [
              GestureDetector(
                onTap: () {
                  if (double.parse(_walletList[0].walletamount) >= 100.0) {
                    showDialog(
                        context: context,
                        builder: (BuildContext context) =>
                            VideoCallAndAudioCallModal(
                                name: results[0].name,
                                image: results[0].photo,
                                vid: results[0].id.toString(),
                                audioCallPrice: results[0].audicallprice,
                                videoCallPrice: results[0].audicallprice));
                  } else {
                    showDialog<void>(
                      context: context,
                      barrierDismissible: false, // user must tap button!
                      builder: (BuildContext context) {
                        return AlertDialog(
                          elevation: 0.6,
                          contentPadding: EdgeInsets.only(
                              left: 20, right: 10, top: 5, bottom: 5),
                          titlePadding: EdgeInsets.only(
                              left: 20, right: 10, top: 5, bottom: 5),
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(15)),
                          title: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              const Text('Recharge Plan'),
                              IconButton(
                                icon: Icon(
                                  Icons.close,
                                  color: Colors.red,
                                ),
                                onPressed: () {
                                  Navigator.of(context).pop();
                                },
                              )
                            ],
                          ),
                          content: RechargeNow(),
                        );
                      },
                    );
                  }
                },
                child: Container(
                  margin: EdgeInsets.only(left: 10, right: 5),
                  width: 160,
                  height: 42,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(5),
                    color: themeColor,
                  ),
                  child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: const [
                        Icon(
                          Icons.phone,
                          color: blueColor,
                          size: 20,
                        ),
                        Text(
                          "Call",
                          style: TextStyle(
                              fontSize: 14,
                              color: blueColor,
                              fontWeight: FontWeight.bold),
                        )
                      ]),
                ),
              ),
              GestureDetector(
                onTap: () {
                  showDialog<void>(
                    context: context,
                    barrierDismissible: false, // user must tap button!
                    builder: (BuildContext context) {
                      return AlertDialog(
                        elevation: 0.6,
                        contentPadding: EdgeInsets.only(
                            left: 20, right: 10, top: 5, bottom: 5),
                        titlePadding: EdgeInsets.only(
                            left: 20, right: 10, top: 5, bottom: 5),
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(15)),
                        title: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            const Text('Recharge Plan'),
                            IconButton(
                              icon: Icon(
                                Icons.close,
                                color: Colors.red,
                              ),
                              onPressed: () {
                                Navigator.of(context).pop();
                              },
                            )
                          ],
                        ),
                        content: RechargeNow(),
                      );
                    },
                  );
                },
                child: Container(
                  margin: EdgeInsets.only(left: 5, right: 10),
                  width: 160,
                  height: 42,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(5),
                    color: themeColor,
                  ),
                  child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        Icon(
                          Icons.message,
                          color: blueColor,
                          size: 20,
                        ),
                        Text(
                          "Chat",
                          style: TextStyle(
                              fontSize: 14,
                              color: blueColor,
                              fontWeight: FontWeight.bold),
                        )
                      ]),
                ),
              )
            ],
          )),
    );
  }

  Widget SendGift(String amount) {
    return Container(
      height: 300,
      child: Column(children: [
        Container(
          margin: EdgeInsets.only(left: 20, right: 20, top: 10),
          child:
              Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            Text(
              "Send Gift to Aditya",
              style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.normal,
                  color: Colors.black),
            ),
            GestureDetector(
                onTap: () {
                  Navigator.pop(context);
                },
                child: Icon(Icons.close))
          ]),
        ),
        Container(
          height: 210,
          margin: EdgeInsets.only(top: 10),
          // color: Colors.black,
          child: GridView.count(
              crossAxisCount: 3,
              crossAxisSpacing: 4.0,
              // scrollDirection: Axis,
              physics: NeverScrollableScrollPhysics(),
              mainAxisSpacing: 3.0,
              children: List.generate(
                  6,
                  (index) => Container(
                        child: Column(children: [
                          Container(
                            height: 45,
                            width: 45,
                            decoration: BoxDecoration(
                                image: DecorationImage(
                                    image: NetworkImage(
                                        "https://creazilla-store.fra1.digitaloceanspaces.com/cliparts/15331/red-rose-flower-clipart-xl.png"),
                                    fit: BoxFit.fill)),
                          ),
                          SizedBox(
                            height: 5,
                          ),
                          Text(
                            "₹ 501",
                            style: TextStyle(
                                fontSize: 11,
                                color: blueColor,
                                fontWeight: FontWeight.bold),
                          ),
                          SizedBox(
                            height: 5,
                          ),
                          Text(
                            "Best Wishes",
                            style: TextStyle(
                                fontSize: 11,
                                color: blueColor,
                                fontWeight: FontWeight.bold),
                          )
                        ]),
                      ))),
        ),
        Divider(
          height: 2,
          color: blueColor,
        ),
        SizedBox(
          height: 5,
        ),
        Container(
          child:
              Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
            Container(
              child: Column(children: [
                Text(
                  "Wallet Balance",
                  style: TextStyle(
                      fontSize: 12,
                      color: textColor,
                      fontWeight: FontWeight.bold),
                ),
                Text(
                  "₹ ${amount}",
                  style: TextStyle(
                      fontSize: 12,
                      color: textColor,
                      fontWeight: FontWeight.bold),
                )
              ]),
            ),
            GestureDetector(
              onTap: () {
                Navigator.pop(context);
                showDialog<void>(
                  context: context,
                  barrierDismissible: false, // user must tap button!
                  builder: (BuildContext context) {
                    return AlertDialog(
                      elevation: 0.6,
                      contentPadding: EdgeInsets.only(
                          left: 20, right: 10, top: 5, bottom: 5),
                      titlePadding: EdgeInsets.only(
                          left: 20, right: 10, top: 5, bottom: 5),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(15)),
                      title: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Text('Recharge Plan'),
                          IconButton(
                            icon: Icon(
                              Icons.close,
                              color: Colors.red,
                            ),
                            onPressed: () {
                              Navigator.of(context).pop();
                            },
                          )
                        ],
                      ),
                      content: RechargeNow(),
                    );
                  },
                );
              },
              child: Container(
                padding: EdgeInsets.symmetric(vertical: 8, horizontal: 15),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(5),
                  color: themeColor,
                ),
                child: Center(
                    child: Text(
                  "Recharge",
                  style: TextStyle(
                      fontSize: 12,
                      color: Colors.white,
                      fontWeight: FontWeight.bold),
                )),
              ),
            ),
            Container(
              padding: EdgeInsets.symmetric(vertical: 8, horizontal: 15),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(5),
                color: themeColor,
              ),
              child: Center(
                  child: Text(
                "Send Gift",
                style: TextStyle(
                    fontSize: 12,
                    color: Colors.white,
                    fontWeight: FontWeight.bold),
              )),
            )
          ]),
        )
      ]),
    );
  }

  void _rechargeNow() async {
    SmartDialog.show(builder: (_) {
      return RechargeNow();
    });
  }

  Future<dynamic> ShowCapturedWidget(
      BuildContext context, Uint8List capturedImage) {
    return showDialog(
      useSafeArea: false,
      context: context,
      builder: (context) => Scaffold(
        appBar: AppBar(
          title: Text("Captured widget screenshot"),
        ),
        body: Center(
            child: capturedImage != null
                ? Image.memory(capturedImage)
                : Container()),
      ),
    );
  }

  void showStartChat() async {
    SmartDialog.show(builder: (_) {
      return Container(
          height: 203,
          width: 265,
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(10),
          ),
          alignment: Alignment.center,
          child: Column(
            children: [
              Container(
                margin: EdgeInsets.only(left: 20, right: 20, top: 10),
                child: Row(mainAxisAlignment: MainAxisAlignment.end, children: [
                  GestureDetector(
                      onTap: () {
                        Navigator.pop(context, true);
                      },
                      child: Icon(Icons.close))
                ]),
              ),
              GestureDetector(
                child: Container(
                  height: 65,
                  width: 65,
                  margin: EdgeInsets.only(top: 10),
                  // color: Colors.black,
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(50),
                      image: DecorationImage(
                          image: NetworkImage(
                              "http://rationcart.in/assets/img/team/rohit.jfif"),
                          fit: BoxFit.fill)),
                ),
              ),
              SizedBox(
                height: 10,
              ),
              Text(
                'Aditya Roy',
                style: TextStyle(
                    fontSize: 19,
                    fontWeight: FontWeight.bold,
                    color: Colors.black),
              ),
              SizedBox(
                height: 10,
              ),
              Container(
                width: 166,
                child: Text(
                  'Aditya will connect with you within 5 minutes.',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.normal,
                      color: Colors.black),
                ),
              )
            ],
          ));
    });
  }

  bool isFollwLoading = false;
  void followVendor(String cid, String vid, bool follow) async {
    Map<String, dynamic> data = {
      'customerid': cid,
      'vendorid': vid,
      'follow': follow,
    };
    setState(() {
      isFollwLoading = true;
    });
    var response = await networkProvider.post('vendor-follower', data);
    print(response.body);
    if (response.statusCode == 200) {
      Map jsonResponse = jsonDecode(response.body);
      if (jsonResponse['data'] == 'inserted' ||
          jsonResponse['data'] == 'updated') {
        if (follow == false) {
          setState(() {
            isfollowing = false;
          });
          Fluttertoast.showToast(
              msg: "Sorry for inconvenience with  ${results[0].name}",
              toastLength: Toast.LENGTH_SHORT,
              gravity: ToastGravity.BOTTOM,
              timeInSecForIosWeb: 1,
              backgroundColor: darkBlue,
              textColor: Colors.white,
              fontSize: 16.0);
        }
      }
      if (follow == true) {
        setState(() {
          isfollowing = true;
        });
        Fluttertoast.showToast(
            msg: "Thanks for following ${results[0].name}",
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.BOTTOM,
            timeInSecForIosWeb: 1,
            backgroundColor: darkBlue,
            textColor: Colors.white,
            fontSize: 16.0);
      }
    }
  }

  Widget AllReviews(ScrollController scrollController) {
    return Column(children: <Widget>[
      Container(
        padding: EdgeInsets.symmetric(vertical: 10, horizontal: 10),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text("Customer Review"),
            InkWell(
                onTap: () {
                  Navigator.pop(context);
                },
                child: Icon(Icons.cancel))
          ],
        ),
      ),
      Expanded(
        child: ListView.builder(
            controller: scrollController,
            itemCount: ratingReviewData.length,
            itemBuilder: (context, index) {
              return Container(
                padding: EdgeInsets.all(15),
                margin: EdgeInsets.only(bottom: 10),
                // height: 130,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  color: Colors.white,
                  boxShadow: [
                    BoxShadow(
                      color: Color.fromRGBO(0, 0, 0, 0.16),
                      offset: const Offset(
                        3.0,
                        3.0,
                      ),
                      blurRadius: 6.0,
                      spreadRadius: 2.0,
                    ), //BoxShadow
                    BoxShadow(
                      color: Colors.white,
                      offset: const Offset(0.0, 0.0),
                      blurRadius: 0.0,
                      spreadRadius: 0.0,
                    ), //BoxShadow
                  ],
                ),
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Container(
                            child: Row(children: [
                              Container(
                                height: 44,
                                width: 44,
                                decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    image: DecorationImage(
                                        image: NetworkImage(MainUrl +
                                            "customer-image/" +
                                            ratingReviewData[index].photo),
                                        fit: BoxFit.fill)),
                              ),
                              SizedBox(
                                width: 15,
                              ),
                              Container(
                                child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        ratingReviewData[index].name,
                                        style: TextStyle(
                                            fontSize: 14,
                                            fontWeight: FontWeight.bold),
                                      ),
                                      Container(
                                        child: RatingBarIndicator(
                                          rating: ratingReviewData[index]
                                              .rating
                                              .toDouble(),
                                          itemBuilder: (context, index) => Icon(
                                            Icons.star,
                                            color: Colors.amber,
                                          ),
                                          itemCount: 5,
                                          itemSize: 13.0,
                                          direction: Axis.horizontal,
                                        ),
                                      ),
                                    ]),
                              ),
                            ]),
                          ),
                          Container(
                            child: PopupMenuButton<int>(
                              itemBuilder: (context) => [
                                // popupmenu item 1
                                PopupMenuItem(
                                  value: 1,
                                  // row has two child icon and text.
                                  child: Row(
                                    children: [Text("Report Review")],
                                  ),
                                ),
                                // popupmenu item 2
                                PopupMenuItem(
                                  value: 2,
                                  // row has two child icon and text
                                  child: Row(
                                    children: [Text("Block Review")],
                                  ),
                                ),
                              ],
                              offset: Offset(10, 40),
                              color: Colors.white,
                              elevation: 4,
                            ),
                            //  Icon(
                            //   Icons.more_vert,
                            //   size: 28,
                            // ),
                          )
                        ],
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      Container(
                        child: Text(
                          ratingReviewData[index].review,
                          textAlign: TextAlign.start,
                          style: TextStyle(
                              fontSize: 12,
                              color: Colors.black.withOpacity(0.53)),
                        ),
                      )
                    ]),
              );
            }),
      )
    ]);
  }
}

class ImageDialog extends StatelessWidget {
  ImageDialog(this.image);
  String image;
  @override
  Widget build(BuildContext context) {
    return Dialog(
      insetPadding: EdgeInsets.all(5),
      elevation: 5,
      backgroundColor: Colors.white,
      shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.all(Radius.circular(32.0))),
      // contentPadding: EdgeInsets.only(top: 10.0),
      child: Container(
        height: 300,
        width: 300,
        decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(15),
            image: DecorationImage(
                image: NetworkImage(image), fit: BoxFit.contain)),
      ),
    );
  }
}

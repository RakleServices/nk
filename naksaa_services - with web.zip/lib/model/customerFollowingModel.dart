// To parse this JSON data, do
//
//     final customerFollowing = customerFollowingFromJson(jsonString);

import 'dart:convert';

CustomerFollowing customerFollowingFromJson(String str) =>
    CustomerFollowing.fromJson(json.decode(str));

String customerFollowingToJson(CustomerFollowing data) =>
    json.encode(data.toJson());

class CustomerFollowing {
  CustomerFollowing({
    required this.rowsCount,
    required this.status,
    required this.data,
  });

  int rowsCount;
  bool status;
  List<CustomerFollowingData> data;

  factory CustomerFollowing.fromJson(Map<String, dynamic> json) =>
      CustomerFollowing(
        rowsCount: json["rowsCount"],
        status: json["status"],
        data: List<CustomerFollowingData>.from(
            json["data"].map((x) => CustomerFollowingData.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "rowsCount": rowsCount,
        "status": status,
        "data": List<dynamic>.from(data.map((x) => x.toJson())),
      };
}

class CustomerFollowingData {
  CustomerFollowingData({
    required this.vendorid,
    required this.follow,
    required this.customerid,
    required this.id,
    required this.name,
    required this.photo,
    required this.language,
    required this.startdate,
    required this.enddate,
    required this.primaryskills,
  });

  int vendorid;
  String follow;
  int customerid;
  int id;
  String name;
  String photo;
  String language;
  DateTime startdate;
  DateTime enddate;
  String primaryskills;

  factory CustomerFollowingData.fromJson(Map<String, dynamic> json) =>
      CustomerFollowingData(
        vendorid: json["vendorid"],
        follow: json["follow"],
        customerid: json["customerid"],
        id: json["id"],
        name: json["name"],
        photo: json["photo"],
        language: json["language"],
        startdate: DateTime.parse(json["startdate"]),
        enddate: DateTime.parse(json["enddate"]),
        primaryskills: json["primaryskills"],
      );

  Map<String, dynamic> toJson() => {
        "vendorid": vendorid,
        "follow": follow,
        "customerid": customerid,
        "id": id,
        "name": name,
        "photo": photo,
        "language": language,
        "startdate":
            "${startdate.year.toString().padLeft(4, '0')}-${startdate.month.toString().padLeft(2, '0')}-${startdate.day.toString().padLeft(2, '0')}",
        "enddate":
            "${enddate.year.toString().padLeft(4, '0')}-${enddate.month.toString().padLeft(2, '0')}-${enddate.day.toString().padLeft(2, '0')}",
        "primaryskills": primaryskills,
      };
}

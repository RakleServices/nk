import 'package:flutter/src/widgets/container.dart';
import 'package:flutter/src/widgets/framework.dart';

import 'package:flutter/material.dart';
import 'package:naksaa_services/MainAsset/LoadingIndicator.dart';
import 'package:naksaa_services/Service/PaymentLogService.dart';
import 'package:naksaa_services/UI/REgister/project%20Assets/constants.dart';
import 'package:naksaa_services/model/CustomerWalletModel.dart';
import 'package:naksaa_services/model/PaymentLogs.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../../Service/WalletService.dart';
import '../../Home/Utility/rechargeNowUtility.dart';

class WalletSection extends StatefulWidget {
  const WalletSection({super.key});

  @override
  State<WalletSection> createState() => _WalletSectionState();
}

class _WalletSectionState extends State<WalletSection> {
  List<Walletdatum> _walletList = [];
  List<Paymentlog> _paymentLog = [];
  bool isloading = false;
  bool ploading = false;
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getWalletAmount();
    getPaymentLogs();
  }

  var walletService = CustomerWalletService();
  Future<void> getWalletAmount() async {
    SharedPreferences pref = await SharedPreferences.getInstance();
    String? uid = pref.getString("uid");
    var response = await walletService.viewCustomerWallet(uid!);
    if (response != null) {
      setState(() {
        isloading = true;
      });
      _walletList = response;
    }
  }

  var paymentLogService = CustomerPaymentLogService();
  Future<void> getPaymentLogs() async {
    SharedPreferences pref = await SharedPreferences.getInstance();
    String? uid = pref.getString("uid");
    var response = await paymentLogService.viewCustomerPaymentLog(uid!);
    if (response != null) {
      setState(() {
        ploading = true;
      });
      _paymentLog = response;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.all(20),
      child: Column(children: [
        Container(
          height: 120,
          padding: const EdgeInsets.only(left: 30, right: 30),
          decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(35), color: blueColor),
          child:
              Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            isloading != false
                ? Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        "Available Balance",
                        style: TextStyle(
                            color: Colors.white,
                            fontSize: 12,
                            fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      Text(
                        "₹ ${_walletList[0].walletamount}",
                        style: TextStyle(
                            color: Colors.white,
                            fontSize: 32,
                            fontWeight: FontWeight.bold),
                      )
                    ],
                  )
                : Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      CircularProgressIndicator(
                        color: themeColor,
                      )
                    ],
                  ),
            Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Text(
                  "Add More",
                  style: TextStyle(
                      color: Colors.white,
                      fontSize: 12,
                      fontWeight: FontWeight.bold),
                ),
                SizedBox(
                  height: 22,
                ),
                GestureDetector(
                  onTap: () {
                    showDialog<void>(
                      context: context,
                      barrierDismissible: false, // user must tap button!
                      builder: (BuildContext context) {
                        return AlertDialog(
                          elevation: 0.6,
                          contentPadding: EdgeInsets.only(
                              left: 20, right: 10, top: 5, bottom: 5),
                          titlePadding: EdgeInsets.only(
                              left: 20, right: 10, top: 5, bottom: 5),
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(15)),
                          title: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              const Text('Recharge Plan'),
                              IconButton(
                                icon: Icon(
                                  Icons.close,
                                  color: Colors.red,
                                ),
                                onPressed: () {
                                  Navigator.of(context).pop();
                                },
                              )
                            ],
                          ),
                          content: RechargeNow(),
                        );
                      },
                    );
                  },
                  child: Container(
                    height: 25,
                    width: 77,
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(6),
                        color: themeColor),
                    child: Center(
                      child: Text(
                        "Recharge",
                        style: TextStyle(
                            color: darkBlue,
                            fontSize: 12,
                            fontWeight: FontWeight.bold),
                      ),
                    ),
                  ),
                )
              ],
            )
          ]),
        ),
        const SizedBox(
          height: 10,
        ),
        ploading != false
            ? Container(
                height: 280,
                child: ListView.builder(
                    itemCount: _paymentLog.length,
                    shrinkWrap: true,
                    itemBuilder: ((context, index) {
                      return Container(
                        margin: EdgeInsets.only(top: 6, bottom: 6),
                        padding: EdgeInsets.all(10),
                        decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(10)),
                        child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(
                                    "Recharge",
                                    style: TextStyle(
                                        fontSize: 14,
                                        color: Colors.black,
                                        fontWeight: FontWeight.bold),
                                  ),
                                  Text(
                                    "₹ ${_paymentLog[index].amount}",
                                    style: TextStyle(
                                        fontSize: 14,
                                        color: Colors.green,
                                        fontWeight: FontWeight.bold),
                                  )
                                ],
                              ),
                              const SizedBox(
                                height: 10,
                              ),
                              Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(
                                      "${_paymentLog[index].createdat}",
                                      style: TextStyle(
                                          fontSize: 14,
                                          color: textColor,
                                          fontWeight: FontWeight.bold),
                                    ),
                                    Text(
                                      "GST : ₹ ${_paymentLog[index].gstamount != null ? _paymentLog[index].gstamount : 0}",
                                      style: TextStyle(
                                          fontSize: 14,
                                          color: Colors.black,
                                          fontWeight: FontWeight.bold),
                                    )
                                  ]),
                              const SizedBox(
                                height: 10,
                              ),
                              Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(
                                      "#Naksa${_paymentLog[index].id}",
                                      style: TextStyle(
                                          fontSize: 14,
                                          color: textColor,
                                          fontWeight: FontWeight.bold),
                                    ),
                                    Text(
                                      "${_paymentLog[index].status}",
                                      style: TextStyle(
                                          fontSize: 14,
                                          color: _paymentLog[index].status ==
                                                  'pending'
                                              ? darkBlue
                                              : _paymentLog[index].status ==
                                                      'success'
                                                  ? Colors.green
                                                  : Colors.red,
                                          fontWeight: FontWeight.bold),
                                    )
                                  ])
                            ]),
                      );
                    })),
              )
            : SizedBox(
                height: 200,
                child: LoadingIndicator(),
              )
      ]),
    );
  }
}

// To parse this JSON data, do
//
//     final ratingReviewModel = ratingReviewModelFromJson(jsonString);

import 'dart:convert';

RatingReviewModel ratingReviewModelFromJson(String str) =>
    RatingReviewModel.fromJson(json.decode(str));

String ratingReviewModelToJson(RatingReviewModel data) =>
    json.encode(data.toJson());

class RatingReviewModel {
  RatingReviewModel({
    required this.rowsCount,
    required this.avgrating,
    required this.status,
    required this.data,
  });

  int rowsCount;
  double avgrating;
  bool status;
  List<RatingData> data;

  factory RatingReviewModel.fromJson(Map<String, dynamic> json) =>
      RatingReviewModel(
        rowsCount: json["rowsCount"],
        avgrating: json["avgrating"],
        status: json["status"],
        data: List<RatingData>.from(
            json["data"].map((x) => RatingData.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "rowsCount": rowsCount,
        "avgrating": avgrating,
        "status": status,
        "data": List<dynamic>.from(data.map((x) => x.toJson())),
      };
}

class RatingData {
  RatingData({
    required this.id,
    required this.customerid,
    required this.review,
    required this.rating,
    required this.transdate,
    required this.vid,
    required this.photo,
    required this.name,
  });

  int id;
  String customerid;
  String review;
  int rating;
  String transdate;
  String vid;
  String photo;
  String name;

  factory RatingData.fromJson(Map<String, dynamic> json) => RatingData(
        id: json["id"],
        customerid: json["customerid"],
        review: json["review"],
        rating: json["rating"],
        transdate: json["transdate"],
        vid: json["vid"],
        photo: json["photo"],
        name: json["name"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "customerid": customerid,
        "review": review,
        "rating": rating,
        "transdate": transdate,
        "vid": vid,
        "photo": photo,
        "name": name,
      };
}

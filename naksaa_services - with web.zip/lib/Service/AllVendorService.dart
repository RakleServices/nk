import 'dart:convert';

import 'package:http/http.dart' as http;
import 'package:naksaa_services/MainAsset/URL.dart';
import 'package:naksaa_services/model/AllVendorModel.dart';
import 'package:naksaa_services/model/RatingReviewModel.dart';
import 'package:naksaa_services/model/VendorAvailabilityModel.dart';
import 'package:naksaa_services/model/VendorWorkModel.dart';

import '../model/VendorDetailsModel.dart';

class AllVendorService {
  Future<List<Datum>?> viewallVendor() async {
    var client = http.Client();
    var uri = Uri.parse(BaseUrl + 'allvendor');
    var response = await client.get(uri);
    if (response.statusCode == 200) {
      var json = response.body;
      // print(json);
      return VendorModel.fromJson(jsonDecode(json)).data.toList();
    } else {
      throw Exception('failed to load data');
    }
  }

  Future viewSingleVendor(String id) async {
    var client = http.Client();
    var uri = Uri.parse(BaseUrl + 'vendor/$id');
    var response = await client.get(uri);
    if (response.statusCode == 200) {
      var json = response.body;
      // print(json);
      return json;
    } else {
      throw Exception('failed to load data');
    }
  }

  Future<List<VendorWork>> viewWorkPortfolio(String id) async {
    var client = http.Client();
    var uri = Uri.parse(BaseUrl + 'vendor-workportfolio/${id}');
    var response = await client.get(uri);
    if (response.statusCode == 200) {
      var json = response.body;
      // print(json);
      return VendorWorkModel.fromJson(jsonDecode(json)).data.toList();
    } else {
      throw Exception('failed to load data');
    }
  }

  Future<List<RatingData>> viewRatingReview(String id) async {
    var client = http.Client();
    var uri = Uri.parse(BaseUrl + 'rating-review/${id}');
    var response = await client.get(uri);
    if (response.statusCode == 200) {
      var json = response.body;
      // print(json);
      return RatingReviewModel.fromJson(jsonDecode(json)).data.toList();
    } else {
      throw Exception('failed to load data');
    }
  }

  Future<List<VendorAData>> viewVendorAvailability(String id) async {
    var client = http.Client();
    var uri = Uri.parse(BaseUrl + 'vavailability/${id}');
    var response = await client.get(uri);
    if (response.statusCode == 200) {
      var json = response.body;
      // print(json);
      return VendorAvailabilityModel.fromJson(jsonDecode(json)).data.toList();
    } else {
      throw Exception('failed to load data');
    }
  }
}

import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:naksaa_services/API/NetworkProvider.dart';
import 'package:naksaa_services/MainAsset/LoadingIndicator.dart';
import 'package:naksaa_services/UI/Home/Partner/VideoCall/OrderSuccessModel.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../../REgister/project Assets/constants.dart';

class VideoCallAndAudioCallModal extends StatefulWidget {
  String name;
  String image;
  String audioCallPrice;
  String videoCallPrice;
  String vid;
  VideoCallAndAudioCallModal(
      {super.key,
      required this.name,
      required this.vid,
      required this.audioCallPrice,
      required this.image,
      required this.videoCallPrice});

  @override
  State<VideoCallAndAudioCallModal> createState() =>
      _VideoCallAndAudioCallModalState();
}

class _VideoCallAndAudioCallModalState
    extends State<VideoCallAndAudioCallModal> {
  bool isloading = false;
  var networkHandler = NetworkHandler();
  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      elevation: 0.6,
      contentPadding: EdgeInsets.only(left: 20, right: 10, top: 5, bottom: 5),
      titlePadding: EdgeInsets.only(left: 20, right: 10, top: 5, bottom: 5),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      title: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            "Call with ${widget.name}",
            style: TextStyle(
                fontSize: 17, fontWeight: FontWeight.bold, color: darkBlue),
          ),
          IconButton(
              onPressed: () {
                Navigator.pop(context);
              },
              icon: const Icon(
                Icons.close,
                color: Colors.black,
              ))
        ],
      ),
      content: isloading != true
          ? Container(
              height: 135,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  GestureDetector(
                    onTap: () {
                      setState(() {
                        isloading = true;
                      });
                      audioCallOrder(widget.name, widget.image, widget.vid);
                    },
                    child: Column(
                      children: [
                        Container(
                            height: 65,
                            width: 65,
                            decoration: BoxDecoration(
                                color: themeColor, shape: BoxShape.circle),
                            child: Icon(Icons.call)),
                        const SizedBox(
                          height: 10,
                        ),
                        const Text(
                          "Audio Call",
                          style: TextStyle(
                              fontSize: 15,
                              fontWeight: FontWeight.bold,
                              color: darkBlue),
                        ),
                        const SizedBox(
                          height: 5,
                        ),
                        Text(
                          "₹ ${widget.audioCallPrice}/min",
                          style: TextStyle(
                              fontSize: 12, fontWeight: FontWeight.w500),
                        )
                      ],
                    ),
                  ),
                  const SizedBox(
                    width: 10,
                  ),
                  GestureDetector(
                    onTap: () {
                      setState(() {
                        isloading = true;
                      });

                      videoCallOrder(widget.vid, widget.name, widget.image);
                    },
                    child: Column(
                      children: [
                        Container(
                            height: 65,
                            width: 65,
                            decoration: BoxDecoration(
                                color: themeColor, shape: BoxShape.circle),
                            child: Icon(Icons.video_call)),
                        const SizedBox(
                          height: 10,
                        ),
                        const Text(
                          "Video Call",
                          style: TextStyle(
                              fontSize: 15,
                              fontWeight: FontWeight.bold,
                              color: darkBlue),
                        ),
                        Text(
                          "₹ ${widget.videoCallPrice}/min",
                          style: TextStyle(
                              fontSize: 12, fontWeight: FontWeight.w500),
                        )
                      ],
                    ),
                  )
                ],
              ))
          : Container(
              height: 135,
              color: Colors.white,
              child: const Center(
                child: CircularProgressIndicator(
                  color: themeColor,
                ),
              ),
            ),
    );
  }

  void audioCallOrder(String name, String image, String vid) async {
    SharedPreferences pref = await SharedPreferences.getInstance();

    Map<String, String> data = {
      "userid": pref.getString("uid").toString(),
      "vid": vid,
      "orderfor": "call",
      "createdat": DateTime.now().toString()
    };

    var response = await networkHandler.post("new-order", data);
    if (response.statusCode == 200) {
      Map jsonResponse = jsonDecode(response.body);
      if (jsonResponse["data"] == "created") {
        print("Order created succesflly");
        setState(() {
          isloading = false;
        });
        Navigator.pop(context);
        showDialog(
          context: context,
          builder: (BuildContext context) => OrderSuccessModel(
            vendorName: name,
            vendorimage: image,
            response: "success",
          ),
        );
      } else {
        setState(() {
          isloading = false;
        });
        Navigator.pop(context);
        showDialog(
          context: context,
          builder: (BuildContext context) => OrderSuccessModel(
            vendorName: name,
            vendorimage: image,
            response: "failed",
          ),
        );
        print("Something went wrong");
      }
    }
  }

  void videoCallOrder(String vid, String name, String image) async {
    SharedPreferences pref = await SharedPreferences.getInstance();

    Map<String, String> data = {
      "userid": pref.getString("uid").toString(),
      "vid": vid,
      "orderfor": "video-call",
      "createdat": DateTime.now().toString()
    };

    var response = await networkHandler.post("new-order", data);
    if (response.statusCode == 200) {
      Map jsonResponse = jsonDecode(response.body);
      if (jsonResponse["data"] == "created") {
        print("Order created succesflly");
        setState(() {
          isloading = false;
        });
        Navigator.pop(context);
        showDialog(
          context: context,
          builder: (BuildContext context) => OrderSuccessModel(
              vendorName: name, vendorimage: image, response: "success"),
        );
      } else {
        setState(() {
          isloading = false;
        });
        Navigator.pop(context);
        showDialog(
            context: context,
            builder: (BuildContext context) => OrderSuccessModel(
                  vendorName: name,
                  vendorimage: image,
                  response: "failed",
                ));
        print("Something went wrong");
      }
    }
  }
}

import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:naksaa_services/UI/Home/CallScreen.dart';
import 'package:naksaa_services/UI/Home/ChatScreen.dart';
import 'package:naksaa_services/UI/Home/HistoryScreen.dart';
import 'package:naksaa_services/UI/Home/HomeScreen.dart';
import 'package:naksaa_services/UI/REgister/project%20Assets/constants.dart';

import '../REgister/newScreen.dart';
import 'Partner/LiveVendorScreen.dart';

class BottomNavigationBarScreen extends StatefulWidget {
  int pageIndex;
  BottomNavigationBarScreen({super.key, required this.pageIndex});

  @override
  State<BottomNavigationBarScreen> createState() =>
      _BottomNavigationBarScreenState(this.pageIndex);
}

class _BottomNavigationBarScreenState extends State<BottomNavigationBarScreen> {
  int pageIndex;
  _BottomNavigationBarScreenState(this.pageIndex);

  final pages = [
    const HomeScreen(),
    const ChatMainScreen(),
    // const LiveVendorScreen(
    //   channelId: '15151',
    //   isRole: false,
    //   uid: 123,
    // ),
    const ChatMainScreen(),
    const CallMainScreen(),
    const HistoryScreen(),
  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Color.fromRGBO(242, 244, 243, 1),
        body: pages[pageIndex],
        bottomNavigationBar: buildMyNavBar(context),
        bottomSheet: Padding(padding: EdgeInsets.only(bottom: 85.0)));
  }

  Container buildMyNavBar(BuildContext context) {
    var screenHeight = MediaQuery.of(context).size.height;
    var screenWidth = MediaQuery.of(context).size.width;
    Color themeColor = Color.fromRGBO(255, 215, 0, 1);
    Color secondColor = Color.fromRGBO(2, 44, 67, 1).withOpacity(0.59);
    return Container(
      height: 75,
      decoration: BoxDecoration(
          color: Color.fromRGBO(255, 255, 255, 1),
          borderRadius: BorderRadius.only(
              topLeft: Radius.circular(18), topRight: Radius.circular(18))),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          GestureDetector(
            onTap: () {
              setState(() {
                pageIndex = 0;
              });
            },
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Container(
                  height: 3,
                  width: 40,
                  color: themeColor,
                ),
                SizedBox(
                  height: 10,
                ),
                Container(
                    height: screenHeight / 23.31,
                    child: pageIndex == 0
                        ? Container(
                            child: SvgPicture.asset("assets/SVG/home.svg"),
                          )
                        : Container(
                            child: SvgPicture.asset("assets/SVG/home.svg"),
                          )),
                Container(
                  padding: EdgeInsets.only(left: 3),
                  child: BigText(
                    name: "Home",
                  ),
                )
              ],
            ),
          ),
          GestureDetector(
            onTap: () {
              setState(() {
                pageIndex = 1;
              });
            },
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Container(
                  height: 3,
                  width: 40,
                  color: themeColor,
                ),
                SizedBox(
                  height: 10,
                ),
                Container(
                    height: screenHeight / 23.31,
                    child: pageIndex == 1
                        ? Container(
                            child: SvgPicture.asset("assets/SVG/chat.svg"),
                          )
                        : Container(
                            child:
                                SvgPicture.asset("assets/SVG/chat-yellow.svg"),
                          )),
                Container(
                  padding: EdgeInsets.only(left: 3),
                  child: BigText(
                    name: "Chat",
                  ),
                )
              ],
            ),
          ),
          GestureDetector(
            onTap: () {
              setState(() {
                pageIndex = 2;
              });
            },
            child: Container(
              // height: 55,
              // width: 55,
              // decoration: BoxDecoration(
              //     color: pageIndex == 2 ? themeColor : Colors.white,
              //     shape: BoxShape.circle,
              //     border: Border.all(width: 1, color: blueColor)),
              child: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      child: pageIndex == 2
                          ? Icon(
                              Icons.play_arrow,
                              color: themeColor,
                              size: screenHeight / 27.2,
                            )
                          : Icon(
                              Icons.play_arrow,
                              color: blueColor,
                              size: screenHeight / 27.2,
                            ),
                    ),
                    Container(
                      padding: EdgeInsets.only(left: 3),
                      child: BigText(
                        name: "Live",
                      ),
                    )
                  ],
                ),
              ),
            ),
          ),
          GestureDetector(
            onTap: () {
              setState(() {
                pageIndex = 3;
              });
            },
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Container(
                  height: 3,
                  width: 40,
                  color: themeColor,
                ),
                SizedBox(
                  height: 10,
                ),
                Container(
                    height: screenHeight / 23.31,
                    child: pageIndex == 3
                        ? Container(
                            child: SvgPicture.asset("assets/SVG/phone.svg"),
                          )
                        : Container(
                            child: SvgPicture.asset("assets/SVG/phone.svg"),
                          )),
                Container(
                  padding: EdgeInsets.only(left: 3),
                  child: BigText(
                    name: "Call",
                  ),
                )
              ],
            ),
          ),
          GestureDetector(
            onTap: () {
              setState(() {
                pageIndex = 4;
              });
            },
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Container(
                  height: 3,
                  width: 40,
                  color: themeColor,
                ),
                SizedBox(
                  height: 10,
                ),
                Container(
                    height: screenHeight / 23.31,
                    child: pageIndex == 4
                        ? Container(
                            child: SvgPicture.asset("assets/SVG/history.svg"),
                          )
                        : Container(
                            child: SvgPicture.asset("assets/SVG/history.svg"),
                          )),
                Container(
                  padding: EdgeInsets.only(left: 3),
                  child: BigText(
                    name: "History",
                  ),
                )
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class BigText extends StatelessWidget {
  final String name;
  final Color color;
  final double size;
  BigText(
      {Key? key,
      required this.name,
      this.color = Colors.black,
      this.size = 11.0})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Text(
      name,
      maxLines: 3,
      overflow: TextOverflow.ellipsis,
      style:
          TextStyle(fontSize: size, fontWeight: FontWeight.bold, color: color),
    );
  }
}

// To parse this JSON data, do
//
//     final vendorWorkModel = vendorWorkModelFromJson(jsonString);

import 'dart:convert';

VendorWorkModel vendorWorkModelFromJson(String str) =>
    VendorWorkModel.fromJson(json.decode(str));

String vendorWorkModelToJson(VendorWorkModel data) =>
    json.encode(data.toJson());

class VendorWorkModel {
  VendorWorkModel({
    required this.rowsCount,
    required this.status,
    required this.data,
  });

  int rowsCount;
  bool status;
  List<VendorWork> data;

  factory VendorWorkModel.fromJson(Map<String, dynamic> json) =>
      VendorWorkModel(
        rowsCount: json["rowsCount"],
        status: json["status"],
        data: List<VendorWork>.from(
            json["data"].map((x) => VendorWork.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "rowsCount": rowsCount,
        "status": status,
        "data": List<dynamic>.from(data.map((x) => x.toJson())),
      };
}

class VendorWork {
  VendorWork({
    required this.id,
    required this.photo,
    required this.vid,
  });

  int id;
  String photo;
  int vid;

  factory VendorWork.fromJson(Map<String, dynamic> json) => VendorWork(
        id: json["id"],
        photo: json["photo"],
        vid: json["vid"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "photo": photo,
        "vid": vid,
      };
}

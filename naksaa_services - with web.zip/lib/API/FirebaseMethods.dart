import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/cupertino.dart';
import 'package:uuid/uuid.dart';

Future<User?> createAcountFirebase(
    String name, String email, String password) async {
  FirebaseAuth _auth = FirebaseAuth.instance;
  FirebaseFirestore firebaseFirestore = FirebaseFirestore.instance;

  try {
    User? _user = (await _auth.createUserWithEmailAndPassword(
            email: email, password: password))
        .user;
    if (_user != null) {
      print("Accounted Created Succesfully");
      _user.updateProfile(displayName: name);
      await firebaseFirestore
          .collection("users")
          .doc(_auth.currentUser!.uid)
          .set({
        "name": name,
        "email": email,
        "status": "unavailable",
        "role": "customer",
        "uid": _auth.currentUser!.uid
      });

      return _user;
    } else {
      print("Account Creattion Failed");
      return _user!;
    }
  } catch (e) {
    print(e);
    return null;
  }
}

Future<User?> loginFirebase(String email, String password) async {
  FirebaseAuth _auth = FirebaseAuth.instance;
  try {
    User? _user = (await _auth.signInWithEmailAndPassword(
            email: email, password: password))
        .user;
    if (_user != null) {
      print("Login successsfull");
      return _user;
    } else {
      print("Login Failed");
      return _user;
    }
  } catch (e) {
    print(e);
    return null;
  }
}

Future Logout() async {
  FirebaseAuth _auth = FirebaseAuth.instance;
  try {
    await _auth.signOut();
    print("logout");
  } catch (e) {
    print(e);
  }
}

Future<void> updateViewCount(String id, bool isIncrease) async {
  FirebaseFirestore firebaseFirestore = FirebaseFirestore.instance;
  try {
    await firebaseFirestore
        .collection('livestream')
        .doc(id)
        .update({'viewer': FieldValue.increment(isIncrease ? 1 : -1)});
  } catch (e) {
    print(e.toString());
  }
}

Future<void> chatFirebase(String text, String id, BuildContext context,
    String username, String uid) async {
  FirebaseFirestore firebaseFirestore = FirebaseFirestore.instance;
  try {
    String commentId = const Uuid().v1();
    await firebaseFirestore
        .collection('livestream')
        .doc(id)
        .collection('comments')
        .doc(commentId)
        .set({
      'username': username,
      'message': text,
      'uid': uid,
      'createdAt': DateTime.now(),
      'commentId': commentId
    });
  } on FirebaseException catch (e) {
    print(e.toString());
  }
}

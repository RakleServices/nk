import 'dart:convert';

import 'package:http/http.dart' as http;
import 'package:naksaa_services/MainAsset/URL.dart';
import 'package:naksaa_services/model/CustomerProfileModel.dart';

class CustomerProfileService {
  Future<List<CustomerP>?> viewCustomerProfile(String phone) async {
    var client = http.Client();
    var uri = Uri.parse(BaseUrl + 'customer-profile/${phone}');
    var response = await client.get(uri);
    if (response.statusCode == 200) {
      var json = response.body;
      print(json);
      // print(json);
      return CustomerProfileModel.fromJson(jsonDecode(json)).data.toList();
    } else {
      throw Exception('failed to load data');
    }
  }
}

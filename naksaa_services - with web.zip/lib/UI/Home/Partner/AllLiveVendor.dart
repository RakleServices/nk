import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/container.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:naksaa_services/UI/Home/Partner/LivePeople.dart';
import 'package:naksaa_services/UI/REgister/project%20Assets/constants.dart';

import '../BottomNavigation.dart';

class AllLiveVendor extends StatefulWidget {
  const AllLiveVendor({super.key});

  @override
  State<AllLiveVendor> createState() => _AllLiveVendorState();
}

class _AllLiveVendorState extends State<AllLiveVendor>
    with TickerProviderStateMixin {
  late TabController _controller;
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _controller = TabController(
      vsync: this,
      length: 2,
      initialIndex: 0,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Live Naksian"),
        backgroundColor: themeColor,
        elevation: 0,
      ),
      body: SingleChildScrollView(
        child: Container(
          child: Column(
            children: [
              TabBar(
                labelColor: darkBlue,
                // labelStyle: theme.textTheme.headline1,
                indicatorColor: darkBlue,
                // indicatorSize: TabBarIndicatorSize.label,
                // indicatorPadding: tab,

                unselectedLabelColor: Colors.grey,
                controller: _controller,
                tabs: [
                  Tab(
                    child: Text(
                      "OnGoing",
                      style:
                          TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                    ),
                  ),
                  Tab(
                    child: Text(
                      "UpComing",
                      style:
                          TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                    ),
                  ),
                ],
              ),
              Container(
                padding: EdgeInsets.all(8),
                height: 655,
                child: TabBarView(
                    physics: AlwaysScrollableScrollPhysics(),
                    controller: _controller,
                    children: [
                      Container(
                        child: GridView.builder(
                          itemCount: 20,
                          gridDelegate:
                              SliverGridDelegateWithFixedCrossAxisCount(
                                  childAspectRatio: 0.8,
                                  crossAxisCount: 3,
                                  crossAxisSpacing: 5.0,
                                  mainAxisSpacing: 5.0),
                          itemBuilder: (BuildContext context, int index) {
                            return InkWell(
                              onTap: () {
                                Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) =>
                                            BottomNavigationBarScreen(
                                              pageIndex: 2,
                                            )));
                              },
                              child: Container(
                                height: 140,
                                margin: EdgeInsets.only(right: 10),
                                child: Stack(
                                    alignment: Alignment.center,
                                    children: [
                                      Container(
                                        height: 140,
                                        width: 100,
                                        decoration: BoxDecoration(
                                            color: Colors.yellow,
                                            borderRadius:
                                                BorderRadius.circular(10),
                                            image: DecorationImage(
                                                image: NetworkImage(
                                                    "https://www.tikli.in/wp-content/uploads/2022/02/rashmika-mandanna-10.jpg"),
                                                fit: BoxFit.fill)),
                                      ),
                                      Positioned(
                                          top: 85,
                                          left: 30,
                                          child: Container(
                                            padding: EdgeInsets.symmetric(
                                                vertical: 2, horizontal: 5),
                                            decoration: BoxDecoration(
                                                borderRadius:
                                                    BorderRadius.circular(5),
                                                color: Color.fromRGBO(
                                                        56, 56, 56, 1)
                                                    .withOpacity(0.55)),
                                            child: Row(
                                              children: [
                                                Container(
                                                  height: 8,
                                                  width: 8,
                                                  decoration: BoxDecoration(
                                                      shape: BoxShape.circle,
                                                      color: Color.fromRGBO(
                                                          36, 220, 55, 1)),
                                                ),
                                                SizedBox(
                                                  width: 5,
                                                ),
                                                Text(
                                                  "Live",
                                                  style:
                                                      TextStyle(fontSize: 10),
                                                ),
                                              ],
                                            ),
                                          )),
                                      Positioned(
                                          top: 105,
                                          // left: 10,
                                          child: Container(
                                            child: Text(
                                              "Rashmika Gautam",
                                              style: TextStyle(
                                                  fontSize: 11,
                                                  fontWeight: FontWeight.bold),
                                            ),
                                          ))
                                    ]),
                              ),
                            );
                          },
                        ),
                      ),
                      Container()
                    ]),
              )
            ],
          ),
        ),
      ),
    );
  }
}

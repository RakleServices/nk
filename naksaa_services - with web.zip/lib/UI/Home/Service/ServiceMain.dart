import 'package:flutter/material.dart';
import 'package:naksaa_services/UI/Home/Partner/demo1.dart';
import 'package:naksaa_services/UI/Home/Service/InteriorDesginer.dart';
import 'package:naksaa_services/UI/Home/ServiceDescription/InteriorDesgin.dart';

class ServiceMainScreen extends StatefulWidget {
  const ServiceMainScreen({super.key});

  @override
  State<ServiceMainScreen> createState() => _ServiceMainScreenState();
}

class _ServiceMainScreenState extends State<ServiceMainScreen> {
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, constraints) {
      if (constraints.maxWidth > 1200) {
        return DesktopServiceMain();
      } else if (constraints.maxWidth > 800 && constraints.maxWidth < 1200) {
        return DesktopServiceMain();
      } else {
        return MobileServiceMain();
      }
    });
  }

  Widget MobileServiceMain() {
    return Container(
      margin: EdgeInsets.only(left: 10, right: 10, top: 6),
      height: 85,
      child: ListView.builder(
          itemCount: 5,
          scrollDirection: Axis.horizontal,
          physics: NeverScrollableScrollPhysics(),
          itemBuilder: ((context, index) {
            return GestureDetector(
              onTap: () {
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) =>
                            //  DemoLive()
                            InteriorDesginDescription()));
              },
              child: Container(
                margin: EdgeInsets.only(right: 10),
                child: Column(
                  children: [
                    Container(
                      height: 60,
                      width: 60,
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(50),
                          color: Colors.yellow,
                          image: DecorationImage(
                              image: AssetImage("assets/SVG/civil.png"),
                              fit: BoxFit.contain)),
                    ),
                    Container(
                      child: Center(
                        child: Text('Structure',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              fontFamily: 'Varela',
                              fontSize: 12,
                            )),
                      ),
                    ),
                  ],
                ),
              ),
            );
          })),
    );
  }

  Widget DesktopServiceMain() {
    return Center(
      child: Container(
        margin: EdgeInsets.only(left: 10, right: 10, top: 6),
        height: 280,
        child: ListView.builder(
            itemCount: 5,
            scrollDirection: Axis.horizontal,
            physics: NeverScrollableScrollPhysics(),
            itemBuilder: ((context, index) {
              return GestureDetector(
                onTap: () {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) =>
                              //  DemoLive()
                              InteriorDesginDescription()));
                },
                child: Container(
                  margin: EdgeInsets.only(right: 40),
                  child: Column(
                    children: [
                      Container(
                        height: 200,
                        width: 200,
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(50),
                            color: Colors.yellow,
                            image: DecorationImage(
                                image: AssetImage("assets/SVG/civil.png"),
                                fit: BoxFit.contain)),
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      Container(
                        child: Center(
                          child: Text('Interior Desginer',
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                fontFamily: 'Varela',
                                fontSize: 20,
                              )),
                        ),
                      ),
                    ],
                  ),
                ),
              );
            })),
      ),
    );
  }
}

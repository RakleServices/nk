import 'dart:convert';

import 'package:http/http.dart' as http;
import 'package:naksaa_services/model/AllVendorModel.dart';

import '../MainAsset/URL.dart';

class SearchService {
  static Future<List<Datum>> searchProducts(String query) async {
    Map mapresponse;
    // List<Re> results = [];

    final response = await http.get(Uri.parse(BaseUrl + 'allvendor'));

    if (response.statusCode == 200) {
      print("data loaded");
      mapresponse = json.decode(response.body);
      List services = mapresponse["data"];
      print("1 $services");
      return services.map((json) => Datum.fromJson(json)).where((services) {
        final nameLower = services.name.toLowerCase();
        // final boardLower = services.board!.toLowerCase();
        // final subjectLower = services.subject!.toLowerCase();
        // final classLower = services.sClass!.toLowerCase();
        final searchLower = query.toLowerCase();
        // print(services.sClass);
        return nameLower.contains(searchLower);
      }).toList();
      // if (query != null) {
      //   results = results
      //       .where(
      //           (element) => element.productName!.toLowerCase().contains(query))
      //       .toList();
      // }
      // print("2 $results");
      // return results;
    } else {
      throw Exception("data not loaded");
    }
  }
}

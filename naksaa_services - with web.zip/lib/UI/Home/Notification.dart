import 'package:flutter/material.dart';
import 'package:naksaa_services/UI/REgister/project%20Assets/constants.dart';
import 'package:shared_preferences/shared_preferences.dart';

class NaksaNotifictaion extends StatefulWidget {
  const NaksaNotifictaion({super.key});

  @override
  State<NaksaNotifictaion> createState() => _NaksaNotifictaionState();
}

class _NaksaNotifictaionState extends State<NaksaNotifictaion> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Notifications"),
        backgroundColor: themeColor,
        actions: [
          Container(
              height: 40,
              margin: EdgeInsets.only(right: 10),
              child: Center(child: Text("Clear")))
        ],
      ),
      body: Container(
        margin: EdgeInsets.all(15),
        child: ListView.builder(
            itemCount: 5,
            itemBuilder: (context, index) {
              return GestureDetector(
                onTap: () async {
                  SharedPreferences pref =
                      await SharedPreferences.getInstance();
                  pref.clear();
                },
                child: Container(
                  width: 334,
                  margin: EdgeInsets.only(bottom: 10),
                  padding: EdgeInsets.symmetric(vertical: 15, horizontal: 10),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    boxShadow: [
                      BoxShadow(
                        color: Color.fromRGBO(0, 0, 0, 0.16),
                        offset: const Offset(
                          3.0,
                          3.0,
                        ),
                        blurRadius: 6.0,
                        spreadRadius: 2.0,
                      ), //BoxShadow
                      BoxShadow(
                        color: Colors.white,
                        offset: const Offset(0.0, 0.0),
                        blurRadius: 0.0,
                        spreadRadius: 0.0,
                      ), //BoxShadow
                    ],
                  ),
                  child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text("Want to know your daily horoscope ?"),
                        Icon(Icons.arrow_forward_ios_sharp)
                      ]),
                ),
              );
            }),
      ),
    );
  }
}

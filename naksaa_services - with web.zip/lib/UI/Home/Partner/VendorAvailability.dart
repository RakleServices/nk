import 'package:flutter/material.dart';
import 'package:flutter_smart_dialog/flutter_smart_dialog.dart';
import 'package:naksaa_services/MainAsset/URL.dart';
import 'package:naksaa_services/Service/AllVendorService.dart';
import 'package:naksaa_services/UI/REgister/project%20Assets/constants.dart';
import 'package:naksaa_services/model/CustomerWalletModel.dart';
import 'package:naksaa_services/model/VendorAvailabilityModel.dart';
import 'package:naksaa_services/model/VendorDetailsModel.dart';

import '../Utility/rechargeNowUtility.dart';
import 'VideoCall/VideoCallandAudioCallModal.dart';

class VendorAvailabilityScreen extends StatefulWidget {
  List<Vdatum> Vendor;
  List<Walletdatum> wallet;
  VendorAvailabilityScreen(
      {super.key, required this.Vendor, required this.wallet});

  @override
  State<VendorAvailabilityScreen> createState() =>
      _VendorAvailabilityScreenState(this.Vendor);
}

class _VendorAvailabilityScreenState extends State<VendorAvailabilityScreen> {
  List<Vdatum> Vendor;
  _VendorAvailabilityScreenState(this.Vendor);
  var vendorService = AllVendorService();
  List<VendorAData> result = [];

  Future<List<VendorAData>> getVendorDetails() async {
    result =
        await vendorService.viewVendorAvailability(Vendor[0].id.toString());
    print(result);
    if (result != null) {
      return result;
    } else {
      throw Exception('Failed to load');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Availability"),
        backgroundColor: themeColor,
        elevation: 0,
      ),
      body: SingleChildScrollView(
        child: Column(children: [
          Container(
            margin: EdgeInsets.only(top: 10),
            child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Container(
                    height: 85,
                    width: 100,
                    child: Stack(children: [
                      Container(
                        margin: EdgeInsets.only(left: 10),
                        height: 76,
                        width: 76,
                        decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            // color: Colors.red,
                            border: Border.all(width: 2, color: lightblueColor),
                            image: DecorationImage(
                                image: NetworkImage(MainUrl +
                                    'vendor-image/' +
                                    Vendor[0].photo),
                                fit: BoxFit.cover)),
                      ),
                      Positioned(
                          top: 8,
                          right: 6,
                          child: Container(
                            height: 25,
                            width: 25,
                            decoration: BoxDecoration(
                                image: DecorationImage(
                                    image:
                                        AssetImage("assets/SVG/star2-2x.png"),
                                    fit: BoxFit.fill)),
                          )),
                    ]),
                  ),
                  Container(
                    child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            Vendor[0].name,
                            style: TextStyle(
                                fontSize: 14, fontWeight: FontWeight.bold),
                          ),
                          SizedBox(
                            width: 120,
                            child: Text(
                              Vendor[0].primaryskills,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                  fontSize: 12,
                                  fontWeight: FontWeight.normal,
                                  color: Colors.black.withOpacity(0.53)),
                            ),
                          ),
                          SizedBox(
                            width: 120,
                            child: Text(
                              Vendor[0].language,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                  fontSize: 12,
                                  fontWeight: FontWeight.normal,
                                  color: Colors.black.withOpacity(0.53)),
                            ),
                          ),
                          Text(
                            "Exp: ${(Vendor[0].startdate.difference(Vendor[0].enddate)).inDays} Years",
                            style: TextStyle(
                                fontSize: 12,
                                fontWeight: FontWeight.normal,
                                color: Colors.black.withOpacity(0.53)),
                          )
                        ]),
                  ),
                  Container(
                    margin: EdgeInsets.only(left: 49),
                    child: Column(children: [
                      GestureDetector(
                        onTap: () {
                          if (double.parse(widget.wallet[0].walletamount) >=
                              100.0) {
                            showDialog(
                                context: context,
                                builder: (BuildContext context) =>
                                    VideoCallAndAudioCallModal(
                                        name: widget.Vendor[0].name,
                                        image: widget.Vendor[0].photo,
                                        vid: widget.Vendor[0].id.toString(),
                                        audioCallPrice:
                                            widget.Vendor[0].audicallprice,
                                        videoCallPrice:
                                            widget.Vendor[0].audicallprice));
                          } else {
                            showDialog<void>(
                              context: context,
                              barrierDismissible:
                                  false, // user must tap button!
                              builder: (BuildContext context) {
                                return AlertDialog(
                                  elevation: 0.6,
                                  contentPadding: EdgeInsets.only(
                                      left: 20, right: 10, top: 5, bottom: 5),
                                  titlePadding: EdgeInsets.only(
                                      left: 20, right: 10, top: 5, bottom: 5),
                                  shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(15)),
                                  title: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      const Text('Recharge Plan'),
                                      IconButton(
                                        icon: Icon(
                                          Icons.close,
                                          color: Colors.red,
                                        ),
                                        onPressed: () {
                                          Navigator.of(context).pop();
                                        },
                                      )
                                    ],
                                  ),
                                  content: RechargeNow(),
                                );
                              },
                            );
                          }
                        },
                        child: Container(
                          height: 36,
                          width: 83,
                          decoration: BoxDecoration(
                              color: themeColor,
                              borderRadius: BorderRadius.only(
                                  topLeft: Radius.circular(22),
                                  bottomLeft: Radius.circular(22))),
                          child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(
                                  Icons.phone,
                                  color: blueColor,
                                  size: 20,
                                ),
                                SizedBox(
                                  width: 5,
                                ),
                                Text(
                                  "Call",
                                  style: TextStyle(
                                      fontSize: 14,
                                      color: blueColor,
                                      fontWeight: FontWeight.bold),
                                )
                              ]),
                        ),
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      GestureDetector(
                        onTap: () {
                          showDialog<void>(
                            context: context,
                            barrierDismissible: false, // user must tap button!
                            builder: (BuildContext context) {
                              return AlertDialog(
                                elevation: 0.6,
                                contentPadding: EdgeInsets.only(
                                    left: 20, right: 10, top: 5, bottom: 5),
                                titlePadding: EdgeInsets.only(
                                    left: 20, right: 10, top: 5, bottom: 5),
                                shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(15)),
                                title: Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    const Text('Recharge Plan'),
                                    IconButton(
                                      icon: Icon(
                                        Icons.close,
                                        color: Colors.red,
                                      ),
                                      onPressed: () {
                                        Navigator.of(context).pop();
                                      },
                                    )
                                  ],
                                ),
                                content: RechargeNow(),
                              );
                            },
                          );
                        },
                        child: Container(
                            height: 36,
                            width: 83,
                            decoration: BoxDecoration(
                                color: themeColor,
                                borderRadius: BorderRadius.only(
                                    topLeft: Radius.circular(22),
                                    bottomLeft: Radius.circular(22))),
                            child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Icon(
                                    Icons.message,
                                    color: blueColor,
                                    size: 20,
                                  ),
                                  SizedBox(
                                    width: 5,
                                  ),
                                  Text(
                                    "Chat",
                                    style: TextStyle(
                                        fontSize: 14,
                                        color: blueColor,
                                        fontWeight: FontWeight.bold),
                                  )
                                ])),
                      ),
                    ]),
                  )
                ]),
          ),
          FutureBuilder(
              future: getVendorDetails(),
              builder: (BuildContext ctx, AsyncSnapshot<List> item) => item
                      .hasData
                  ? item.data!.length != 0
                      ? Container(
                          width: 300,
                          margin: EdgeInsets.symmetric(
                              vertical: 15, horizontal: 20),
                          child: ListView.builder(
                            shrinkWrap: true,
                            physics: NeverScrollableScrollPhysics(),
                            itemCount: result.length,
                            itemBuilder: (context, index) {
                              List slotdata =
                                  result[index].slotrange.split(',');
                              return Container(
                                child: Row(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                        width: 65,
                                        child: Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.center,
                                            children: [
                                              Text(
                                                result[index].day,
                                                style: TextStyle(
                                                    fontSize: 12,
                                                    fontWeight:
                                                        FontWeight.bold),
                                              ),
                                              Text(
                                                "October 8th",
                                                style: TextStyle(
                                                    fontSize: 9,
                                                    fontWeight:
                                                        FontWeight.normal,
                                                    color: Colors.black
                                                        .withOpacity(0.53)),
                                              )
                                            ]),
                                      ),
                                      SizedBox(
                                        width: 25,
                                      ),
                                      Container(
                                        child: Column(children: [
                                          Container(
                                            height: 18,
                                            width: 18,
                                            decoration: BoxDecoration(
                                                color: themeColor,
                                                shape: BoxShape.circle),
                                          ),
                                          Container(
                                            width: 1,
                                            height: 217,
                                            color: Color.fromRGBO(
                                                112, 112, 112, 1),
                                          )
                                        ]),
                                      ),
                                      Container(
                                          width: 150,
                                          margin: EdgeInsets.only(
                                              left: 35, top: 15),
                                          child: ListView.builder(
                                              itemCount: slotdata.length,
                                              shrinkWrap: true,
                                              physics:
                                                  NeverScrollableScrollPhysics(),
                                              itemBuilder: (context, nindex) {
                                                return Container(
                                                  height: 34,
                                                  width: 174,
                                                  margin: EdgeInsets.only(
                                                      bottom: 10),
                                                  decoration: BoxDecoration(
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              21),
                                                      color: blueColor),
                                                  child: Center(
                                                    child: Text(
                                                      slotdata[nindex],
                                                      style: TextStyle(
                                                          fontSize: 13,
                                                          fontWeight:
                                                              FontWeight.bold,
                                                          color: Colors.white),
                                                    ),
                                                  ),
                                                );
                                              }))
                                    ]),
                              );
                            },
                          ))
                      : Center(
                          child: Text("No Data Found"),
                        )
                  : Container(
                      height: 800,
                      child: Center(
                        child: CircularProgressIndicator(),
                      ),
                    ))
        ]),
      ),
    );
  }
}

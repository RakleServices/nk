import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/src/widgets/container.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:naksaa_services/UI/Home/BottomNavigation.dart';
import 'package:naksaa_services/UI/Home/CallScreen.dart';
import 'package:naksaa_services/UI/Home/HomeScreen.dart';
import 'package:naksaa_services/UI/Home/Partner/CallRequest.dart';
import 'package:naksaa_services/UI/Home/Partner/CallWithCustomer.dart';
import 'package:naksaa_services/UI/Home/Partner/ChatRequest.dart';
import 'package:naksaa_services/UI/Home/Partner/VideoCall/IncomingVideoCallScreen.dart';
import 'package:naksaa_services/UI/REgister/PhoneRegister.dart';
import 'package:naksaa_services/UI/REgister/project%20Assets/constants.dart';
import 'package:naksaa_services/UI/REgister/project%20Assets/logo.dart';
import 'package:naksaa_services/main.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../Home/ChatScreen.dart';
import '../Home/Service/SharedDataService.dart';

class ChooseLanguage extends StatefulWidget {
  const ChooseLanguage({super.key});

  @override
  State<ChooseLanguage> createState() => _ChooseLanguageState();
}

class _ChooseLanguageState extends State<ChooseLanguage> {
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    // showNotifications();

    FirebaseMessaging.onMessage.listen((RemoteMessage message) {
      RemoteNotification? notification = message.notification;
      AndroidNotification? android = message.notification?.android;
      if (notification != null && android != null) {
        flutterLocalNotificationsPlugin.show(
            notification.hashCode,
            notification.title,
            notification.body,
            NotificationDetails(
                android: AndroidNotificationDetails(channel.id, channel.name,
                    channelDescription: channel.description,
                    color: themeColor,
                    playSound: true,
                    icon: '@mipmap/ic_launcher')));
      }
    });
    FirebaseMessaging.onMessageOpenedApp.listen((RemoteMessage message) {
      print("A new onmessageopenedapp is published");
      RemoteNotification? notification = message.notification;
      AndroidNotification? android = message.notification?.android;
      if (notification!.body != null && android != null) {
        print("Inside function" + message.data["vtokken"].toString());
        if (message.data["notificationtype"] == "chat") {
          Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (context) => IncomingChatRequest(
                        vendorid: message.data["vendorimage"],
                      )));
        }
        if (message.data["notificationtype"] == "call") {
          Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (context) => IncomingCallRequest(
                      channelname: "message.data[channelid]",
                      token: "message.data[vtokken]",
                      vendorid: message.data["vendorimage"])));
        }
        if (message.data["notificationtype"] == "video-call") {
          Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (context) => IncomingVideoCallRequest(
                      channelname: "message.data[channelid]",
                      token: "message.data[vtokken]",
                      vendorid: message.data["vendorimage"])));
        }
      }
    }).onError((error) {
      print(error);
    });
  }

  // void showNotifications() {
  //   flutterLocalNotificationsPlugin.show(
  //       0,
  //       "Testing message",
  //       "How to check it",
  //       NotificationDetails(
  //           android: AndroidNotificationDetails(channel.id, channel.name,
  //               channelDescription: channel.description,
  //               importance: Importance.high,
  //               color: Colors.blue,
  //               playSound: true,
  //               icon: '@mipmap/ic_launcher')));
  // }

  @override
  Widget build(BuildContext context) {
    var screenWidth = MediaQuery.of(context).size.width;
    var screenHeight = MediaQuery.of(context).size.height;
    Size size = MediaQuery.of(context).size;
    return LayoutBuilder(builder: (context, constraints) {
      if (constraints.maxWidth > 1200) {
        return DesktopLanguage();
      } else if (constraints.maxWidth > 800 && constraints.maxWidth < 1200) {
        return DesktopLanguage();
      } else {
        return MobileLanguage();
      }
    });
  }

  Widget DesktopLanguage() {
    var screenWidth = MediaQuery.of(context).size.width;
    var screenHeight = MediaQuery.of(context).size.height;
    Size size = MediaQuery.of(context).size;
    bool amIHovering = false;

    // store the position where your mouse pointer left the widget
    Offset exitFrom = Offset(0, 0);
    return Scaffold(
      body: Center(
        child: Container(
          height: 700,
          width: 500,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Container(
                margin: EdgeInsets.only(top: 30, left: 21),
                height: 140,
                width: 150,
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Container(
                        height: 100,
                        // width: 198,
                        child: Image.asset(
                          "assets/logo.png",
                          fit: BoxFit.fill,
                        ),
                      ),
                      SizedBox(
                        height: 5,
                      ),
                      Text(
                        "DISCOVER THE BEST SOLUTION EASY & SIMPLE",
                        textAlign: TextAlign.center,
                        style: TextStyle(
                            fontSize: 12,
                            color: Color.fromRGBO(112, 112, 112, 1)),
                      )
                    ]),
              ),
              Container(
                margin: EdgeInsets.only(top: 35),
                height: 340,
                width: double.infinity,
                decoration: BoxDecoration(
                    image: DecorationImage(
                        image: AssetImage("assets/SVG/back.png"))),
                child: Container(
                  height: 390,
                  width: 340,
                  margin: EdgeInsets.only(left: 20, right: 20),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    color: Colors.white,
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.12),
                        offset: const Offset(
                          3.0,
                          3.0,
                        ),
                        blurRadius: 8.0,
                        spreadRadius: 2.0,
                      ), //BoxShadow
                      BoxShadow(
                        color: Colors.white,
                        offset: const Offset(0.0, 0.0),
                        blurRadius: 0.0,
                        spreadRadius: 0.0,
                      ), //BoxShadow
                    ],
                  ),
                  child: Column(children: [
                    Container(
                      margin:
                          EdgeInsets.symmetric(vertical: 43, horizontal: 62.10),
                      child: Text(
                        "Select Your Language",
                        style: TextStyle(
                            fontSize: 20, color: Color.fromRGBO(78, 78, 78, 1)),
                      ),
                    ),
                    Container(
                        child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        InkWell(
                          onHover: (val) {
                            setState(() {
                              amIHovering = val;
                              print(amIHovering);
                            });
                          },
                          child: AnimatedContainer(
                            duration: Duration(milliseconds: 200),
                            height: 110,
                            width: 110,
                            decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: amIHovering ? Colors.white : themeColor,
                                boxShadow: [
                                  BoxShadow(
                                    color: Color.fromRGBO(153, 167, 223, 1)
                                        .withOpacity(1),
                                    spreadRadius: 5,
                                    blurRadius: 6,
                                    offset: Offset(
                                        0, 6), // changes position of shadow
                                  ),
                                ]),
                            child: Column(
                                // mainAxisAlignment: MainAxisAlignment.spaceBspaceetween,
                                children: [
                                  SizedBox(
                                    height: screenHeight / 26.26,
                                  ),
                                  Container(
                                    height: 50,
                                    width: 50,
                                    decoration: BoxDecoration(
                                        image: DecorationImage(
                                            image: AssetImage(
                                                "assets/SVG/अ2x.png"),
                                            fit: BoxFit.cover)),
                                  ),
                                  Text(
                                    "Hindi",
                                    style: TextStyle(
                                        fontSize: 14,
                                        color: Colors.black,
                                        fontWeight: FontWeight.bold),
                                  )
                                ]),
                          ),
                        ),
                        Container(
                          margin: EdgeInsets.all(10),
                          height: 4,
                          width: 24,
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10),
                              color: Color.fromRGBO(154, 154, 154, 1)),
                        ),
                        Container(
                          height: 110,
                          width: 110,
                          decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              // borderRadius: BorderRadius.circular(100),
                              color: Color.fromRGBO(250, 215, 0, 1),
                              boxShadow: [
                                BoxShadow(
                                  color: Color.fromRGBO(153, 167, 223, 1)
                                      .withOpacity(1),
                                  spreadRadius: 5,
                                  blurRadius: 6,
                                  offset: Offset(
                                      0, 6), // changes position of shadow
                                ),
                              ]),
                          child: Column(
                              // mainAxisAlignment: MainAxisAlignment.spaceBspaceetween,
                              children: [
                                SizedBox(
                                  height: screenHeight / 26.26,
                                ),
                                Container(
                                  height: 50,
                                  width: 50,
                                  decoration: BoxDecoration(
                                      image: DecorationImage(
                                          image:
                                              AssetImage("assets/SVG/A2x.png"),
                                          fit: BoxFit.cover)),
                                ),
                                Text(
                                  "English",
                                  style: TextStyle(
                                      fontSize: 14,
                                      color: Colors.white,
                                      fontWeight: FontWeight.bold),
                                )
                              ]),
                        )
                      ],
                    )),
                    GestureDetector(
                      onTap: () async {
                        if (kIsWeb) {
                        } else {
                          final fcmToken =
                              await FirebaseMessaging.instance.getToken();
                          print(fcmToken);
                        }
                        SharedPreferences prefs =
                            await SharedPreferences.getInstance();
                        //
                        var phone = prefs.getBool("islogin");
                        if (phone == true) {
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) =>
                                      BottomNavigationBarScreen(
                                        pageIndex: 0,
                                      )));
                        } else {
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => PhoneRegister()));
                        }
                      },
                      child: Container(
                        margin: EdgeInsets.only(top: 46),
                        width: 247,
                        height: 56,
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(25),
                            border: Border.all(
                                width: 2, color: Color.fromRGBO(2, 44, 67, 1))),
                        child: Center(
                          child: Text(
                            "GET STARTED",
                            style: TextStyle(
                                fontSize: 17,
                                color: Color.fromRGBO(2, 44, 67, 1)),
                          ),
                        ),
                      ),
                    )
                  ]),
                ),
              ),
              Center(
                child: Container(
                  margin: EdgeInsets.only(
                    top: 50,
                  ),
                  width: 196,
                  child: Text(
                    "Welcome To ChatnFix Discover the Best Solution Easy & Simple",
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 16, color: Colors.black),
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }

  Widget MobileLanguage() {
    var screenWidth = MediaQuery.of(context).size.width;
    var screenHeight = MediaQuery.of(context).size.height;
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            margin: EdgeInsets.only(top: 94, left: 21),
            height: 84,
            width: double.infinity,
            child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    height: 50,
                    // width: 198,
                    child: Image.asset(
                      "assets/logo.png",
                      fit: BoxFit.fill,
                    ),
                  ),
                  SizedBox(
                    height: 5,
                  ),
                  Text(
                    "DISCOVER THE BEST SOLUTION EASY & SIMPLE",
                    style: TextStyle(
                        fontSize: 10, color: Color.fromRGBO(112, 112, 112, 1)),
                  )
                ]),
          ),
          Container(
            margin: EdgeInsets.only(top: 68),
            height: 390,
            width: double.infinity,
            decoration: BoxDecoration(
                image:
                    DecorationImage(image: AssetImage("assets/SVG/back.png"))),
            child: Container(
              height: 390,
              width: 340,
              margin: EdgeInsets.only(left: 20, right: 20),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                color: Colors.white,
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.12),
                    offset: const Offset(
                      3.0,
                      3.0,
                    ),
                    blurRadius: 8.0,
                    spreadRadius: 2.0,
                  ), //BoxShadow
                  BoxShadow(
                    color: Colors.white,
                    offset: const Offset(0.0, 0.0),
                    blurRadius: 0.0,
                    spreadRadius: 0.0,
                  ), //BoxShadow
                ],
              ),
              child: Column(children: [
                Container(
                  margin: EdgeInsets.symmetric(vertical: 43, horizontal: 62.10),
                  child: Text(
                    "Select Your Language",
                    style: TextStyle(
                        fontSize: 20, color: Color.fromRGBO(78, 78, 78, 1)),
                  ),
                ),
                Container(
                    child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    GestureDetector(
                      child: Container(
                        height: screenHeight / 6.73,
                        width: screenWidth / 3.0763,
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(100),
                            color: Colors.white,
                            boxShadow: [
                              BoxShadow(
                                color: Color.fromRGBO(153, 167, 223, 1)
                                    .withOpacity(1),
                                spreadRadius: 5,
                                blurRadius: 6,
                                offset:
                                    Offset(0, 6), // changes position of shadow
                              ),
                            ]),
                        child: Column(
                            // mainAxisAlignment: MainAxisAlignment.spaceBspaceetween,
                            children: [
                              SizedBox(
                                height: screenHeight / 26.26,
                              ),
                              Container(
                                height: screenHeight / 16.08,
                                width: screenWidth / 7.2,
                                decoration: BoxDecoration(
                                    image: DecorationImage(
                                        image: AssetImage("assets/SVG/अ2x.png"),
                                        fit: BoxFit.cover)),
                              ),
                              Text(
                                "Hindi",
                                style: TextStyle(
                                    fontSize: 14,
                                    color: Colors.black,
                                    fontWeight: FontWeight.bold),
                              )
                            ]),
                      ),
                    ),
                    Container(
                      margin: EdgeInsets.all(10),
                      height: 4,
                      width: 24,
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          color: Color.fromRGBO(154, 154, 154, 1)),
                    ),
                    Container(
                      height: screenHeight / 6.73,
                      width: screenWidth / 3.0763,
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(100),
                          color: Color.fromRGBO(250, 215, 0, 1),
                          boxShadow: [
                            BoxShadow(
                              color: Color.fromRGBO(153, 167, 223, 1)
                                  .withOpacity(1),
                              spreadRadius: 5,
                              blurRadius: 6,
                              offset:
                                  Offset(0, 6), // changes position of shadow
                            ),
                          ]),
                      child: Column(
                          // mainAxisAlignment: MainAxisAlignment.spaceBspaceetween,
                          children: [
                            SizedBox(
                              height: screenHeight / 26.26,
                            ),
                            Container(
                              height: screenHeight / 16.08,
                              width: screenWidth / 5.14,
                              decoration: BoxDecoration(
                                  image: DecorationImage(
                                      image: AssetImage("assets/SVG/A2x.png"),
                                      fit: BoxFit.cover)),
                            ),
                            Text(
                              "English",
                              style: TextStyle(
                                  fontSize: 14,
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold),
                            )
                          ]),
                    )
                  ],
                )),
                GestureDetector(
                  onTap: () async {
                    if (kIsWeb) {
                    } else {
                      final fcmToken =
                          await FirebaseMessaging.instance.getToken();
                      print(fcmToken);
                    }
                    SharedPreferences prefs =
                        await SharedPreferences.getInstance();
                    //
                    var phone = prefs.getBool("islogin");
                    if (phone == true) {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => BottomNavigationBarScreen(
                                    pageIndex: 0,
                                  )));
                    } else {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => PhoneRegister()));
                    }
                  },
                  child: Container(
                    margin: EdgeInsets.only(top: 46),
                    width: 247,
                    height: 56,
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(25),
                        border: Border.all(
                            width: 2, color: Color.fromRGBO(2, 44, 67, 1))),
                    child: Center(
                      child: Text(
                        "GET STARTED",
                        style: TextStyle(
                            fontSize: 17, color: Color.fromRGBO(2, 44, 67, 1)),
                      ),
                    ),
                  ),
                )
              ]),
            ),
          ),
          Center(
            child: Container(
              margin: EdgeInsets.only(
                top: 50,
              ),
              width: 196,
              child: Text(
                "Welcome To ChatnFix Discover the Best Solution Easy & Simple",
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 16, color: Colors.black),
              ),
            ),
          )
        ],
      ),
    );
  }
}

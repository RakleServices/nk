// To parse this JSON data, do
//
//     final customerProfileModel = customerProfileModelFromJson(jsonString);

import 'dart:convert';

CustomerProfileModel customerProfileModelFromJson(String str) =>
    CustomerProfileModel.fromJson(json.decode(str));

String customerProfileModelToJson(CustomerProfileModel data) =>
    json.encode(data.toJson());

class CustomerProfileModel {
  CustomerProfileModel({
    required this.rowsCount,
    required this.data,
  });

  int rowsCount;
  List<CustomerP> data;

  factory CustomerProfileModel.fromJson(Map<String, dynamic> json) =>
      CustomerProfileModel(
        rowsCount: json["rowsCount"],
        data: List<CustomerP>.from(
            json["data"].map((x) => CustomerP.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "rowsCount": rowsCount,
        "data": List<dynamic>.from(data.map((x) => x.toJson())),
      };
}

class CustomerP {
  CustomerP(
      {required this.id,
      required this.phone,
      required this.name,
      required this.otp,
      required this.email,
      required this.dob,
      required this.gender,
      required this.photo,
      required this.transdate,
      required this.mob_notification});

  int id;
  String phone;
  String name;
  String otp;
  String email;
  String dob;
  String gender;
  String photo;
  String transdate;
  String mob_notification;

  factory CustomerP.fromJson(Map<String, dynamic> json) => CustomerP(
      id: json["id"],
      phone: json["phone"],
      name: json["name"],
      otp: json["otp"],
      email: json["email"],
      dob: json["dob"],
      gender: json["gender"],
      photo: json["photo"],
      transdate: json["transdate"],
      mob_notification: json["mob_notification"]);

  Map<String, dynamic> toJson() => {
        "id": id,
        "phone": phone,
        "name": name,
        "otp": otp,
        "email": email,
        "dob": dob,
        "gender": gender,
        "photo": photo,
        "transdate": transdate,
        "mob_notification": mob_notification
      };
}
